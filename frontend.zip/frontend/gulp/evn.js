'use strict';


var gulp = require('gulp');
var gulpNgConfig = require('gulp-ng-config');
var rename = require("gulp-rename");


gulp.task('env', function () {
  gulp.src('app.env.json')
    .pipe(gulpNgConfig('app',{
      createModule: false,
      wrap: true,
    }))
    .pipe(rename(function (path) {
      path.basename = "app.env";
      path.extname = ".js"
    }))
    .pipe(gulp.dest('./src/app'))
});


