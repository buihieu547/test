'use strict'

$(document).ready(function(){
    var option = [
		{option_1: 'a'},
		{option_1: 'b'},
		{option_1: 'c'},
		{option_1: 'd'},
		{option_1: 'e'}
	];
	
	$('#').change(function() {
		
	});
});