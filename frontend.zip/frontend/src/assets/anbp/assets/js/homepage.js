function searchValue(type) {
    var searchType = type || $("#searchType").val();

    switch (searchType) {
        case '0':
            window.location.href = "categories-vin.html";
            break;
        case '1':
            window.location.href = "categories-oem-detail.html";
            break;
        case '2':
            window.location.href = "categories-partlink.html";
            break;
        case '3':
            window.location.href = "product-detail-part.html";
            break;
        default:
            window.location.href = "categories-vin.html";
            break;
    }
}