(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($httpProvider, $localStorageProvider, APIProvider,$sessionStorageProvider) {
        var interceptor = function ($q, $injector) {
            return {
                'request': function (config) {
                    var $state = $injector.get("$state");
                    if($state.includes('app')){
                        var token = $localStorageProvider.get('AUTHENTICATE_TOKEN');
                        if (token) {
                            config.headers['Authorization'] = 'Bearer ' + token;
                        }


                    }else{
                        var token = $sessionStorageProvider.get('CL_AUTHENTICATE_TOKEN');
                        if (token) {
                            config.headers['Authorization'] = 'Bearer ' + token;
                        }

                    }

                    // config.headers['Timezone'] = moment.tz.guess();

                    return config;
                },
                'response': function (response) {
                    return response;
                },
                'responseError': function (errors) {

                    APIProvider.$get().handleErrors(errors.data);

                    if(errors.data.hasOwnProperty('logout') && errors.data.logout === true){
                        $localStorageProvider.remove('AUTHENTICATE_TOKEN');

                        var $state = $injector.get("$state");
                        console.log($state);
                        $state.go('app.login');
                    }

                    return $q.reject(errors);
                }
            }
        };

        $httpProvider.interceptors.push(interceptor);
    }

})();
