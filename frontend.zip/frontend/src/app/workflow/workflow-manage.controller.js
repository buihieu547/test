(function() {
    'use strict';

    angular
        .module('app')
        .controller('workflow-manage.controller', controller);

    /** @ngInject */
    function controller($uibModal, $scope, $timeout, $state, $location, $stateParams, $rootScope, $sessionStorage, $localStorage, $controller) {

        $scope.goDetail = function() {
            $state.go("app.workflow.edit", {}, { reload: true });
        }
    }
})();