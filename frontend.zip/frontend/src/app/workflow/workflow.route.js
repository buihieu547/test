(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.workflow', {
                url: '/workflow',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.workflow.manage', {
                url: '/manage',
                templateUrl: 'app/workflow/workflow.html',
                controller: 'workflow-manage.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.workflow.edit', {
                url: '/edit',
                templateUrl: 'app/workflow/workflow.edit.html',
                controller: 'workflow.controller',
                // middleware : ['auth', 'manager_salesman']
            })

    }

})();
