(function() {
    'use strict';

    angular
        .module('app')
        .controller('workflow.controller', controller);

    /** @ngInject */
    function controller($uibModal, $scope, $timeout, $state, $location, $stateParams, $rootScope, $sessionStorage, $localStorage, $controller) {
        $scope.draggableActions = [{ name: 'Start', type: 3, }, { name: 'End', type: 4, }, { name: 'New Document', img: "../../../assets/img/icon-workflow/new-document.png" }, { name: 'Notify Document', img: "../../../assets/img/icon-workflow/Notify.png" }, { name: 'Read Document', img: "../../../assets/img/icon-workflow/Read.png" }, { name: 'Delete Document', img: "../../../assets/img/icon-workflow/delete.png" }, { name: 'Approve Document', img: "../../../assets/img/icon-workflow/new-document.png" }];
        $scope.draggableConditions = [{ name: 'Condition', type: 2, img: "../../../assets/img/icon-workflow/Condition.png" }, { name: 'Parallel', type: 2, img: "../../../assets/img/icon-workflow/Parallel.png" }];
        $scope.draggableInteractives = [{ name: 'Message', img: "../../../assets/img/icon-workflow/Message.png" }, { name: 'Set State Name', img: "../../../assets/img/icon-workflow/Set-State-name.png" }, { name: 'User Notification', img: "../../../assets/img/icon-workflow/User-notification.png" }, { name: 'Task', img: "../../../assets/img/icon-workflow/task.png" }];

        $scope.centerAnchor = true;
        $scope.dropOject = [];
        $scope.parentDragable = true;
        $scope.conditionMode = {
            flag: 0,
            data: null
        };

        $scope.currentIndex = 0;
        $scope.currentPrevObject = null;

        var currentjsPlumb = jsPlumb.getInstance();

        var common = {
            connector: ["Straight"],
            anchor: ["Bottom", "Top"],
            endpoint: "Blank"
        };

        var condition = {
            2: {
                connector: ["Flowchart"],
                anchor: ["Left", "Top"],
                endpoint: "Blank"
            },
            1: {
                connector: ["Flowchart"],
                anchor: ["Right", "Top"],
                endpoint: "Blank"
            }
        }

        $scope.nodes = [];

        function initArrow(src, type, data) {
            $scope.currentPrevObject = src;
            var currentIndex = ($scope.dropOject.length - 1);
            console.log(currentIndex);

            var cur = jQuery("#object" + currentIndex);
            var jsConfig = common;

            if (type == "left") {
                cur.css({ "left": src.offset().left - 240 });
                jsConfig = condition[2];
            } else
            if (type == "right") {
                cur.css({ "left": src.offset().left + 90 });
                jsConfig = condition[1];
            } else {
                if ($scope.currentPrevObject) {
                    cur.css({ "left": $scope.currentPrevObject.offset().left - 75 });
                }
            }

            //Set height position
            cur.css({ "top": jQuery(".dropable-container").scrollTop() + src.offset().top - 100 });
            jQuery(".dropable-container-1").css("height", jQuery(".dropable-container").scrollTop() + cur.offset().top + 100);

            currentjsPlumb.ready(function() {
                currentjsPlumb.connect({
                    source: src,
                    target: cur,
                    paintStyle: { stroke: "lightgray", strokeWidth: 2 , "dashstyle": "2" },
                    endpointStyle: { fillStyle: "lightgray", outlineStroke: "gray" },
                    overlays: [
                        ["Arrow", { width: 12, length: 12, location: 0.5 }],
                        // [ "Label", { location:0.1, label:"Teooo",cssClass:"labell" } ],
                        
                    ]
                }, jsConfig);
                currentjsPlumb.draggable(cur, { containment: 'parent' });

            })




        }


        $scope.enableDrag = function(index, item) {
            // $scope.currentDragItem = jQuery("#object" + index);
            // $scope.currentDragItem = item;

            // if (item.dragable) {
            //     item.dragable = !item.dragable;
            //     currentjsPlumb.draggable(jQuery("#object" + index), { disabled: true, containment: 'parent' });
            // } else {
            //     item.dragable = !item.dragable;
            //     currentjsPlumb.draggable(jQuery("#object" + index), { containment: 'parent' });
            // }
        }

        $scope.disableDrag = function() {
            // if ($scope.currentDragItem) return;
            // $scope.currentDragItem.item.dragable = !$scope.currentDragItem.item.dragable;
            // currentjsPlumb.draggable($scope.currentDragItem, { disabled: true, containment: 'parent' });

        }

        $scope.onDropComplete = function(data, event, id, item, flag, type, reload) {
            var data_id = angular.copy(id);
            if (flag) {
                data.parent = (type) ? id : "";
                data.id = data_id;
                data.item = item;
                data.flag = flag;
                data.type_condition = type;
                $timeout(function() {
                        $scope.dropOject.push(angular.copy(data));
                    })
                    //Show connector button
                    // if(item) {
                    //     item.notAvaiable = true;                    
                    // }
                    // if(type) {
                    //     if(type == "left") item.notAvaiableLeft = true;   
                    //     if(type == "left") item.notAvaiableRight = true;   
                    // }
                $scope.parentDragable = false;
                if (data_id != null) {
                    $timeout(function() {
                        initArrow(jQuery("#object" + data_id), type, data);
                    })
                } else {
                    $timeout(function() {
                        jQuery('#object0').css({ "top": '100px' });

                    })
                }

                return;
            }

            item.children = item.children || [];
            item.children.push(data);
            console.log(item.children)
        }

        $scope.onDragComplete1 = function(data, evt) {
            $scope.dropOject.push(data);
            if (data.type) {
                $scope.parentDragable = false;
                $scope.conditionMode.flag = 3;
            } else {
                $scope.conditionMode.flag = ($scope.conditionMode.flag || 1) - 1;
            }

            $timeout(function() {
                jQuery("#object" + $scope.currentnode + " a#close-object-" + $scope.currentnode).on('click', function(e) {
                    var id = e.currentTarget.id.split("close-object-")[1];
                    $scope.remove(id);
                });
            }, 500)

            if ($scope.dropOject.length > 1) {
                $timeout(function() {
                    var prev = jQuery("#object" + ($scope.currentnode));
                    var cur = jQuery("#object" + ($scope.currentnode + 1));

                    //Check if condition 
                    if ($scope.conditionMode.flag) {
                        if ($scope.conditionMode.flag == 3) {
                            $scope.conditionMode.data = cur;
                            $scope.conditionMode.index = $scope.currentnode + 1;
                        } else {
                            prev = $scope.conditionMode.data;
                        }
                    }


                    cur.css({ "top": jQuery(".dropable-container").scrollTop() + prev.offset().top - 100 });

                    jQuery(".dropable-container-1").css("height", cur.offset().top + 100);

                    if ($scope.conditionMode.flag > 0 && $scope.conditionMode.flag < 3) {
                        if ($scope.conditionMode.flag == 2) {
                            cur.css({ "left": prev.offset().left - 300 });
                        }

                        if ($scope.conditionMode.flag == 1) {
                            cur.css({ "left": prev.offset().left + 150 });
                        }

                        currentjsPlumb.connect({
                            source: "object" + ($scope.conditionMode.index || $scope.currentnode),
                            target: "object" + (++$scope.currentnode),
                            paintStyle: { stroke: "lightgray", strokeWidth: 3 },
                            endpointStyle: { fillStyle: "lightgray", outlineStroke: "gray" },
                            overlays: [
                                ["Arrow", { width: 12, length: 12, location: 1 }]
                            ]
                        }, condition[$scope.conditionMode.flag]);

                        resetCondition();
                    } else {
                        currentjsPlumb.connect({
                            source: "object" + ($scope.currentnode++),
                            target: "object" + ($scope.currentnode),
                            paintStyle: { stroke: "lightgray", strokeWidth: 3 },
                            endpointStyle: { fillStyle: "lightgray", outlineStroke: "gray" },
                            overlays: [
                                ["Arrow", { width: 12, length: 12, location: 1 }]
                            ]
                        }, common);
                    }


                    // currentjsPlumb.animate($("#object0"), {"left": 50,"top": 300},{duration:"slow"});
                    // currentjsPlumb.animate($("#object1"), {"left": 250,"top": 100},{duration:"slow"});
                    // currentjsPlumb.connect({
                    //     source: "object"+ ($scope.currentnode++),
                    //     target: "object" + $scope.currentnode
                    // }, stateMachineConnector);

                    // currentjsPlumb.animate($("#object0"), {"left": 50,"top": 300},{duration:"slow"});
                    // currentjsPlumb.animate($("#object1"), {"left": 250,"top": 100},{duration:"slow"});
                    currentjsPlumb.draggable(cur, { containment: 'parent' });


                }, 100);




            }
        }

        $scope.closeButton = function(index) {
            $scope.remove(index);

        }

        $scope.loadChart = function() {

            var loadData = angular.copy($scope.tempData);
            loadData.map(function(data) {
                $timeout(function() {
                    $scope.onDropComplete(data, null, data.id, data.item, data.flag, data.type_condition);

                }, 100)

            })
        }

        $scope.enterText = function(item) {
            item.hide = !item.hide;
        }

        $scope.saveChart = function() {
            $scope.tempData = angular.copy($scope.dropOject);
            for (var i in $scope.dropOject) {
                currentjsPlumb.remove("object" + i);
            }
            $localStorage.chartData = angular.copy($scope.tempData);
            $scope.dropOject = [];
            $scope.parentDragable = true;
        }

        $scope.openSetting = function() {

            $uibModal.open({
                animation: true,
                templateUrl: 'app/workflow/document-popup.html',
                controller: ['$uibModalInstance',
                    '$scope',
                    function($uibModalInstance, modalScope) {

                        modalScope.modalTitle = "SETTING";

                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        };

                        modalScope.ok = function() {
                            $uibModalInstance.close(modalScope.checkList);
                        };

                    }
                ],
                size: 'md'
            }).result.then(function(res) {

            });
        }

        function resetCondition() {
            if ($scope.conditionMode.flag == 1) {
                //Reset condition
                $scope.currentnode = $scope.conditionMode.index + 1;
                $scope.conditionMode = {
                    flag: 0,
                    data: null
                };
            }
        }


        $scope.currentnode = 0;
        // $scope.onDropComplete = function(data, evt) {
        //     console.log("drop success, data:", data);
        // }

        $scope.onDropCompleteLeft = function(data, e, ref) {

        }

        $scope.remove = function(index) {
            currentjsPlumb.remove("object" + index);
            $scope.dropOject.splice(index, 1);
            if ($scope.dropOject.length == 0) {
                $scope.parentDragable = true;
            }

            $scope.currentnode = (Number(index) || 1) - 1;
        }

        $scope.createTemplate = function() {
            $scope.dropOject = [];
            $scope.tempData = [];
            $scope.parentDragable = true;
        }

        $timeout(function() {
            if ($localStorage.chartData) {
                $scope.dropOject = [];
                $scope.tempData = $localStorage.chartData
                $scope.loadChart();
            }

        })

    }
})();