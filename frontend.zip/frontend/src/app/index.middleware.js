(function () {
    'use strict';

    angular.module('app').config(configMiddleware);

    /** @ngInject **/
    function configMiddleware($middlewareProvider, $localStorageProvider, $sessionStorageProvider) {
        $middlewareProvider.map({

            /** Don't allow anyone through */
            'nobody': function nobodyMiddleware() {
				// this.redirectTo('app.products.manage');
            },

            /** Let everyone through */
            'everyone': function everyoneMiddleware() {
                this.next();
            },

            'auth': function everyoneMiddleware() {
                if ($localStorageProvider.get('AUTHENTICATE_TOKEN')) {
					 this.next();
						// this.redirectTo('app.products.manage');
                }
                this.redirectTo('app.login');
			},

			'auth-client': function everyoneMiddleware() {
					if ($sessionStorageProvider.get('CL_AUTHENTICATE_TOKEN')) {
						this.next();
				   }
				   this.redirectTo('anbp.index');
            },
	        // 'admin': function everyoneMiddleware() {
		    //     if($localStorageProvider.get('USER_DATA')) {
			//         var _userData  = $localStorageProvider.get('USER_DATA');
			//         if(_userData.role_alias === 'admin') {
			// 	        this.next();
			//         }
		    //     }

		    //     this.redirectTo('access_denied');
	        // },

	        // 'manager': function everyoneMiddleware() {
		    //     if($localStorageProvider.get('USER_DATA')) {
			//         var _userData  = $localStorageProvider.get('USER_DATA');
			//         if(_userData.role_alias === 'manager') {
			// 	        this.next();
			//         }
		    //     }

		    //     this.redirectTo('access_denied');
	        // },

	        // 'bo': function everyoneMiddleware() {
		    //     if($localStorageProvider.get('USER_DATA')) {
			//         var _userData  = $localStorageProvider.get('USER_DATA');
			//         if(_userData.role_alias === 'bo') {
			// 	        this.next();
			//         }
		    //     }

		    //     this.redirectTo('access_denied');
	        // },

	        // 'manager_salesman': function everyoneMiddleware() {
		    //     if($localStorageProvider.get('USER_DATA')) {
			//         var _userData  = $localStorageProvider.get('USER_DATA');
			//         if(_userData.role_alias === 'manager' || _userData.role_alias === 'salesman') {
			// 	        this.next();
			//         }
		    //     }

		    //     this.redirectTo('access_denied');
	        // },

	        // 'manager_salesman_bo': function everyoneMiddleware() {
		    //     if($localStorageProvider.get('USER_DATA')) {
			//         var _userData  = $localStorageProvider.get('USER_DATA');
			//         if(_userData.role_alias === 'manager' || _userData.role_alias === 'salesman' || _userData.role_alias == 'bo') {
			// 	        this.next();
			//         }
		    //     }

		    //     this.redirectTo('access_denied');
	        // },

            /** Redirect everyone */
            'redirect-all': function redirectAllMiddleware() {
                this.redirectTo('app.home');
            }
        })
    }
})();
