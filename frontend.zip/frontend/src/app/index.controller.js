(function() {
    'use strict';

    angular
        .module('app')
        .controller('index.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $localStorage, $rootScope, productAPI, Idle, Keepalive, hotkeys, $sessionStorage,  tmhDynamicLocale, gettextCatalog) {
        $rootScope.forceHidden = false;
        $rootScope.cartItem = $sessionStorage.cartItem || [];
        $rootScope.totalItems = 0;
        $scope.oneui = {
            version: '3.1', // Template version
            localStorage: false, // Enable/Disable local storage
            settings: {
                activeColorTheme: false, // Set a color theme of your choice, available: 'amethyst', 'city, 'flat', 'modern' and 'smooth'
                sidebarLeft: true, // true: Left Sidebar and right Side Overlay, false: Right Sidebar and left Side Overlay
                sidebarOpen: true, // Visible Sidebar by default (> 991px)
                sidebarOpenXs: false, // Visible Sidebar by default (< 992px)
                sidebarMini: false, // Mini hoverable Sidebar (> 991px)
                sideOverlayOpen: false, // Visible Side Overlay by default (> 991px)
                sideOverlayHover: false, // Hoverable Side Overlay (> 991px)
                sideScroll: true, // Enables custom scrolling on Sidebar and Side Overlay instead of native scrolling (> 991px)
                headerFixed: true // Enables fixed header
            }
        };
        $scope.brands = {};

        $scope.permission = {};
        console.log(1)
        $scope.stateConfig = {
            partList: "app.products.manage",
            orderList: "app.orders.sale-order.list",
            rmaList: "app.orders.rma.list",
            buyerList: "app.customer.buyers.manage",
            activity: "app.logs.activity"
        }

        $scope.getHomeRoute = 'app.dashboard.promotion';
        $scope.getLoginRoute = 'login';

        $scope.languageConfig = [
            { value: "en", image: "./assets/img/flag/Flag_Global.png", name: "English", align: 'left' },
            { value: "he", image: "./assets/img/flag/Flag_Israel.png", name: "Hebrew", align: 'right' },
        ]


        $scope.user = {};
        if ($localStorage.USER_DATA) {
            $scope.permission = $localStorage.USER_DATA.role_alias;
            $scope.user = $localStorage.USER_DATA;
        }

        $scope.logoutAction = function() {
            $timeout(function() {
                $localStorage.$reset();
                $localStorage.currentLanguge = $rootScope.currentLanguge.value;
                // window.location.reload();
                $state.go('app.login');

            }, 0);
        };

        //Language Handle

        $scope.languageConfig = [
            { value: "en", image: "./assets/img/flag/Flag_Global.png", name: "English", align: 'left' },
            { value: "he", image: "./assets/img/flag/Flag_Israel.png", name: "Hebrew", align: 'right' },
        ]

        function setLanguage() {
            var language = $localStorage.currentLanguge || 'en';
            var data = $scope.languageConfig.find(function(item) {
                return item.value == language;
            })
            $rootScope.currentLanguge = {
                value: language,
                image: data.image,
                name: data.name,
                align: data.align,
            };
            tmhDynamicLocale.set($rootScope.currentLanguge.value);
            gettextCatalog.setCurrentLanguage($rootScope.currentLanguge.value);
        }

        $scope.changeLanguage = function(value) {
            $localStorage.currentLanguge = value;
            setLanguage();
            $state.go($state.current, {}, { reload: true });
        }

        setLanguage();
        //Key board Handle
        hotkeys.bindTo($scope)
            .add({
                combo: 'ctrl+p',
                description: 'Parts List',
                callback: function(e) {
                    e.preventDefault();
                    switchState($scope.stateConfig.partList)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'ctrl+o',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Orders List',
                callback: function(e) {
                    e.preventDefault();
                    switchState($scope.stateConfig.orderList)
                }
            })
            .add({
                combo: 'ctrl+r',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Return Orders List',
                callback: function(e) {
                    e.preventDefault();
                    switchState($scope.stateConfig.rmaList)
                }
            })
            .add({
                combo: 'ctrl+b',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Buyers List',
                callback: function(e) {
                    e.preventDefault();
                    switchState($scope.stateConfig.buyerList)
                }
            })
            .add({
                combo: 'ctrl+l',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Activities Logs',
                callback: function(e) {
                    e.preventDefault();
                    switchState($scope.stateConfig.activity)
                }
            })

        function switchState(stateName) {
            $state.go(stateName);
        }

        $scope.$on('IdleTimeout', function() {
            $localStorage.$reset();
            window.location.reload();
        });
    }
})();
