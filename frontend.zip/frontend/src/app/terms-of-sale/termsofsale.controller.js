(function () {
    'use strict';

    angular.module('app').controller('termsofsale.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $state, $stateParams) {

    }
})();
