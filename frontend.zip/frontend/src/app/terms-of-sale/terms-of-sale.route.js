(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {
        $stateProvider
	        .state('termsofsale', {
		        url: '/terms-of-sale',
		        controller: 'termsofsale.controller',
		        templateUrl: 'app/terms-of-sale/terms-of-sale.html'
	        })
    }
})();
