(function () {
    'use strict';

    angular.module('app').config(
        appConfig
    );

    /** @ngInject **/
    function appConfig($stateProvider, $urlRouterProvider, $httpProvider) {
        $urlRouterProvider.when('/admin', '/admin/login');
        $urlRouterProvider.otherwise('/');
        // Application routes
        $stateProvider
            .state('app', {
                url: '/admin',
                abstract: true,
                templateUrl: 'app/layouts/main.html',
                controller: 'index.controller',
                middleware: ['auth']
            })
            .state('anbp', {
                url: '',
                abstract: true,
                templateUrl: 'app/anbp/main-layout/main-layout.html',
                ncyBreadcrumb: {
                    label: 'Home'
                },
                // middleware: ['auth-client']
            })
            .state('404', {
                url: '/404',
                data: {pageTitle: 'Not Found'},
                templateUrl: 'app/layouts/404.html',
		        controller: 'index.controller',
            })
            .state('access_denied', {
                url: '/access_denied',
                data: {pageTitle: 'Access Denied'},
                templateUrl: 'app/layouts/access_denied.html',
                controller: 'index.controller',
            });

    }

})();
