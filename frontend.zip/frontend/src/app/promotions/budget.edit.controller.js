(function() {
    'use strict';
    angular
        .module('app')
        .controller('budget.edit.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, promotionAPI, $state,hotkeys,$localStorage) {
        //Define variable 
        $scope.mainData = {           
            generalInfo: {}           
        };        
        (function onInit() {  
            var id = $stateParams.id;
            if(id)
            {
                getDetailBudget(id);
            }          
                     
      
          })();
        
        $scope.cancelBudget= function(){
            $state.go("app.promotions.budget.list");
        }
        function getDetailBudget(id){
            promotionAPI.getBudgetDetail(id).then(function(res){
                try{
                    if(res.data._type=='success'){
                        $scope.mainData.generalInfo = res.data.results;
                        $scope.mainData.generalInfo.crtd_on = new Date($scope.mainData.generalInfo.crtd_on);
                        $scope.mainData.generalInfo.allowable_qty = parseInt($scope.mainData.generalInfo.allowable_qty);
                        $scope.mainData.generalInfo.allowable_amt = parseFloat($scope.mainData.generalInfo.allowable_amt);
                        $scope.mainData.generalInfo.rest_qty =parseInt($scope.mainData.generalInfo.allowable_qty) - ($scope.mainData.generalInfo.tot_qty_used ? $scope.mainData.generalInfo.tot_qty_used: 0);
                        $scope.mainData.generalInfo.rest_amount = parseFloat($scope.mainData.generalInfo.allowable_amt) -($scope.mainData.generalInfo.tot_amt_used ? $scope.mainData.generalInfo.tot_amt_used: 0);
                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        
        $scope.updateBudget = function(id){
            console.log($scope.mainData);
            var params = $scope.mainData.generalInfo;
            promotionAPI.updateBudget(id,params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.promotions.budget.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        $scope.approveBudget = function(id){ 
            var params = $scope.mainData.generalInfo;
            promotionAPI.approveBudget(id,params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);                       

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }      
        
       
    }
})();
