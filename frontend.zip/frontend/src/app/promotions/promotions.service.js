(function () {
    'use strict';

    angular.module('app').service('promotionAPI', service);

    function service(API, $http) {

        this.getListBundle = getListBundle;
        this.postBundle = postBundle;
        this.getListBundleActive =getListBundleActive;
        this.getDetailBundle =getDetailBundle;
        this.updateDetailBundle =updateDetailBundle;

        this.getListBudget = getListBudget;
        this.getListBudgetAll =getListBudgetAll;
        this.getBudgetDetail =getBudgetDetail;
        this.updateBudget = updateBudget;
        this.approveBudget = approveBudget;
        this.postBudget = postBudget;

        this.getListSegment =getListSegment;
        this.getListAllSegment =getListAllSegment;
        this.postSegment = postSegment;
        this.getCustomerSegment = getCustomerSegment;
        this.getDetailSegment =getDetailSegment;
        this.updateSegment = updateSegment;


        //Campaign
        this.getListCampaign =getListCampaign;
        this.getListBaseOption =getListBaseOption;
        this.postCampaign =postCampaign;
        this.getListprogramLevel =getListprogramLevel;
        this.getTypeProgram =getTypeProgram;
        this.getListPromoType =getListPromoType;
        this.getBundleRef = getBundleRef;
        this.getListRefernceBundle =getListRefernceBundle;
        this.getPromoProgram =getPromoProgram;
        this.updatePromoProgram =updatePromoProgram;
        this.generateCampaignCode =generateCampaignCode;

        //condition
        this.getListCondition = getListCondition;
        this.postCondition = postCondition;
        this.getListConditionRef = getListConditionRef;

        this.getListItemById = getListItemById;
        this.createOrder = createOrder;
        this.getStatisticalOrder = getStatisticalOrder;
        this.approveOrd = approveOrd;
        this.cancelOrd = cancelOrd;
        this.sendEmail = sendEmail;
        this.getOrderNumber = getOrderNumber;
        this.generateSO= generateSO;
        this.getHistoryByCode =getHistoryByCode;
        this.getInvoice =getInvoice;

        /** Internal functions */
        // Bundle
        function getListBundle(params){
            var url ='bundle/get-list';
            return API.get(url,params);
        }
        function getBundleRef(params){
            var url ='bundle/reference';
            return API.get(url,params);
        }
        function postBundle(params){
            var url ='bundle';
            return API.post(url,params);
        }
        function getListBundleActive(){
            var url ='bundle/get-list-available';
            return API.get(url);
        }
        function getDetailBundle(id){
            var url ='bundle/'+id;
            return API.get(url);
        }
        function updateDetailBundle(id,params){
            var url ='bundle/'+id;
            return API.put(url,params);
        }


        //Budget
        function getListBudget(params){
            var url ='budget/get-list';
            return API.get(url,params);
        }
        function postBudget(params){
            var url ='budget';
            return API.post(url,params);
        }
        function getListBudgetAll(){
            var url ='budget/get-list-option';
            return API.get(url);
        }
        function getBudgetDetail(id){
            var url ='budget/'+id;
            return API.get(url);
        }
        function updateBudget(id,params){
            var url ='budget/'+id;
            return API.put(url,params);
        }
        function approveBudget(id,params){
            var url ='budget/'+id+'/approve';
            return API.put(url,params);
        }

        //Segment
        function getListSegment(params){
            var url ='customer_segment';
            return API.get(url,params);
        }
        function postSegment(params){
            var url ='customer_segment';
            return API.post(url,params);
        }
        function getListAllSegment(){
            var url ='customer_segment/all';
            return API.get(url);
        }
        function getCustomerSegment(params){
            var url ='customer_segment/search_customer';
            return API.get(url,params);
        }
        function getDetailSegment(id){
            var url ='customer_segment/'+id;
            return API.get(url);
        }
        function updateSegment(id,params){
            var url ='customer_segment/'+id;
            return API.put(url,params);
        }


        //Campaign
        function getListCampaign(params){
            var url ='promotion-campaign/get-list';
            return API.get(url,params);
        }
        function getListBaseOption(){
            var url ='promotion-campaign/get-list-based-option';
            return API.get(url);
        }
        function postCampaign(params){
            var url ='promotion-campaign';
            return API.post(url,params);
        }
        function getListprogramLevel(){
            var url ='promotion-program-level/get-list';
            return API.get(url);
        }
        function getTypeProgram(){
            var url ='promotion-program-type/get-list';
            return API.get(url);
        }
        function getListPromoType(){
            var url ='promo-program-detail/get-list-type';
            return API.get(url);
        }
        function getListRefernceBundle(){
            var url='bundle/promo-reference';
            return API.get(url);
        }
        function getPromoProgram(id){
            var url ="promotion-campaign/"+id;
            return API.get(url)
        }
        function updatePromoProgram(id,params){
            var url ="promotion-campaign/"+id;
            return API.put(url,params)
        }
        function generateCampaignCode(){
            var url ='promotion-campaign/get-campaign-code';
            return API.get(url);
        }



        function getListItemById(params) {
            var url = 'product/list-product-to-order';
            return API.get(url, params);
        }
        function createOrder(params) {
            var url = 'order/create-order';
            return API.post(url, params);
        }
        function getOrderNumber(id){
             var url = ['order', 'generate-order-number',id].join('/');
            return API.get(url);
        }

        function getStatisticalOrder(params) {
            var url = 'order/statistical-order';
            return API.get(url, params);
        }

        function approveOrd(ordId) {
            var url = 'order/approved/' + ordId;
            return API.put(url);
        }

        function cancelOrd(ordId) {
            var url = 'order/cancel/' + ordId;
            return API.put(url);
        }
        function sendEmail(params){
            var url ='order/sent-message';
            return API.put(url, params);
        }
        function generateSO(){
            var url ='order/get-order-code';
            return API.get(url);
        }
        function getHistoryByCode(code){
            var url ="order/history?order_cd="+code;
            return API.get(url);
        }
        function getInvoice(id){
            var url ="order/invoice/"+id;
            return API.get(url);
        }

        //condition
        function getListCondition(params){
            var url ='promotion_condition';
            return API.get(url,params);
        }
        function getListConditionRef(params){
            var url ='promotion_condition/reference';
            return API.get(url,params);
        }
        function postCondition(params){
            var url ='promotion_condition';
            return API.post(url,params);
        }
    }
})();
