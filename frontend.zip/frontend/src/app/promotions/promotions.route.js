(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.promotions', {
                url: '/promotions',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.promotions.budget', {
                url: '/budget',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.promotions.budget.list', {
                url: '/list',
                templateUrl: 'app/promotions/promotions.budget.html',
                controller: 'promotions.budget.controller',
            })
            .state('app.promotions.budget.create', {
                url: '/create',
                templateUrl: 'app/promotions/budget.create.html',
                controller: 'budget.create.controller',
            })
            .state('app.promotions.budget.edit', {
                url: '/view/:id',
                templateUrl: 'app/promotions/budget.edit.html',
                controller: 'budget.edit.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.promotions.campaign', {
                url: '/campaign',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.promotions.campaign.list', {
                url: '/list',
                templateUrl: 'app/promotions/promotions.campaign.html',
                controller: 'promotions.campaign.controller',
            })
            .state('app.promotions.campaign.create', {
                url: '/create',
                templateUrl: 'app/promotions/campaign.create.html',
                controller: 'campaign.create.controller',
            })
            .state('app.promotions.campaign.edit', {
                url: '/view/:id',
                templateUrl: 'app/promotions/campaign.view.html',
                controller: 'campaign.view.controller',
            })
            .state('app.promotions.campaign.promo', {
                url: '/promo.create',
                templateUrl: 'app/promotions/promo.create.html',
                controller: 'promo.create.controller',
            })
    }

})();
