(function() {
    'use strict';
    angular
        .module('app')
        .controller('promo.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, rmaAPI, $state,hotkeys,$localStorage) {
        //Define variable 
        $scope.mainData = {           
            generalInfo: {},
            segmentList:[]
        }; 
        $scope.countries=[];  
        $scope.all_customer_type ='1';
        $scope.listBaseOn = [{
            id: '1',
            name: "Multi Promotion Line"
        }, {
            id: '2',
            name: "Highest Promotion Line"
        }];
        $scope.listStatus = [{
            id: '0',
            name: "In-Active"
        }, {
            id: '1',
            name: "Active "
        }];
        $scope.promoLevel=[
             {
                id: '1',
                name: "Line Item"
            },
            {
                id: '2',
                name: "Products Group"
            },
            {
                id: '3',
                name: "Invoice"
            }
        ];       
        $scope.customerList=[
            {
               id: '1',
               name: "ABC Bar "
           },
           {
               id: '2',
               name: "XYZ Bar "
           }
       ];
        (function onInit() {            
            getListCountry();           
      
          })();
        $scope.clickAdd= function() {
            console.log('a');
            $scope.mainData.segmentList.push({});
        };
        $scope.remove= function(index) {
            $scope.mainData.segmentList.splice(index, 1);
        };
        function getListCountry() {
            API.get('country/get-all').then(function(res) {
              try {
                $scope.countries = res.data.results;               
      
              } catch (e) {
                console.log(e);
              }
            })
          }
       
    }
})();
