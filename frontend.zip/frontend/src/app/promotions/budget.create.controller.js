(function() {
    'use strict';
    angular
        .module('app')
        .controller('budget.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, promotionAPI, $state,hotkeys,$localStorage) {
        //Define variable 
        $scope.mainData = {           
            generalInfo: {}           
        };        
        (function onInit() {            
            $scope.mainData.generalInfo.crtd_on = new Date();
      
          })();
        
        $scope.cancelBudget= function(){
            $state.go("app.promotions.budget.list");
        }
        $scope.createBudget = function(){
            console.log($scope.mainData);
            var params = $scope.mainData.generalInfo;
            promotionAPI.postBudget(params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.promotions.budget.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }      
        
       
    }
})();
