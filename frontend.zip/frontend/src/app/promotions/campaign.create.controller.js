(function() {
    'use strict';
    angular
        .module('app')
        .controller('campaign.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, promotionAPI, $state,hotkeys,$localStorage,$uibModal) {
        //Define variable
        $scope.mainData = {
            generalInfo: {
            },
            programs:[]
        };
        $scope.countries=[];
        $scope.listMaster={
            'listBudget':[],
            'listBaseOn':[],
            'listCustomerSegment':[],
            'promotionLevel':[],
            'typeProgram':[]
        }
        $scope.all_customer_type ='1';
        $scope.listStatus = [{
            id: '0',
            name: "In-Active"
        }, {
            id: '1',
            name: "Active "
        }];
        (function onInit() {
            getListCountry();
            getListBudget();
            getListCustomerSegment();
            getListBaseOn();
            getListPromotionLevel();
            getTypeProgram();
            generateCampaignCode();

          })();
        $scope.clickAdd= function() {
            $scope.mainData.programs.push({'is_dsct':0,'is_acc_bal':0,'is_promo_goods':0});
        };
        $scope.remove= function(index) {
            $scope.mainData.programs.splice(index, 1);
        };
        $scope.goPromoDetail= function(){
            $state.go('app.promotions.campaign.promo');
        }
        $scope.checkLevel =function(item){
            var tempArr = angular.copy($scope.listMaster.typeProgram);
            if(item.level ==3){
                item.typeProgram = tempArr.splice(1,1);
                item.detail=[];
            }else{
                 item.typeProgram = tempArr.splice(0,1);
                 item.detail =[];
            }
        }
        //Create Buyer
        $scope.createCampain= function(){
            var params =$scope.mainData.generalInfo;
            params.programs =$scope.mainData.programs;
            console.log(params);
            promotionAPI.postCampaign(params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.promotions.campaign.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                      }

                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.cancel = function(){
            $state.go("app.promotions.campaign.list");
        }
        function getListCountry() {
            API.get('country/get-all').then(function(res) {
              try {
                $scope.countries = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          function getListBudget(){
              promotionAPI.getListBudgetAll().then(function(res){
                  try{
                      $scope.listMaster.listBudget = res.data.results;
                  }catch(e){
                      console.log(e);
                  }
              })
          }
          function generateCampaignCode(){
            promotionAPI.generateCampaignCode().then(function(res){
                try{
                    $scope.mainData.generalInfo.code = res.data.results.code;
                }catch(e){
                    console.log(e);
                }
            })
        }
          
          function getListBaseOn(){
              promotionAPI.getListBaseOption().then(function(res){
                  try{
                      $scope.listMaster.listBaseOn = res.data.results;
                  }catch(e){
                      console.log(e);
                  }
              })
          }
          function getListCustomerSegment(){
              promotionAPI.getListAllSegment().then(function(res){
                  try{
                      $scope.listMaster.listCustomerSegment = res.data.results;
                  }catch(e){
                      console.log(e);
                  }
              })
          }
          function getListPromotionLevel(){
            promotionAPI.getListprogramLevel().then(function(res){
                try{
                    $scope.listMaster.promotionLevel = res.data.results;
                }catch(e){
                    console.log(e);
                }
            })
          }
          function getTypeProgram(){
            promotionAPI.getTypeProgram().then(function(res){
                try{
                    $scope.listMaster.typeProgram = res.data.results;
                }catch(e){
                    console.log(e);
                }
            })
          }
          //Promo Program
          $scope.goPromoDetail = function(item){
            console.log(item);
            if(item.level==1 && item.type==1){
                $uibModal.open({
                    animation: true,
                    templateUrl: 'app/promotions/add_new_promo.html',
                    controller: ['$uibModalInstance',
                        '$scope',
                        'promotionAPI',
                        'productAPI',
                        'hotkeys',
                        '$timeout',
                        function($uibModalInstance, modalScope, promotionAPI,productAPI, hotkeys, $timeout) {
                            modalScope.item = item;
                            if(!modalScope.item.detail){
                                modalScope.item.detail =[];
                            }
                            console.log(modalScope.item);

                            modalScope.listMaster={
                                'promotionLevel':[],
                                'productList':[],
                                'promoType':[]
                            }

                            modalScope.modalTitle = 'PROMOTION DETAIL LINE';
                            modalScope.name = modalScope.item.name;
                            (function onInit() {
                                getListPromotionLevel();
                                getListItem();
                                getListPromoType();

                            })();

                            modalScope.clickAdd= function() {
                                modalScope.item.detail.push({level:modalScope.item.level,prom_type:1});
                            };
                            modalScope.remove= function(index) {
                                modalScope.item.detail.splice(index, 1);
                            };
                           modalScope.changeProductLineBuying = function(item,index){
                                console.log(index)
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if(product.item_id == item.buying_product_id )
                                        return product;
                                });
                                item.name = itemID[0].name;
                                item.uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }
                            modalScope.changeProductLinePromo = function(item,index){
                                console.log(index)
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if( product.item_id == item.prom_product_id)
                                        return product;
                                });
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }

                            modalScope.cancel = function() {
                                $uibModalInstance.close();
                            };
                            modalScope.ok = function() {
                                $uibModalInstance.close(modalScope.item.detail);
                            };
                            //getlistMaster
                            function getListPromotionLevel(){
                                promotionAPI.getListprogramLevel().then(function(res){
                                    try{
                                        modalScope.listMaster.promotionLevel = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListItem(){
                                productAPI.getListItemOption().then(function(res){
                                    try{
                                        modalScope.listMaster.productList = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListPromoType(){
                                promotionAPI.getListPromoType().then(function(res){
                                    try{
                                        modalScope.listMaster.promoType = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }

                        }
                    ],
                    size: 'lg'
                }).result.then(function(res) {
                   console.log(res)
                    })

            }
            if(item.level==2 && item.type==1){
                $uibModal.open({
                    animation: true,
                    templateUrl: 'app/promotions/add_new_promo.html',
                    controller: ['$uibModalInstance',
                        '$scope',
                        'promotionAPI',
                        'productAPI',
                        'hotkeys',
                        '$timeout',
                        function($uibModalInstance, modalScope, promotionAPI,productAPI, hotkeys, $timeout) {
                            modalScope.item = item;
                            if(!modalScope.item.detail){
                                modalScope.item.detail =[];
                            }
                            modalScope.listMaster={
                                'promotionLevel':[],
                                'productList':[],
                                'promoType':[],
                                'productListBundle':[]
                            }

                            modalScope.modalTitle = 'PROMOTION DETAIL LINE';
                            modalScope.name = modalScope.item.name;
                            (function onInit() {
                                getListPromotionLevel();
                                getListItem();
                                getListBundleRefer();
                                getListPromoType();

                            })();

                            modalScope.clickAdd= function() {
                                modalScope.item.detail.push({level:modalScope.item.level,prom_type:1});
                            };
                            modalScope.remove= function(index) {
                                modalScope.item.detail.splice(index, 1);
                            };
                           modalScope.changeProductLineBuying = function(item,index){
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if(product.item_id == item.buying_product_id )
                                        return product;
                                });
                                item.name = itemID[0].name;
                                item.uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }
                            modalScope.changeProductLinePromo = function(item,index){
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if( product.item_id == item.prom_product_id)
                                        return product;
                                });
                                console.log(itemID);
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }
                            modalScope.changeBundleLineBuying = function(item,index){
                                var itemID= modalScope.listMaster.productListBundle.filter(function(product){
                                    if(product.item_id == item.buying_bundle_id )
                                        return product;
                                });
                                console.log(itemID);
                                item.name = itemID[0].name;
                                item.uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }
                            modalScope.changeBundleLinePromo = function(item,index){
                                var itemID= modalScope.listMaster.productListBundle.filter(function(product){
                                    if(product.item_id == item.prom_bundle_id )
                                        return product;
                                });
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.prom_price=itemID[0].price;
                            }


                            modalScope.cancel = function() {
                                $uibModalInstance.close();
                            };
                            modalScope.ok = function() {
                                $uibModalInstance.close(modalScope.item.detail);
                            };
                            //getlistMaster
                            function getListPromotionLevel(){
                                promotionAPI.getListprogramLevel().then(function(res){
                                    try{
                                        modalScope.listMaster.promotionLevel = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListBundleRefer(){
                                promotionAPI.getListRefernceBundle().then(function(res){
                                    try{
                                        // modalScope.listMaster.productList = res.data.results;
                                        modalScope.listMaster.productListBundle = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListItem(){
                                productAPI.getListItemOption().then(function(res){
                                    try{
                                        modalScope.listMaster.productList = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListPromoType(){
                                promotionAPI.getListPromoType().then(function(res){
                                    try{
                                        modalScope.listMaster.promoType = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }




                        }
                    ],
                    size: 'lg'
                }).result.then(function(res) {
                   console.log(res)
                    })

            }
            if(item.level==3 && item.type==2){
                $uibModal.open({
                    animation: true,
                    templateUrl: 'app/promotions/add_new_promo_invoice.html',
                    controller: ['$uibModalInstance',
                        '$scope',
                        'promotionAPI',
                        'productAPI',
                        'hotkeys',
                        '$timeout',
                        function($uibModalInstance, modalScope, promotionAPI,productAPI, hotkeys, $timeout) {
                            modalScope.item = item;
                            if(!modalScope.item.detail){
                                modalScope.item.detail =[];
                            }
                            modalScope.listMaster={
                                'promotionLevel':[],
                                'productList':[],
                                'promoType':[]
                            }

                            modalScope.modalTitle = 'PROMOTION DETAIL LINE';
                            modalScope.name = modalScope.item.name;
                            (function onInit() {
                                getListPromotionLevel();
                                getListItem();
                                getListPromoType();

                            })();

                            modalScope.clickAdd= function() {
                                modalScope.item.detail.push({level:modalScope.item.level,prom_type:1});
                            };
                            modalScope.remove= function(index) {
                                modalScope.item.detail.splice(index, 1);
                            };
                           modalScope.changeProductLineBuying = function(item,index){
                                console.log(index)
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if(product.item_id == item.buying_product_id )
                                        return product;
                                });
                                item.name = itemID[0].name;
                                item.uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }
                            modalScope.changeProductLinePromo = function(item,index){
                                console.log(index)
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if( product.item_id == item.prom_product_id)
                                        return product;
                                });
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }

                            modalScope.cancel = function() {
                                $uibModalInstance.close();
                            };
                            modalScope.ok = function() {
                                $uibModalInstance.close(modalScope.item.detail);
                            };
                            //getlistMaster
                            function getListPromotionLevel(){
                                promotionAPI.getListprogramLevel().then(function(res){
                                    try{
                                        modalScope.listMaster.promotionLevel = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListItem(){
                                productAPI.getListItemOption().then(function(res){
                                    try{
                                        modalScope.listMaster.productList = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListPromoType(){
                                promotionAPI.getListPromoType().then(function(res){
                                    try{
                                        modalScope.listMaster.promoType = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }




                        }
                    ],
                    size: 'md-2'
                }).result.then(function(res) {
                   console.log(res)
                    })
            }
            if(item.level==4 && item.type==1){
                $uibModal.open({
                    animation: true,
                    templateUrl: 'app/promotions/add_new_promo.html',
                    controller: ['$uibModalInstance',
                        '$scope',
                        'promotionAPI',
                        'productAPI',
                        'hotkeys',
                        '$timeout',
                        function($uibModalInstance, modalScope, promotionAPI,productAPI, hotkeys, $timeout) {
                            modalScope.item = item;
                            if(!modalScope.item.detail){
                                modalScope.item.detail =[];
                            }
                            console.log(modalScope.item);

                            modalScope.listMaster={
                                'promotionLevel':[],
                                'productList':[],
                                'promoType':[],
                                'productListBundle':[],
                                'productLine': []
                            }

                            modalScope.modalTitle = 'PROMOTION DETAIL LINE';
                            modalScope.name = modalScope.item.name;
                            (function onInit() {
                                getListPromotionLevel();
                                getListItem();
                                getListPromoType();
                                getListBundleRefer();
                                getListLine();
                            })();

                            modalScope.clickAdd= function() {
                                modalScope.item.detail.push({level:modalScope.item.level,prom_type:1});
                            };
                            modalScope.remove= function(index) {
                                modalScope.item.detail.splice(index, 1);
                            };
                           modalScope.changeConditionLineBuying = function(item,index){
                                console.log(index)
                                var itemID= modalScope.listMaster.productList.filter(function(product){
                                    if(product.id == item.promotion_condition_group_id )
                                        return product;
                                });
                                item.name = itemID[0].name;
                            }
                            modalScope.changeProductLinePromo = function(item,index){
                                var itemID= modalScope.listMaster.productLine.filter(function(product){
                                    if( product.item_id == item.prom_product_id)
                                        return product;
                                });
                                console.log(itemID);
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.price=itemID[0].price;
                            }

                            modalScope.changeBundleLinePromo = function(item,index){
                                var itemID= modalScope.listMaster.productListBundle.filter(function(product){
                                    if(product.item_id == item.prom_bundle_id )
                                        return product;
                                });
                                item.prom_name = itemID[0].name;
                                item.prom_uom=itemID[0].uom_name;
                                item.prom_price=itemID[0].price;
                            }

                            modalScope.cancel = function() {
                                $uibModalInstance.close();
                            };
                            modalScope.ok = function() {
                                $uibModalInstance.close(modalScope.item.detail);
                            };
                            //getlistMaster
                            function getListPromotionLevel(){
                                promotionAPI.getListprogramLevel().then(function(res){
                                    try{
                                        modalScope.listMaster.promotionLevel = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListItem(){
                                promotionAPI.getListConditionRef().then(function(res){
                                    try{
                                        modalScope.listMaster.productList = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListPromoType(){
                                promotionAPI.getListPromoType().then(function(res){
                                    try{
                                        modalScope.listMaster.promoType = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListBundleRefer(){
                                promotionAPI.getListRefernceBundle().then(function(res){
                                    try{
                                        modalScope.listMaster.productListBundle = res.data.results;
                                    }catch(e){
                                        console.log(e);
                                    }
                                })
                              }
                              function getListLine(){
                                  productAPI.getListItemOption().then(function(res){
                                      try{
                                          modalScope.listMaster.productLine = res.data.results;
                                      }catch(e){
                                          console.log(e);
                                      }
                                  })
                              }

                        }
                    ],
                    size: 'lg'
                }).result.then(function(res) {
                   console.log(res)
                    })

            }

        }


    }
})();
