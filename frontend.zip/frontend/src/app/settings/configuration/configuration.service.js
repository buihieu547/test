(function () {
    'use strict';

    angular.module('app').service('configurationAPI', service);

    function service(API, $http) {

        this.getListUOM = getListUOM;
        this.postUOM = postUOM;
        this.updateUOM =updateUOM;
        this.getListShipmetMethodAll =getListShipmetMethodAll;
        this.getListShipment = getListShipment;
        this.postShipment =postShipment;
        this.getListTypeShipmentMethod = getListTypeShipmentMethod;
        this.getListCarrier = getListCarrier;


        this.getListItemById = getListItemById;
        this.createOrder = createOrder;
        this.getStatisticalOrder = getStatisticalOrder;
        this.approveOrd = approveOrd;
        this.cancelOrd = cancelOrd;
        this.sendEmail = sendEmail;
        this.getOrderNumber = getOrderNumber;
        this.generateSO= generateSO;
        this.getHistoryByCode =getHistoryByCode;
        this.getInvoice =getInvoice;

        /** Internal functions */
        // UOM
        function getListUOM(params){
            var url = 'uom';
            return API.get(url, params);
        }
        function postUOM(params){
            var url ='uom';
            return API.post(url,params);
        }
        function updateUOM(id,params){
            var url ='uom/'+id;
            return API.put(url,params);
        }

        // Shipment method
        function getListShipmetMethodAll(){
            var url ="shipment_method/all";
            return API.get(url);
        }
        function getListShipment(params){
            var url ='shipment_method';
            return API.get(url,params);
        }
        function postShipment(params){
            var url ='shipment_method';
            return API.post(url,params);
        }
        function updateShipment(id,params){
            var url ='shipment_method/'+id;
            return API.put(url,params);
        }

        //shipment method type
        function getListTypeShipmentMethod(){
            var url ="shipment_method_type/all";
            return API.get(url);
        }

        // carrier method

        function getListCarrier(){
            var url ='carrier/all';
            return API.get(url);
        }

        function getListItemById(params) {
            var url = 'product/list-product-to-order';
            return API.get(url, params);
        }
        function createOrder(params) {
            var url = 'order/create-order';
            return API.post(url, params);
        }
        function getOrderNumber(id){
             var url = ['order', 'generate-order-number',id].join('/');           
            return API.get(url);
        }

        function getStatisticalOrder(params) {
            var url = 'order/statistical-order';
            return API.get(url, params);
        }

        function approveOrd(ordId) {
            var url = 'order/approved/' + ordId;
            return API.put(url);
        }
        
        function cancelOrd(ordId) {
            var url = 'order/cancel/' + ordId;
            return API.put(url);
        }
        function sendEmail(params){
            var url ='order/sent-message';
            return API.put(url, params);
        }
        function generateSO(){
            var url ='order/get-order-code';
            return API.get(url);
        }
        function getHistoryByCode(code){
            var url ="order/history?order_cd="+code;
            return API.get(url);
        }
        function getInvoice(id){
            var url ="order/invoice/"+id;
            return API.get(url);
        }
    }
})();
