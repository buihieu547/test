

(function() {
    'use strict';

    angular
        .module('app')
        .controller('configuration.shipment-method.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $uibModal, API, configurationAPI, $localStorage, MessageService, hotkeys, $state,$timeout) {

        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.getList = getList;
        $scope.KeyShorcut = KeyShorcut;
        $scope.changeStatus = changeStatus;
        $scope.searchAction =searchAction;
        //  $scope.scrollToFilter =scrollToFilter;
        $scope.filter = filter;
        $scope.list = {
            items: [],
            search: {}
        };
        $scope.listType = [{
            id: '1',
            name: "Standard "
        }, {
            id: '2',
            name: "EXPEDITED"
        }];
        $scope.addNewItem = addNewItem;

        /** Internal functions */

        (function onInit() {
            getList();
            getListTypeMethod();
        })();
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            item.is_checked = !item.is_checked;
            $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
            $scope.selectedIndex = index;
        }
        function searchAction(search) {
            var params = $listController.getParams();
            angular.merge(params, search);
            $listController.searchAction(params);
        }   

        function getList() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            configurationAPI.getListShipment(params)
                .then(function(res) {
                    try {
                        $scope.list.items = res.data.results.rows;
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function getListTypeMethod(){
            configurationAPI.getListTypeShipmentMethod().then(function (res){
                try{
                    console.log(res);
                    $scope.listType = res.data.results;
                    
                }catch(e){
                    console.log(e);
                }
            })
        };
        // function 
        $scope.checkItem = function(item) {
            console.log(item)
            $scope.item_detail = item.id;
        }

        function updateStatus(orderNum) {
            var params = {
                orderNum: orderNum
            };
            API
                .put('order/update-status', params)
                .then(function(res) {
                    try {
                        getList();
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+n',
                description: 'Create New Sales order',
                callback: function(e) {
                    $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'enter',
                description: 'Go to  detail Sales order',
                callback: function(e) {
                    if ($scope.selectedIndex > -1) {
                        $scope.item_detail = $scope.list.items[$scope.selectedIndex].id;
                        $state.go('app.orders.detail', { id: $scope.item_detail })
                    }

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+s',
                description: 'Search',
                callback: function() {
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+r',
                description: 'Reset Search',
                callback: function() {
                    $scope.list.search = {};
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pagedown',
                description: 'Move to next page',
                callback: function(e) {
                    $scope.pagination.page++;
                    if ($scope.pagination.page > $scope.pagination.total_page) {
                        $scope.pagination.page = $scope.pagination.total_page;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pageup',
                description: 'Move to previous page',
                callback: function(e) {
                    $scope.pagination.page--;
                    if ($scope.pagination.page < 1) {
                        $scope.pagination.page = 1;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+end',
                description: 'Move to last page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = $scope.pagination.total_page;
                    $scope.changePage();

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+home',
                description: 'Move to first page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = 1;
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            // .add({
            //     combo: 'alt+shift+a',
            //     description: 'Filter Search',
            //     callback: function(e) {
            //         e.preventDefault();
            //         $scope.pagination.page = 1;
            //         $scope.scrollToFilter()
            //     },
            //     allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            // })

        function scrollToTable() {
            try {
                var top = document.getElementsByClassName("custom-table")[0].offsetTop - 100;
                $('html, body').animate({
                    scrollTop: top
                }, 500);
            } catch (e) {
                console.log(e)
            }
        }
        

        function filter(type) {
            $scope.list.search.sts = type;

            return $scope.searchAction($scope.list.search);
        }       
        $scope.dateOptions = {}
        $scope.upDateDateOption = function(key, min, max){
            $scope.dateOptions[key] = {
                showWeeks: false,
            }
            if(min) {
                $scope.dateOptions[key].minDate  = min; 
            }
            if(max) {
                $scope.dateOptions[key].maxDate  = max; 
            }
        };
        function addNewItem() {
            $uibModal.open({
                animation: true,
                templateUrl: 'app/settings/configuration/shipment.create.html',
                controller: ['$uibModalInstance',
                    '$scope',
                    'productAPI',
                    'hotkeys',
                    '$timeout',
                    function($uibModalInstance, modalScope, productAPI, hotkeys,$timeout) {
                        modalScope.shipment={}
                        modalScope.listReference={
                            'listType':[],
                            'listCarrier':[],
                            'listSync':[{value:true,name:'Yes'},{value:false,name:'No'}]
                        }
                        modalScope.getListTypeMethod = getListTypeMethod;
                        modalScope.getListCarrier = getListCarrier;

                        (function onInit() {
                            modalScope.getListTypeMethod();
                            modalScope.getListCarrier();
                        })();
                       
                        
                        // modal function
                        function getListTypeMethod(){
                            configurationAPI.getListTypeShipmentMethod().then(function (res){
                                try{
                                    console.log(res);
                                    modalScope.listReference.listType = res.data.results;
                                    
                                }catch(e){
                                    console.log(e);
                                }
                            })
                        };
                        function getListCarrier(){
                            configurationAPI.getListCarrier().then(function (res){
                                try{
                                    console.log(res);
                                    modalScope.listReference.listCarrier = res.data.results;
                                    
                                }catch(e){
                                    console.log(e);
                                }
                            })
                        };


                        /**
                         * KEY CONTROL
                         */
                        hotkeys.bindTo(modalScope)
                            .add({
                                combo: 'alt+a',
                                description: 'Select all items on page',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.isCheckAll = !modalScope.isCheckAll;
                                    checkAll();
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+pageup',
                                description: 'Move to next page',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.pagination.page++;
                                    if (modalScope.pagination.page > modalScope.pagination.total_page) {
                                        modalScope.pagination.page = modalScope.pagination.total_page;
                                        return;
                                    }
                                    modalScope.changePage();
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+pagedown',
                                description: 'Move to previous page',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.pagination.page--;
                                    if (modalScope.pagination.page < 1) {
                                        modalScope.pagination.page = 1;
                                        return;
                                    }
                                    modalScope.changePage();
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+end',
                                description: 'Move to last page',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.pagination.page = modalScope.pagination.total_page;
                                    modalScope.changePage();

                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+home',
                                description: 'Move to first page',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.pagination.page = 1;
                                    modalScope.changePage();
                                }
                            })
                            .add({
                                combo: 'alt+enter',
                                description: 'OK',
                                callback: function(e) {
                                    e.preventDefault();
                                    if(modalScope.list.checklist.length > 0)
                                    modalScope.ok();
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })

                        function KeyShorcut() {
                            hotkeys.toggleCheatSheet();
                        }

                        function activateTab(tab) {
                            $timeout(function() {
                                jQuery('#' + tab + 'Search').trigger('click');
                            })
                        };

                        hotkeys.bindTo(modalScope).add({
                                combo: 'alt+s',
                                description: 'Search data based on key',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.searchActionForList()
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+r',
                                description: 'Reset Search',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.resetAction()
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+shift+a',
                                description: 'Filter',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.searchActionForList()
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'alt+shift+r',
                                description: 'Reset Filter',
                                callback: function(e) {
                                    e.preventDefault();
                                    modalScope.resetAction(1)
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            })
                            .add({
                                combo: 'ctrl+1',
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                                description: 'Search by VIN',
                                callback: function(e) {
                                    e.preventDefault();
                                    setFocus(1);
                                    activateTab("vin");
                                }
                            })
                            .add({
                                combo: 'ctrl+3',
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                                description: 'Search by Part Number',
                                callback: function(e) {
                                    e.preventDefault();
                                    setFocus(3);
                                    activateTab("partNumber");
                                }
                            })
                            .add({
                                combo: 'ctrl+2',
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                                description: 'Search by Vehicle',
                                callback: function(e) {
                                    e.preventDefault();
                                    setFocus(2);
                                    activateTab("vehicle");
                                }
                            })
                            .add({
                                combo: 'ctrl+4',
                                description: 'Open Filter',
                                callback: function(e) {
                                    e.preventDefault();
                                    if (modalScope.list.items.length == 0) return;
                                    modalScope.focusFilter = true;
                                },
                                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
                            });

                        modalScope.modalTitle = "CREATE NEW SHIPMENT METHOD";

                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        };
                        modalScope.ok = function() {
                            $uibModalInstance.close(modalScope.shipment);
                        };                    

                    }
                ],
                size: 'md-2'
            }).result.then(function(res) {
                if(res){
                    console.log(res);
                var params = res;
                configurationAPI.postShipment(params).then(function(res){                    
                    try {
                        if (res.data._type === 'success') {
                            toastr.success(res.data.message);
                            $timeout(function() {
                               getList();
                            }, 500)

                        } else {
                            toastr.error(res.data.message);
                        }
                    } catch (e) {
                        console.log(e);
                    }
                });
                }
                
            });
        };
        function changeStatus(id, ac){
            var params ={'ac':ac};
            configurationAPI.updateShipment(id,params).then(function(res){
                try{
                    if(res.data._type ==='success'){
                        toastr.success(res.data.message);
                    }else{
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e);
                }
            })
        }

    
    }
})();