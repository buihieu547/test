
(function () {
    'use strict';

    angular.module('app').controller('setting.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $state,$stateParams, warehouseAPI) {

        var modal = document.getElementById('imageModal');
        var modalImg = document.getElementById("img01");
        var captionText = document.getElementById("caption");

        $scope.imageModal = function () {
            modal.style.display = "block";
            // modalImg.src = 'http://newschoolsaigon.com/publicimages/photos/0_1517685245.jpg';
             modalImg.src = './assets/img/Content/pim1.png';
            captionText.innerHTML = 'Priority Intergration Map';
        }

        $scope.closeImage = function () {
            modal.style.display = "none";
        }
    }
})();
