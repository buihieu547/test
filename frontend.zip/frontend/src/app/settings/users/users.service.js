
(function () {
    'use strict';

    angular.module('app').service('userAPI', service);

    function service(API) {

        this.getList = getList;


        /** Internal functions */

        function getList(params) {
            var url = ['user'].join('/');
            return API.get(url, params);
        }

    }
})();
