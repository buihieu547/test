
(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.settings', {
                url: '/settings',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.list', {
                url: '/settings/list',
                templateUrl: 'app/settings/setting.list.html',
                controller: 'setting.list.controller',
            })
            .state('app.settings.warehouse', {
                url: '/warehouse',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.warehouse.list', {
                url: '/list',
                templateUrl: 'app/settings/warehouse/settings.manage.warehouse.html',
                controller: 'manage.warehouse.list.controller',
                // middleware : ['auth', 'admin']
            })
            .state('app.settings.warehouse.create', {
                url: '/create',
                templateUrl: 'app/settings/warehouse/settings.manage.warehouse.create.html',
                controller: 'manage.warehouse.create.controller',
            })
            .state('app.settings.warehouse.edit', {
                url: '/:id',
                templateUrl: 'app/settings/warehouse/settings.manage.warehouse.create.html',
                controller: 'manage.warehouse.create.controller',
            })
            .state('app.settings.company', {
                url: '/company',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.company.list', {
                url: '/list',
                templateUrl: 'app/settings/company/settings.manage.company.html',
                controller: 'manage.company.list.controller',
                // middleware : ['auth', 'admin']
            })
            .state('app.settings.company.create', {
                url: '/create',
                templateUrl: 'app/settings/company/settings.manage.company.create.html',
                controller: 'manage.company.create.controller',
            })
            .state('app.settings.company.edit', {
                url: '/:id',
                templateUrl: 'app/settings/company/settings.manage.company.create.html',
                controller: 'manage.company.create.controller',
            })
            .state('app.settings.uom-setting', {
                url: '/uom-setting',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.uom-setting.list', {
                url: '/list',
                templateUrl: 'app/settings/configuration/configuration.uom-setting.html',
                controller: 'configuration.uom-setting.controller',
            })
            .state('app.settings.shipment-method', {
                url: '/shipment-method',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.shipment-method.list', {
                url: '/list',
                templateUrl: 'app/settings/configuration/configuration.shipment.html',
                controller: 'configuration.shipment-method.controller',
            })
            .state('app.settings.users', {
                url: '/users',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.settings.users.list', {
                url: '/list',
                templateUrl: 'app/settings/users/settings.manage.users.html',
                controller: 'manage.users.list.controller',
                // middleware : ['auth', 'admin']
            })

    }

})();
