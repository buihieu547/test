
(function () {
    'use strict';

    angular.module('app').controller('manage.company.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $state,$stateParams, companyAPI) {

        var $listController = $controller('abstract.list.controller',{ $scope : $scope });
        $scope.getList = getList; 
        $scope.resetAction = resetAction;
        $scope.createCompanyMaster =createCompanyMaster;
        $scope.list = {
            search : {},
            items : [],
            company : []
        };

        (function onInit() {
            getList();
           
        })();
        /** Internal functions */

        $scope.isNew = true; 

        function createCompanyMaster() {
            $state.go('app.settings.company.create');
        }

        if ($scope.isNew) {
            // categoryModal();
        } else {
            if ($stateParams.id) {
                $scope.isNew = false;
            }
        }

        function getList() {
            var params = $listController.getParams();
            companyAPI.getList(params).success(function (res) {
                try{
                    $scope.list.company = res.results.rows;
                    $listController.matchPagingOption(res.results);
                   
                }catch (e){
                    console.log(e.message);
                }

                console.log(res);
            });
        }

        function resetAction() {
            $scope.pagination.page = 1;
            $scope.list.search = {};
            return $scope.searchAction();
        }
    }
})();
