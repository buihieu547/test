(function () {
    'use strict';
    angular
        .module('app')
        .controller('manage.company.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,  companyAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},           
        };
        $scope.getListStateByCountry =getListStateByCountry;
       
        (function onInit() {
            getListCountry();
            
        })();
      
        $scope.cancelCompanyMaster= function(){
            $state.go("app.settings.company.list");
        }
        $scope.createCompanyMaster = function(){            
            var params = $scope.mainData.generalInfo;
            params.products = $scope.mainData.products;           
            companyAPI.createCompanyMaster(params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.settings.company.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }  
        function getListCountry(){
            companyAPI.getListCountry().then(function(res){
                $scope.listCountry = res.data.results;
            })
        }
        function getListStateByCountry(country_code) {
            var params = {
              country: country_code
            }
            companyAPI.getStateByCountry(params).then(function(res) {
              try {
                $scope.listState = res.data.results;
               
              } catch (e) {
                console.log(e);
              }
            })
          }
        

    }
})();
