
(function () {
    'use strict';

    angular.module('app').service('companyAPI', service);

    function service(API) {

        this.getList = getList;       
        this.createCompanyMaster = createCompanyMaster;        
        this.getListCountry =getListCountry;
        this.getStateByCountry =getStateByCountry;

        /** Internal functions */      

        function getList(params) {
            var url = ['company-master','index'].join('/');
            return API.get(url, params);
        }     

        function createCompanyMaster(params) {
            var url = ['company-master','create'].join('/');
            return API.post(url, params);
        }
       
        function getListCountry() {
            var url ='country/get-all';
            return API.get(url);           
        }
        function getStateByCountry( params) {
            var url = 'state/get-by-country'
            return API.get(url, params);
        }
    }
})();
