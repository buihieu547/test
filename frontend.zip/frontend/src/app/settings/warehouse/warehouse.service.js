
(function () {
    'use strict';

    angular.module('app').service('warehouseAPI', service);

    function service(API) {

        this.getList = getList;
        this.getWarehouse = getWarehouse;
        this.createWarehouse = createWarehouse;
        this.updateWarehouse = updateWarehouse;
        this.getWarehouseDetail = getWarehouseDetail;
        this.getListCountry =getListCountry;
        this.getStateByCountry =getStateByCountry;

        /** Internal functions */

        function getList(params) {
            var url = ['warehouse','index'].join('/');
            return API.get(url, params);
        }

        function getWarehouse() {
            var url = ['warehouse','get-all'].join('/');
            return API.get(url);
        }

        function getWarehouseDetail(id) {
            var url = ['warehouse','detail', id].join('/');
            return API.get(url);
        }

        function createWarehouse(params) {
            var url = ['warehouse','create'].join('/');
            return API.post(url, params);
        }

        function updateWarehouse(params, id) {
            var url = ['warehouse','update', id].join('/');
            return API.put(url, params);
        }
        function getListCountry() {
            var url ='country/get-all';
            return API.get(url);           
        }
        function getStateByCountry( params) {
            var url = 'state/get-by-country'
            return API.get(url, params);
        }
    }
})();
