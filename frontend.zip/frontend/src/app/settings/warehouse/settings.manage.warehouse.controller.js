
(function () {
    'use strict';

    angular.module('app').controller('manage.warehouse.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $state,$stateParams, warehouseAPI) {

        var $listController = $controller('abstract.list.controller',{ $scope : $scope });
        $scope.getList = getList;
        $scope.editAction = editAction;
        $scope.createWarehouse = createWarehouse;
        $scope.resetAction = resetAction;
        $scope.list = {
            search : {},
            items : [],
            warehouse : []
        };

        (function onInit() {
            getList();           
        })();
        /** Internal functions */

        $scope.isNew = true;       

        function editAction(id) {
            $state.go('app.settings.edit',{id:id});
        }

        function createWarehouse() {
            $state.go('app.settings.warehouse.create');
        }

        if ($scope.isNew) {
            // categoryModal();
        } else {
            if ($stateParams.id) {
                $scope.isNew = false;
            }
        }

        function getList() {
            var params = $listController.getParams();
            warehouseAPI.getList(params).success(function (res) {
                try{
                    $scope.list.warehouse = res.results.rows;                    
                    $listController.matchPagingOption(res.results);
                }catch (e){
                    console.log(e.message);
                }

                console.log(res);
            });
        }

        function resetAction() {
            $scope.pagination.page = 1;
            $scope.list.search = {};
            return $scope.searchAction();
        }
    }
})();
