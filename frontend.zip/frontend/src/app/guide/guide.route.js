(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.guide', {
                url: '/guide',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.guide.view', {
                url: '/view',
                templateUrl: 'app/guide/guide.view.html',
                controller: 'guide.view.controller',
            })
           
    }

})();
