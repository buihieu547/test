(function() {
    'use strict';

    angular.module('app').controller('guide.view.controller', controller);
    /** @ngInject */
    function controller($scope, productAPI, $rootScope, $state, envConfig) {

    } 
  

})();
