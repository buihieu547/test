(function () {
    angular
        .module('app')
        .directive('imageBind', [function () {
                return {
                    restrict: 'A',
                    require: '?ngModel',
                    link: function ($scope, element, attrs, controller) {
                        element
                            .bind("change", function (changeEvent) {
                                var fileCheck = [];
                                var widthCheck = 1600;
                                var heightCheck = 2048;
                                var imgSrcList = [];

                                function displayPreview(files) {
                                    var reader = new FileReader();
                                    var img = new Image();
                                    reader.onload = function (e) {
                                        img.src = e.target.result;
                                        imgSrcList.push(img.src)
                                        var li = document.createElement('li');
                                        li.innerHTML = ['<img class="thumb" src="', e.target.result, '"/>'].join('');
                                        document
                                            .getElementById('list')
                                            .insertBefore(li, null);
                                        img.onload = function () {};
                                    };
                                    reader.readAsDataURL(files);
                                    controller.$setViewValue(imgSrcList);
                                }

                                var files = [],
                                    fileOverSize = [],
                                    fileVideo = [];
                                for (var i = 0; i < element[0].files.length; i++) {
                                    files.push(element[0].files[i]);
                                    var fileName = element[0].files[i].name;
                                    var fileExtension = fileName
                                        .split('.')[
                                        fileName
                                            .split('.')
                                            .length - 1
                                    ]
                                        .toLowerCase();
                                    var fileSize = element[0].files[i].size;
                                    if (fileExtension === "jpg" || fileExtension === "jpeg" || fileExtension === "bmp" || fileExtension === "png") {
                                        if (fileSize > 1048576) {
                                            fileOverSize.push(element[0].files[i].name);
                                        }

                                    } else if (fileExtension === "mkv" || fileExtension === "mp4" || fileExtension === "avi" || fileExtension === "wmv" || fileExtension === "flv") {
                                        if (fileSize > 20971520) {
                                            fileVideo.push(element[0].files[i].name);
                                        }
                                    } else {
                                        return;
                                    }
                                }
                                if (attrs.multiple) {
                                    if (files.length == 0) {
                                        flash.error = 'Images 360 must have 36 files';
                                        return;
                                    } else {
                                        if (fileOverSize.length > 0) {
                                            flash.error = fileOverSize + ' - File size must under 1MB!';
                                            var nameInput = attrs.name;
                                            return;
                                        } else {
                                            for (var i = 0; i < element[0].files.length; i++) {
                                                displayPreview(element[0].files[i]);

                                            }

                                        }
                                    }
                                } else {
                                    if (fileVideo.length > 0) {
                                        flash.error = fileVideo + ' - File size must under 10MB!';
                                        var nameInput = attrs.name;
                                        return;

                                    }
                                    if (fileOverSize.length > 0) {
                                        flash.error = fileOverSize + ' - File size must under 1MB!';
                                        var nameInput = attrs.name;
                                        return;

                                    } else {
                                        for (var i = 0; i < element[0].files.length; i++) {
                                            displayPreview(element[0].files[i]);

                                        }
                                    }
                                }
                                $scope
                                    .$apply(function () {
                                        controller.$setViewValue(files);
                                        console.log(files)
                                    });

                            });
                    }

                };
            }
        ])
        .directive('multipleEmails', function () {
      return {
        require: 'ngModel',
        link: function(scope, element, attrs, ctrl) {
          ctrl.$parsers.unshift(function(viewValue) {

                var emails = viewValue.split(',');
            (emails)
            // define single email validator here
            var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;

            // angular.foreach(emails, function() {
              var validityArr = emails.map(function(str){
                  return re.test(str.trim());
              }); // sample return is [true, true, true, false, false, false]
              var atLeastOneInvalid = false;
              angular.forEach(validityArr, function(value) {
                if(value === false)
                  atLeastOneInvalid = true;
              });
              if(!atLeastOneInvalid) {
                // ^ all I need is to call the angular email checker here, I think.
                ctrl.$setValidity('multipleEmails', true);
                return viewValue;
              } else {
                ctrl.$setValidity('multipleEmails', false);
                return undefined;
              }
            // })
          });
        }
      };
    })
    .directive('format', ['$filter', function ($filter) {
    return {
        require: '?ngModel',
        link: function (scope, elem, attrs, ctrl) {
            if (!ctrl) return;

            ctrl.$formatters.unshift(function (a) {
                return $filter(attrs.format)(ctrl.$modelValue)
            });

            elem.bind('change', function(event) {
                var plainNumber = elem.val().replace(/[^0-9.]/g, '');
                elem.val($filter(attrs.format)(plainNumber));
            });
        }
    };
}])
    .directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^.0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }

                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })
    .directive('numbersInt', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }

                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })
     .directive('numbersText',['$parse', function ($parse) {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^-a-zA-Z0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }

                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    }])
     .directive('capitalize',['$parse', function($parse) {
    return {
        require: 'ngModel',
      link: function(scope, element, attrs, modelCtrl) {
        var capitalize = function(inputValue) {            
          if (inputValue == undefined) inputValue = '';
          var capitalized = inputValue.toUpperCase();
          if (capitalized !== inputValue) {
            modelCtrl.$setViewValue(capitalized);
            modelCtrl.$render();
          }
          return capitalized;
        }
        if(modelCtrl) modelCtrl.$parsers.push(capitalize);
        capitalize(scope[attrs.ngModel]); // capitalize initial value
      }
    };
      } ])
    .directive('disCount', function(){
        return {
            require: 'ngModel',
            restrict: 'ACE',
            link: function(scope, element, attrs, ngModelCtrl) {
                function fromUser(inputValue) {
                    if (inputValue) {
                        var transformedInput = inputValue;
                        var min = parseInt(attrs.minvalue);
                        var max = parseInt(attrs.maxvalue);
                        if (transformedInput != inputValue ||
                            transformedInput < min ||
                            transformedInput > max) {
                            if (transformedInput < min || transformedInput > max) {
                                transformedInput = transformedInput.substring(0, transformedInput.length - 1);
                            }
                            else {
                                transformedInput;
                            }

                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }

                        return transformedInput;
                    }
                    return undefined;
                }




                ngModelCtrl.$parsers.push(fromUser);

            }
        }
    })
    .directive('decimalOnly', ['$filter',function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'ACE',
            link: function (scope, attr, element, ngModelCtrl) {

                if (!ngModelCtrl) {
                    return;
                }
                 ngModelCtrl.$formatters.unshift(function (a) {
                return $filter('currency')(ngModelCtrl.$modelValue)
                    });


                ngModelCtrl.$parsers.push(function (val) {
                    if (angular.isUndefined(val)) {
                        var val = '';
                    }
                    var clean = val.replace(/[^0-9.]/g, '');
                    var decimalCheck = clean.split('.');
                    if (!angular.isUndefined(decimalCheck[1])) {
                        decimalCheck[1] = decimalCheck[1].slice(0, 2);
                        clean = decimalCheck[0] + '.' + decimalCheck[1];
                    }
                    if (val !== clean) {
                        ngModelCtrl.$setViewValue($filter('currency')(clean));
                        ngModelCtrl.$render();
                    }
                    return $filter('currency')(clean);
                });
                // element.bind('keypress', function (event) {
                //     if (event.keyCode === 32) {
                //         event.preventDefault();
                //     }
                // });
            }
        }
    }])
    .directive('decimalNumber', ['$filter',function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'ACE',
            link: function (scope, attr, element, ngModelCtrl) {

                if (!ngModelCtrl) {
                    return;
                }
                 ngModelCtrl.$formatters.unshift(function (a) {
                return $filter('number')(ngModelCtrl.$modelValue)
                    });


                ngModelCtrl.$parsers.push(function (val) {
                    if (angular.isUndefined(val)) {
                        var val = '';
                    }
                    var clean = val.replace(/[^0-9.]/g, '');
                    var decimalCheck = clean.split('.');
                    if (!angular.isUndefined(decimalCheck[1])) {
                        decimalCheck[1] = decimalCheck[1].slice(0, 2);
                        clean = decimalCheck[0] + '.' + decimalCheck[1];
                    }
                    if (val !== clean) {
                        ngModelCtrl.$setViewValue($filter('number')(clean));
                        ngModelCtrl.$render();
                    }
                    return $filter('number')(clean);
                });
                // element.bind('keypress', function (event) {
                //     if (event.keyCode === 32) {
                //         event.preventDefault();
                //     }
                // });
            }
        }
    }])
    .directive('numberMask', ['$filter',function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'ACE',
            link: function (scope, attr, element, ngModelCtrl) {

                if (!ngModelCtrl) {
                    return;
                }
                 ngModelCtrl.$formatters.unshift(function (a) {
                return $filter('number')(ngModelCtrl.$modelValue, scope.numberMask || 2)
                    });


                ngModelCtrl.$parsers.push(function (val) {
                    if (angular.isUndefined(val)) {
                        var val = '';
                    }
                    var clean = val.replace(/[^0-9.]/g, '');
                    var decimalCheck = clean.split('.');
                    if (!angular.isUndefined(decimalCheck[1])) {
                        decimalCheck[1] = decimalCheck[1].slice(0, 2);
                        clean = decimalCheck[0] + '.' + decimalCheck[1];
                    }
                    if (val !== clean) {
                        ngModelCtrl.$setViewValue($filter('number')(clean, scope.numberMask || 2));
                        ngModelCtrl.$render();
                    }
                    return $filter('number')(clean, scope.numberMask || 2);
                });
                // element.bind('keypress', function (event) {
                //     if (event.keyCode === 32) {
                //         event.preventDefault();
                //     }
                // });
            }
        }
    }])
})();
