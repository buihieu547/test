(function(){
    'use strict';

    angular.module('app').filter('trustAsUrl',filter);

    /** @ngInject **/
    function filter($sce){
        return function(input){
            return $sce.trustAsResourceUrl(input);
        }
    }
})();