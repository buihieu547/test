(function(){
    'use strict';

    angular.module('app').filter('trustAsHtml',filter);

    /** @ngInject **/
    function filter($sce){
        return function(input){
            return $sce.trustAsHtml(input);
        }
    }
})();