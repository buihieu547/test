


(function(){
    angular.module('app').filter('dateFormat',filter);

    /** @ngInject **/
    function filter(){
        return function(date,format){
            var localTimezone = moment().utcOffset();

            if(date)
            {
                date = [date,'+0000'].join(' ');
                var format = format || 'MM/DD/YYYY HH:mm:ss';
                var _format = [format,'Z'].join(' ');
            }

            var _parse = moment(date,_format).utcOffset(localTimezone).format(format);
            return _parse;
        }
    }
})();