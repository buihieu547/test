(function(){
    'use strict';

    angular.module('app').filter('sizeFormat',[function(){
        return function(size) {
            if(!size || size <= 0) return '';
            var size = parseInt(size);

            var i = Math.floor( Math.log(size) / Math.log(1024) );
            return ( size / Math.pow(1024, i) ).toFixed(1) * 1 + ' '+ ['B', 'KB', 'MB', 'GB', 'TB'][i];
        };
    }]);
})();