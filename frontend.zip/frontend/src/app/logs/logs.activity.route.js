(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider) {

        $stateProvider
            .state('app.logs.activity', {
                url: '/log/activity',
                templateUrl: 'app/logs/logs.activity.html',
                controller : 'logs.activity.controller',               
            })

    }

})();
