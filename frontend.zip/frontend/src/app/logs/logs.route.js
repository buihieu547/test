(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider) {

        $stateProvider
            .state('app.logs', {
                url: '/logs',
                template: '<ui-view></ui-view>',
                abstract: true,		       
            })

    }

})();
