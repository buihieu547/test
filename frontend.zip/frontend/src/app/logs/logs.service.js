(function () {
    'use strict';

    angular.module('app').service('logAPI', service);

    function service(API, $http) {

        this.getLogs = getLogs;

        function getLogs(params) {
            var url = 'log/activity?sort=desc';
            return API.get(url, params);
        }
    }
})();