(function () {
    'use strict';

    angular.module('app').controller('logs.activity.controller',controller);

    /** @ngInject */
    function controller($scope, $controller, logAPI, hotkeys) {
        var $listController = $controller('abstract.list.controller', {$scope: $scope});
        $scope.getList = getList;
        $scope.resetAction =resetAction;
        $scope.KeyShorcut =KeyShorcut;

        $scope.list = {
            items : [],
            search: {}
        };

        (function onInit() {
            getList();
            $scope.focusMe = true;
        })();
          function resetAction() {
            $scope.pagination.page = 1;
            $scope.list.search = {};
            return $scope.searchAction();
        }


        function getList() {
            var params = $listController.getParams();
            logAPI.getLogs(params).success(function (res) {
                try {
                    $scope.list.items = res.results.rows;
                    $listController.matchPagingOption(res.results);
                } catch(e) {
                    console.log(e);
                }
            });
        }
        $scope.dateOptions = {}
        $scope.upDateDateOption = function(key, min, max){
            $scope.dateOptions[key] = {
                showWeeks: false,
            }
            if(min) {
                $scope.dateOptions[key].minDate  = min; 
            }
            if(max) {
                $scope.dateOptions[key].maxDate  = max; 
            }
        };
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys.bindTo($scope)  
        .add({
            combo: 'alt+pageup',
            description: 'Move to next page',
            callback: function(e) {
                $scope.pagination.page++;
                if ($scope.pagination.page > $scope.pagination.total_page) {
                    $scope.pagination.page = $scope.pagination.total_page;
                    return;
                }
                $scope.changePage();
            }
        })
        .add({
            combo: 'alt+pagedown',
            description: 'Move to previous page',
            callback: function(e) {
                $scope.pagination.page--;
                if ($scope.pagination.page < 1) {
                    $scope.pagination.page = 1;
                    return;
                }
                $scope.changePage();
            }
        })
        .add({
            combo: 'alt+end',
            description: 'Move to last page',
            callback: function(e) {
                e.preventDefault();
                $scope.pagination.page = $scope.pagination.total_page;
                $scope.changePage();

            }
        })
        .add({
            combo: 'alt+home',
            description: 'Move to first page',
            callback: function(e) {
                e.preventDefault();
                $scope.pagination.page = 1;
                $scope.changePage();
            }
        })
        .add({
            combo: 'alt+s',
            description: 'Search data based on key',
            callback: function(e) {
                e.preventDefault();
                $scope.searchAction();
            },
            allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        .add({
            combo: 'alt+r',
            description: 'Reset Search',
            callback: function(e) {
                e.preventDefault();
                $scope.resetAction()
            },
            allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        
    }
})();
