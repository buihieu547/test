(function () {
    'use strict';

    angular.module('app').controller('reports.order_history.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, reportAPI, $localStorage) {
        var $listController = $controller('abstract.list.controller',{ $scope : $scope });
        $scope.resetAction = resetAction;
        $scope.getList = getList;
        $scope.list = {
            search : {},
            orders_his: [],
        };

        (function onInit() {
            getList();
        })();

        function resetAction() {
            $scope.pagination.page = 1;
            $scope.list.search = {};
            return $scope.searchAction();
        }

        function getList() {
            var params = $listController.getParams();
            params['brand_id']= $localStorage.BRAND.id;
            reportAPI.getOrdHistory(params).success(function (res) {
                try{
                    $scope.list.orders_his = res.results.rows;
                    $listController.matchPagingOption(res.results);
                }catch (e){
                    console.log(e.message);
                }

                console.log(res);
            });
        }
    }
})();
