(function () {
    'use strict';

    angular.module('app').service('reportAPI', service);

    function service(API) {

        this.getListPart      = getListPart;
        this.getListRepair    = getListRepair;
        this.getListRMA       = getListRMA;
        this.getCategorySold  = getCategorySold;
        this.getListCategory  = getListCategory;
        this.getListSaleOrder = getListSaleOrder;


        /** Internal functions */

        function getListPart(params) {
            var url = ['reports','top-selling-parts'].join('/');
            return API.get(url, params);
        }

        function getListRepair(params) {
            var url = ['reports','top-selling-repair-shop'].join('/');
            return API.get(url, params);
        }

        function getListRMA(params) {
            var url = ['reports','rma-status-report'].join('/');
            return API.get(url, params);
        }

        function getCategorySold(params) {
            var url = ['reports','top-category-sold-report'].join('/');
            return API.get(url, params);
        }

        function getListCategory() {
            var url = ['reference','category'].join('/');
            return API.get(url);
        }

        function getListSaleOrder(params) {
            var url = ['reports','sale-order-status-report'].join('/');
            return API.get(url, params);
        }

    }
})();
