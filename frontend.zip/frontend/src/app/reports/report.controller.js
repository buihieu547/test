(function() {
  'use strict';

  angular.module('app').controller('reports.manage.controller', manageController);
  angular.module('app').controller('reports.managePart.controller', managePartController);
  angular.module('app').controller('reports.manageRepair.controller', manageRepairController);
  angular.module('app').controller('reports.manageRMA.controller', manageRMAController);
  angular.module('app').controller('reports.manageSale.controller', manageSale);
  angular.module('app').controller('reports.manageCategory.controller', manageCategory);

  angular.module('app').config(function (ChartJsProvider) {
  // Configure all charts
  ChartJsProvider.setOptions({
    // colors: ['#2f38ed', '#7f4c4c', '#d13e42', '#16afad', '#d88015', '#3b4c68', '#257a06']
  });
});

  /** @ngInject */
  function manageController($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {
    $scope.KeyShorcut  = KeyShorcut;
    function KeyShorcut() {
        hotkeys.toggleCheatSheet();
    }
    $scope.dateOptions = {}
    $scope.upDateDateOption = function(key, min, max){
        $scope.dateOptions[key] = {
            showWeeks: false,
        }
        if(min) {
            $scope.dateOptions[key].minDate  = min;
        }
        if(max) {
            $scope.dateOptions[key].maxDate  = max;
        }
    };
  };

  function managePartController($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {

     $scope.search       = {};
     $scope.list         = [];
     $scope.changeDate   = changeDate;
     $scope.submitDate   = submitDate;
     $scope.drawBarChart = drawBarChart;

     $scope.filterDate   = [{id: 1, name: 'Week'},{id: 2, name: 'Month'},{id: 3, name: 'Year'}, {id: 4, name: 'Date Range'}];
     $scope.topRank      = [5, 10, 15];


     function changeDate(id) {
         var d = new Date();
         if (id != 4 && id != null && id != '' && id != undefined) {
           switch (id) {
             case 1:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 7);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
             case 2:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 30);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
             case 3:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 365);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
           }

         } else {
           $scope.search.to_date = '';
           $scope.search.from_date = '';

         }
       }

    function submitDate() {
      var params = {};

          params.to_date   = $scope.search.to_date;
          params.from_date = $scope.search.from_date;
          params.length    = $scope.search.length;

       reportAPI.getListPart(params).then(function(res) {
           try {
             if(res.data.results.length > 0) {
               $scope.list = res.data.results;
               $scope.drawBarChart(res.data.results);
             }
           } catch(e) {

           }
       })
    }


    function drawBarChart(res) {
      var labels = [], data = [];
      for (var i = 0; i < res.length; i ++) {
         labels.push(res[i].sku);
         data.push(res[i].total_qty);
       }
      $scope.options = {
          legend: { display: true },
          title: { display: true, text: 'Top Selling Part Chart' },
          scales: {
          yAxes: [
              {
                id: 'y-axis-1',
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                    //  stepSize: 1,
                     beginAtZero: true
                   }
              }
            ]
          }};
      $scope.series  = ['Total Sold Quantity'];
      $scope.labels  = labels;
      $scope.data    = [data];
      $scope.colors = [
        { // green
          backgroundColor: 'rgb(0%, 46%, 0%)',
          pointBackgroundColor: 'rgb(0%, 46%, 0%)',
          pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
          borderColor: 'rgb(0%, 46%, 0%)',
          pointBorderColor: '#fff',
          pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
        }
        ];

    }


  };

  function manageRepairController($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {

    $scope.search      = {};
    $scope.list        = [];
    $scope.changeDate  = changeDate;
    $scope.submitDate  = submitDate;
    $scope.drawBarChart = drawBarChart;

    $scope.filterDate  = [{id: 1, name: 'Week'},{id: 2, name: 'Month'},{id: 3, name: 'Year'}, {id: 4, name: 'Date Range'}];
    $scope.topRank     = [5, 10, 15];


    function changeDate(id) {
        var d = new Date();
        if (id != 4 && id != null && id != '' && id != undefined) {
          switch (id) {
            case 1:
              $scope.search.to_date = d.toISOString().slice(0, 10);
              d.setDate(d.getDate() - 7);
              $scope.search.from_date = d.toISOString().slice(0, 10);
              break;
            case 2:
              $scope.search.to_date = d.toISOString().slice(0, 10);
              d.setDate(d.getDate() - 30);
              $scope.search.from_date = d.toISOString().slice(0, 10);
              break;
            case 3:
              $scope.search.to_date = d.toISOString().slice(0, 10);
              d.setDate(d.getDate() - 365);
              $scope.search.from_date = d.toISOString().slice(0, 10);
              break;
          }

        } else {
          $scope.search.to_date = '';
          $scope.search.from_date = '';

        }
      }

   function submitDate() {
     var params = {};

         params.to_date   = $scope.search.to_date;
         params.from_date = $scope.search.from_date;
         params.length    = $scope.search.length;

      reportAPI.getListRepair(params).then(function(res) {
          try {
            if(res.data.results.length > 0) {
                 $scope.list = res.data.results;
                $scope.drawBarChart(res.data.results);
            }
          } catch(e) {

          }
      })
   }

   function drawBarChart(res) {

     var labels = [], data = [], dataSet = [];
     for (var i = 0; i < res.length; i ++) {
       labels.push(res[i].buyer_name);
        data.push(res[i].total_ordered);
        dataSet.push( res[i].total_revenue)
      }
     $scope.options = {
       legend: { display: true },
       title: { display: true, text: 'Top Selling Repair Shop Chart' },
       scales: {
       yAxes: [
           {
             id: 'y-axis-1',
             type: 'linear',
             display: true,
             position: 'left',
             ticks: {
                  stepSize: 1,
                  beginAtZero: true
                }
           },
           {
             id: 'y-axis-2',
             type: 'linear',
             display: true,
             position: 'right',
             ticks: {
                //   stepSize: 1,
                  callback: function(value, index, values) {
                     return '$' + value;
                 },
                 beginAtZero: true,
                 min: 0
            },
            scaleLabel: {
              display: true,
            //   labelString: 'sdgsdfg'
            }
           }
         ],
         xAxes: [{
          display: true,
          ticks: {
            // stepSize: 2
          }
        }]
       }
     };
     $scope.series = ['Total sales orders', 'Total Revenues $'];
     $scope.labels = labels;
     $scope.data = [data, dataSet];
     $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
     $scope.colors = [
       { // green
         backgroundColor: 'rgb(0%, 46%, 0%)',
         pointBackgroundColor: 'rgb(0%, 46%, 0%)',
         pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
         borderColor: 'rgb(0%, 46%, 0%)',
         pointBorderColor: '#fff',
         pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
       },
       { // blue
         backgroundColor: 'rgb(2%, 85%, 92%)',
         pointBackgroundColor: 'rgb(2%, 85%, 92%)',
         pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
         borderColor: 'rgb(2%, 85%, 92%)',
         pointBorderColor: '#fff',
         pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
       }
     ];

   }

  };

  function manageRMAController($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {
      $scope.search       = {};
      $scope.list         = [];
      $scope.changeDate   = changeDate;
      $scope.submitDate   = submitDate;
      $scope.drawPieChart = drawPieChart;

      $scope.filterDate   = [{id: 1, name: 'Week'},{id: 2, name: 'Month'},{id: 3, name: 'Year'}, {id: 4, name: 'Date Range'}];


      function changeDate(id) {
          var d = new Date();
          if (id != 4 && id != null && id != '' && id != undefined) {
            switch (id) {
              case 1:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 7);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
              case 2:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 30);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
              case 3:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 365);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
            }

          } else {
            $scope.search.to_date = '';
            $scope.search.from_date = '';

          }
        }

     function submitDate() {
       var params = {};

           params.to_date   = $scope.search.to_date;
           params.from_date = $scope.search.from_date;

        reportAPI.getListRMA(params).then(function(res) {
            try {
              if(res.data.results.length > 0) {
                $scope.list = res.data.results;
                $scope.drawPieChart(res.data.results);
              }
            } catch(e) {

            }
        })
     }


     function drawPieChart(res) {
       var labels = [], data = [];
       for (var i = 0; i < res.length; i ++) {
          labels.push(res[i].status_label);
          data.push(res[i].total_rma);
        }
       $scope.options = {
           legend: { display: true },
           title: { display: true, text: 'RMA Status Chart' }
       };
       $scope.labels  = labels;
       $scope.data    = data;
       $scope.colors = [
         { // green
           backgroundColor: 'rgb(0%, 46%, 0%)',
           pointBackgroundColor: 'rgb(0%, 46%, 0%)',
           pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
           borderColor: 'rgb(0%, 46%, 0%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
         },
         { // blue
           backgroundColor: 'rgb(2%, 85%, 92%)',
           pointBackgroundColor: 'rgb(2%, 85%, 92%)',
           pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
           borderColor: 'rgb(2%, 85%, 92%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
       },
       { // orange
         backgroundColor: 'rgb(100%, 28%, 10%)',
         pointBackgroundColor: 'rgb(100%, 28%, 10%)',
         pointHoverBackgroundColor: 'rgb(100%, 28%, 10%)',
         borderColor: 'rgb(100%, 28%, 10%)',
         pointBorderColor: '#fff',
         pointHoverBorderColor: 'rgb(100%, 28%, 10%)'
       }
         ];



     }
  };


  function manageSale($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {
      $scope.search       = {};
      $scope.list         = [];
      $scope.changeDate   = changeDate;
      $scope.submitDate   = submitDate;
      $scope.drawPieChart = drawPieChart;

      $scope.filterDate   = [{id: 1, name: 'Week'},{id: 2, name: 'Month'},{id: 3, name: 'Year'}, {id: 4, name: 'Date Range'}];


      function changeDate(id) {
          var d = new Date();
          if (id != 4 && id != null && id != '' && id != undefined) {
            switch (id) {
              case 1:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 7);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
              case 2:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 30);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
              case 3:
                $scope.search.to_date = d.toISOString().slice(0, 10);
                d.setDate(d.getDate() - 365);
                $scope.search.from_date = d.toISOString().slice(0, 10);
                break;
            }

          } else {
            $scope.search.to_date = '';
            $scope.search.from_date = '';

          }
        }

     function submitDate() {
       var params = {};

           params.to_date   = $scope.search.to_date;
           params.from_date = $scope.search.from_date;

        reportAPI.getListSaleOrder(params).then(function(res) {
            try {
              if(res.data.results.length > 0) {
                $scope.list = res.data.results;
                $scope.drawPieChart(res.data.results);
              }
            } catch(e) {

            }
        })
     }


     function drawPieChart(res) {
       var labels = [], data = [];
       for (var i = 0; i < res.length; i ++) {
          labels.push(res[i].status_label);
          data.push(res[i].total_order);
        }

       $scope.options = {
           legend: { display: true },
           title: { display: true, text: 'Sale Order Status Chart' }
       };
       $scope.labels  = labels;
       $scope.data    = data;
       $scope.colors = [
         { // green
           backgroundColor: 'rgb(0%, 46%, 0%)',
           pointBackgroundColor: 'rgb(0%, 46%, 0%)',
           pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
           borderColor: 'rgb(0%, 46%, 0%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
         },
         { // blue
           backgroundColor: 'rgb(2%, 85%, 92%)',
           pointBackgroundColor: 'rgb(2%, 85%, 92%)',
           pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
           borderColor: 'rgb(2%, 85%, 92%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
       },
       { // orange
         backgroundColor: 'rgb(100%, 28%, 10%)',
         pointBackgroundColor: 'rgb(100%, 28%, 10%)',
         pointHoverBackgroundColor: 'rgb(100%, 28%, 10%)',
         borderColor: 'rgb(100%, 28%, 10%)',
         pointBorderColor: '#fff',
         pointHoverBorderColor: 'rgb(100%, 28%, 10%)'
       }
         ];



     }
  };


  function manageCategory($scope, $controller, $timeout, reportAPI, $state, $localStorage, hotkeys) {

     $scope.search          = {};
     $scope.list            = [];
     $scope.listCategory    = [];
     $scope.changeDate      = changeDate;
     $scope.submitDate      = submitDate;
     $scope.drawBarChart    = drawBarChart;
     $scope.getListCategory = getListCategory;

     $scope.filterDate   = [{id: 1, name: 'Week'},{id: 2, name: 'Month'},{id: 3, name: 'Year'}, {id: 4, name: 'Date Range'}];
     $scope.topRank      = [5, 10, 15];


     (function onInit() {
         $scope.getListCategory();
     })();

     function getListCategory() {
         reportAPI.getListCategory().then(function(res) {
             try {
               if(res.data.results.length > 0) {
                 $scope.listCategory = res.data.results;
               }
             } catch(e) {

             }
         })
     }


     function changeDate(id) {
         var d = new Date();
         if (id != 4 && id != null && id != '' && id != undefined) {
           switch (id) {
             case 1:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 7);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
             case 2:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 30);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
             case 3:
               $scope.search.to_date = d.toISOString().slice(0, 10);
               d.setDate(d.getDate() - 365);
               $scope.search.from_date = d.toISOString().slice(0, 10);
               break;
           }

         } else {
           $scope.search.to_date = '';
           $scope.search.from_date = '';

         }
       }

    function submitDate() {
      var params = {};

          params.to_date      = $scope.search.to_date;
          params.from_date    = $scope.search.from_date;
          params.length       = $scope.search.length;
          params.category_id  = $scope.search.category_id;

       reportAPI.getCategorySold(params).then(function(res) {
           try {
             if(res.data.results.length > 0) {
               $scope.list = res.data.results;
               $scope.drawBarChart(res.data.results);
             }
           } catch(e) {

           }
       })
    }


    function drawBarChart(res) {
      var labels = [], data = [];
      for (var i = 0; i < res.length; i ++) {
         labels.push(res[i].brand_name);
         data.push(res[i].total_qty);
       }
      $scope.options = {
          legend: { display: true },
          title: { display: true, text: 'Top Category Sold Report Chart' },
          scales: {
          yAxes: [
              {
                id: 'y-axis-1',
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                     stepSize: 1,
                     beginAtZero: true
                   }
              }
            ]
          }};
      $scope.series  = ['Total Category sold'];
      $scope.labels  = labels;
      $scope.data    = [data];
      $scope.colors = [
        { // green
          backgroundColor: 'rgb(0%, 46%, 0%)',
          pointBackgroundColor: 'rgb(0%, 46%, 0%)',
          pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
          borderColor: 'rgb(0%, 46%, 0%)',
          pointBorderColor: '#fff',
          pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
        }
        ];

    }


  };


})();
