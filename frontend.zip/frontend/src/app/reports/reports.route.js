(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.reports', {
                url: '/reports',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.reports.manage', {
                url: '/manage',
                templateUrl: 'app/reports/report.html',
                controller: 'reports.manage.controller',
                // middleware : ['auth', 'manager_salesman']
            })

    }

})();
