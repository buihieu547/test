(function () {
    'use strict';

    angular.module('app')
        .config(['ChartJsProvider', function (ChartJsProvider) {
            ChartJsProvider.setOptions({
                colours: [
                    {"fillColor": "rgba(224, 108, 112, 1)"}
                ],
                responsive: false,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            userCallback: function(label, index, labels) {
                                if (Math.floor(label) === label) {
                                    return label;
                                }

                            },
                        }
                    }]
                },
                data: [{
                    click: function (e) {
                    }
                }]
            });
        }])

    angular.module('app').controller('reports.order_status.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, reportAPI, $localStorage, moment) {
        var $listController = $controller('abstract.list.controller',{ $scope : $scope });

        $scope.getList = getList;
        $scope.clickBar = clickBar;
        $scope.resetAction = resetAction;
        $scope.list = {
            search : {},
            orders: [],
            statuses: [],
        };
         

        (function onInit() {
            getList();
            getStatus();
        })();

        $scope.labels = [];
        $scope.data = [3, 4, 5, 7];
        $scope.colors = [];
        $scope.colorsStatus = {
            new:'#70b9eb',
            pending:'#646464',
            'in progress': '#f3b760',
            partial: '#a48ad4',
            shipped:'#46c37b',
            canceled: '#d26a5c',
        }

        $scope.dataChart = {};
        function clickBar(e) {
            console.log(e);
            var barLabel = e[0]['_model']['label'];

            $scope.list.statuses.forEach(function (sts) {
               
                if(sts.name.toLowerCase() == barLabel.toLowerCase()) {
                    $scope.list.search.status = sts.id;
                    $scope.searchAction($scope.list.search);
                }
            })
        }
        function getList() {
            var params = $listController.getParams();
            params['brand_id']= $localStorage.BRAND.id;
            reportAPI.getAllSts(params).success(function (res) {
                try{
                    $scope.dataChart = res.results.dataChart;
                    $scope.labels = dataChartMapTo('name');
                    $scope.data = dataChartMapTo('value');
                    $scope.list.orders = res.results.data.rows;
                    $scope.colors = arrangeColorOnStatus();
                    
                    $listController.matchPagingOption(res.results.data);
                }catch (e){
                    console.log(e.message);
                }

                console.log(res);
            });
        }

        function dataChartMapTo(nameProp) {
            var attArrName = [];
            attArrName = $scope.dataChart.map(function (obj) {
                return obj[nameProp]
            })
            return attArrName;
        }

        function arrangeColorOnStatus() {
            var attArrName = [];
            var labelClrs = Object.keys($scope.colorsStatus);

            // $scope.labels = labelClrs;
            for(var i in $scope.labels) {
                var label = $scope.labels[i];
                var lower = label.toString().toLowerCase();
                attArrName.push($scope.colorsStatus[lower]);
            }

            return attArrName;
        }

        function _swap(json){
            var ret = {};
            for(var key in json){
                ret[json[key]] = key;
            }
            return ret;
        }

        function getStatus() {
            var params = $listController.getParams();
            reportAPI.getOrdSts(params).success(function (res) {
                try{
                    console.log('res', res)
                    $scope.list.statuses = res.results;
                    console.log('res', $scope.statuses)
                }catch (e){
                    console.log(e.message);
                }

                console.log(res);
            });
        }

        function getBrand() {
            productAPI.getBrand().then(function(res){
                try {
                    $scope.brands = res.data.results;
                } catch (error) {
                    console.log(error);
                }
            }, function(err) {
                toastr.error(err.data.message);
            });
        }

        function resetAction() {
            $scope.pagination.page = 1;
            $scope.list.search = {};
            return $scope.searchAction();
        }
       

    }
})();
