(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.products', {
                url: '/products',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.item', {
                url: '/products',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.item.create', {
                url: '/create',
                templateUrl: 'app/products/products.create.html',
                controller: 'products.create.controller',

            })
            .state('app.products.item.manage', {
                url: '/manage',
                templateUrl: 'app/products/products.manage.html',
                controller: 'products.manage.controller',
            })
            .state('app.products.item.detail', {
                url: '/detail/:id',
                templateUrl: 'app/products/products.detail.html',
                controller: 'products.detail.controller',
            })
            .state('app.products.bundle', {
                url: '/bundle',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.bundle.list', {
                url: '/list',
                templateUrl: 'app/products/promotions.bundle.html',
                controller: 'promotions.bundle.controller',
            })
            .state('app.products.bundle.create', {
                url: '/create',
                templateUrl: 'app/products/bundle.create.html',
                controller: 'bundle.create.controller',
            })
            .state('app.products.bundle.edit', {
                url: '/view/:id',
                templateUrl: 'app/products/bundle.view.html',
                controller: 'bundle.edit.controller',
            })
            .state('app.products.condition', {
                url: '/condition',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.condition.list', {
                url: '/list',
                templateUrl: 'app/products/promotions.condition.html',
                controller: 'promotions.condition.controller',
            })
            .state('app.products.condition.create', {
                url: '/create',
                templateUrl: 'app/products/condition.create.html',
                controller: 'conditon.create.controller',
            })
            .state('app.products.definition', {
                url: '/definition',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.definition.list', {
                url: '/list',
                templateUrl: 'app/products/product.definition.list.html',
                controller: 'definition.list.controller',
            })
            .state('app.products.definition.create', {
                url: '/create',
                templateUrl: 'app/products/product.definition.create.html',
                controller: 'definition.create.controller',
            })
            .state('app.products.catalog', {
                url: '/e-catalog',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.products.catalog.list', {
                url: '/list',
                templateUrl: 'app/products/e-catalog/e-catalog.list.html',
                controller: 'catalog.list.controller',
            })
            .state('app.products.catalog.create', {
                url: '/create',
                templateUrl: 'app/products/e-catalog/e-catalog.create.html',
                controller: 'catalog.create.controller',
            })
            .state('app.products.catalog.update', {
                url: '/view/:id',
                templateUrl: 'app/products/e-catalog/e-catalog.update.html',
                controller: 'catalog.update.controller',
            })


    }

})();
