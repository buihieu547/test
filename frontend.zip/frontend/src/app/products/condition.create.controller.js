(function() {
    'use strict';
    angular
        .module('app')
        .controller('conditon.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, API, productAPI, promotionAPI, configurationAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            detail: []
        };
        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];
        $scope.productList = [];

        (function onInit() {
            getProductList();
        })();

        $scope.clickAdd = function() {
            $scope.mainData.detail.push({});
        };

        $scope.remove = function(index) {
            $scope.mainData.detail.splice(index, 1);
        };

        $scope.cancelCondition = function() {
            $state.go("app.products.condition.list");
        }

        $scope.createCondition = function() {
            var params = $scope.mainData.generalInfo;
            params.detail = $scope.mainData.detail;
            console.log(params);
            promotionAPI.postCondition(params).then(function(res) {
                try {
                    if (res.data._type == 'success') {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.products.condition.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                } catch (e) {
                    console.log(e)
                }
            })
        }
        $scope.changeProductLine = function(item, index) {

            var itemID = $scope.productList.filter(function(product) {
                if (product.item_id == item.wine_id)
                    return product;
            });
            item.name = itemID[0].name;
            item.uom_name = itemID[0].uom_name;
            item.price = itemID[0].price;
        }

        function getProductList() {
            productAPI.getListItemOption().then(function(res) {
                $scope.productList = res.data.results;
            })
        }

    }
})();
