(function () {
    'use strict';

    angular.module('app').controller('definition.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller,API, productAPI,$localStorage,$state) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.countRecord = 0;
        $scope.getList = getList;
        $scope.getListReference = getListReference;
        $scope.changeToGetSubModel = changeToGetSubModel;
        $scope.changeToGetSubCategory = changeToGetSubCategory;
        $scope.searchActionForList = searchActionForList;
        $scope.resetAction = resetAction;
        $scope.KeyShorcut = KeyShorcut;
        $scope.setFocus = setFocus;
        $scope.editProductDefinition = editProductDefinition;
        $scope.showImage = showImage;
        $scope.closeImage = closeImage;
        $scope.list = {
            search: {},
            items: [],
            checklist: [],
            filter: {}
        };
        $scope.listMoreFilter = [{value:false,name:'Brand'},{value:false,name:'Country'},{value:false,name:'Region'}];
        $scope.listMaster = {
            "brands": [],
            "categories": [],
            "countries": [],
            "suppliers": [],
            "state": []
        };

        $scope.selectItem = {
            isCheckAll: false
        }

        $scope.onoffFilter = false;

        function showImage(index, item) {
            var modal = document.getElementById('imageModal'+index);
            var modalImg = document.getElementById("img"+index);

            modal.style.display = "block";
             modalImg.src = item.large_img;
        }

        function closeImage(index) {
            var modal = document.getElementById('imageModal'+index);
            modal.style.display = "none";
        }

        /**
         * NAVIGATE TABLE
         */
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            item.is_checked = !item.is_checked;
            $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
                $scope.selectedIndex = index;
            }
            /**
             * KEY CONTROL
             */

        //Handle Select Item
        $scope.checkAll = function() {
            var flag = $scope.selectItem.isCheckAll;
            $scope.list.checklist = [];
            $scope.list.items.forEach(function(item) {
                item.is_checked = flag;
                if (flag && !checkExisted($scope.list.checklist, item.id)) {
                    $scope.list.checklist.push(item);
                }
            })
        };

        (function onInit() {
            $scope.getListReference();
            getSupplier();
            $scope.getList();
        })();

        function getSupplier() {
            API.get('company/list-option-company?is_supplier=1').then(function(res) {
              try {
                $scope.listMaster['suppliers'] = res.data.results.rows;
              } catch (e) {
                console.log(e);
              }
            })
        }

        $scope.checkItem = function(item) {
            if (item.is_checked && !checkExisted($scope.list.checklist, item.id)) {
                $scope.list.checklist.push(item);
            } else {
                $scope.list.checklist = $scope.list.checklist.filter(function(it) {
                    return it.id != item.id;
                });
            }

            if ($scope.list.checklist.length == $scope.list.items.length) {
                $scope.selectItem.isCheckAll = true;
            } else $scope.selectItem.isCheckAll = false;
        }
        $scope.showMorefilter = function(){
            $scope.onoffFilter = !$scope.onoffFilter;
        }

        $scope.select2options = function() {
            var s2options = {
                multiple: true,
            };
            return s2options;
        };
        $scope.createNew = function() {
            $state.go("app.products.definition.create")
        }

        function checkExisted(list, id) {
            return list.filter(function(item) {
                return item.item_id == id;
            }).length;
        }

        function resetFocus() {
            $scope.focusVin = false;
            $scope.focusVehicle = false;
            $scope.focusPartNumber = false;
            $scope.focusFilter = false;
        }

        $scope.currentSearch = {
            value: null,
            vin: 'focusVin',
            vehicle: 'focusVehicle',
            part: 'focusPartNumber'
        }

        function scrollToTable() {
            $timeout(function() {
                try {
                    if ($scope.list.items.length == 0) {
                        $scope[$scope.currentSearch.value] = true;
                        resetAction(1);
                        return;
                    }
                    var table = document.getElementsByClassName("custom-table")[0];
                    var top = table.offsetTop - 100;
                    resetFocus();
                    $('html, body').animate({
                        scrollTop: top
                    }, 500);
                } catch (e) {
                    console.log(e)
                }
            })
        }


        function getList() {
            var params = $listController.getParams();
            var filter = angular.copy($scope.list.filter);
            Object.keys(filter).forEach(function(item) {
                if (angular.isArray(filter[item])) {
                    filter[item] = filter[item].join(',');
                }
                return item;
            })
            params = Object.assign(params, $scope.list.search, filter);
            productAPI.getListDefinition(params).success(function(res) {
                try {
                    $scope.countRecord = res.results.total_items;
                    $scope.list.items = res.results.rows;
                    $listController.matchPagingOption(res.results);
                    scrollToTable();
                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function searchActionForList() {
            jQuery(':focus').blur();
            $scope.getList();
        }

        function resetAction(flag) {
            $scope.pagination.page = 1;
            if (flag) {
                $scope.list.filter = {};
                $scope.focusFilter = "reset";
                return;
            }
            $scope.list.search = {};
            $scope.list.items = [];
            $scope[$scope.currentSearch.value] = true;
            $scope.getList();

        }

        function changeTypeSearch() {
            $scope.list.search = [];
        }

        function editProductDefinition() {

        }

        function getListReference() {
            productAPI.getReferList().success(function(res) {
                try {
                    $scope.listMaster['brands'] = res.results.brands;
                    $scope.listMaster['categories'] = res.results.categories
                    $scope.listMaster['countries'] = res.results.countries;
                } catch (e) {
                    console.log(e.message)
                }
            });

        }

        function changeToGetSubModel(id, arr) {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i]['model_id'] == id) {
                    return $scope.listMaster['sub_models'] = arr[i]['sub_models'];
                }
            }

        }

        function changeToGetSubCategory(id, arr) {
            $scope.listMaster['sub_cat'] = [];
            console.log(id, arr);
            for (var k = 0; k < id.length; k++) {
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i]['category_id'] == id[k]) {
                        $scope.listMaster['sub_cat'] = $scope.listMaster['sub_cat'].concat(arr[i]['sub_categories']);
                    }
                }
            }
        }

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }

        function activateTab(tab) {
            $timeout(function() {
                jQuery('#' + tab + 'Search').trigger('click');
            })
        };


        function setFocus(focusMe) {
            $scope.list.search = [];
            $scope.list.checklist = [];
            if (focusMe == 1) {
                $scope.focusVin = true;
                $scope.currentSearch.value = $scope.currentSearch.vin;
            } else if (focusMe == 2) {
                $scope.focusVehicle = true;
                $scope.currentSearch.value = $scope.currentSearch.vehicle;
            } else {
                $scope.focusPartNumber = true;
                $scope.currentSearch.value = $scope.currentSearch.part;
            }
            $scope.resetAction();
        }
    }
})();
