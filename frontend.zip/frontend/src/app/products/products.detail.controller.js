(function () {
    'use strict';

    angular.module('app').controller('products.detail.controller',controller);

    /** @ngInject */
    function controller($scope, productAPI, $rootScope, $state,$stateParams) {
        $scope.updateImage = updateImage;
        $scope.product ={
            //defined product detail
        };
        $scope.listPreview=[];
        $scope.idProduct= $stateParams.id;
        (function onInit() {
            fetchProductByID($scope.idProduct);
        })();

        /** Internal functions */

       function fetchProductByID (id){
            productAPI.fetchProductById(id).success(function (res){
                $scope.product = res.results;
            });
        }
        function updateImage(){
            $scope.postData ={
                sku:$scope.product.sku
            }
            if($scope.listPreview.length>0){
                 productAPI.updateImageForProduct($scope.idProduct,$scope.postData,$scope.listFile).then(function(res){
                      var msg = "Updated product  successfully!"
                     window.toastr.success(msg);
                $state.go('app.products.item.manage');

            })
            }else{
                 $state.go('app.products.item.manage');
            }


        }

        $scope.cancel= function(){
            $state.go('app.products.item.manage');
        }
          $scope.setFiles = function(event){
        $scope.selectedImage =0;
         var files = event.target.files;
         $scope.listFile = files;
         for (var i = 0; i < files.length; i++) {
             var file = files[i];
                 var reader = new FileReader();
                 reader.onload = $scope.imageIsLoaded;
                 reader.readAsDataURL(file);
         }
    }

    $scope.imageIsLoaded = function(e){
        $scope.$apply(function() {
            $scope.listPreview.push(e.target.result);
        });
    }
    $scope.selectedImage = 0;
    $scope.selectedImages = function(index){
        $scope.selectedImage = index;
    }



    }
})();
