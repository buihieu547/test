(function() {
    'use strict';

    angular.module('app').controller('products.manage.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $controller, productAPI, $state, $localStorage, $uibModal,  hotkeys) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.countRecord = 0;
        $scope.getList = getList;
        $scope.getListReference = getListReference;
        $scope.changeToGetSubModel = changeToGetSubModel;
        $scope.changeToGetSubCategory = changeToGetSubCategory;
        $scope.searchActionForList = searchActionForList;
        $scope.resetAction = resetAction;
        $scope.KeyShorcut = KeyShorcut;
        $scope.setFocus = setFocus;
        $scope.showImage = showImage;
        $scope.closeImage = closeImage;
        $scope.list = {
            search: {},
            items: [],
            checklist: [],
            filter: {}
        };
        $scope.listMoreFilter = [{value:false,name:'Brand'},{value:false,name:'Country'},{value:false,name:'Region'}];
        $scope.listMaster = {
            "brands": [],
            "categories": [],
            "countries": [],
            "grape_varieties": [],
            "state": []
        };

        $scope.selectItem = {
            isCheckAll: false
        }

        $scope.onoffFilter = false;

        function showImage(index, item) {
            var modal = document.getElementById('imageModal'+index);
            var modalImg = document.getElementById("img"+index);

            modal.style.display = "block";
             modalImg.src = item.large_img;
        }

        function closeImage(index) {
            var modal = document.getElementById('imageModal'+index);
            modal.style.display = "none";
        }

        /**
         * NAVIGATE TABLE
         */
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            item.is_checked = !item.is_checked;
            $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
                $scope.selectedIndex = index;
            }
            /**
             * KEY CONTROL
             */
        hotkeys.bindTo($scope)
            .add({
                combo: 'alt+n',
                description: 'Create New Sales order with selected items',
                callback: function(e) {
                    $scope.createOrder();
                }
            })
            .add({
                combo: 'alt+a',
                description: 'Select all items on page',
                callback: function(e) {
                    $scope.selectItem.isCheckAll = !$scope.selectItem.isCheckAll;
                    $scope.checkAll();
                }
            })
            .add({
                combo: 'alt+pagedown',
                description: 'Move to next page',
                callback: function(e) {
                    $scope.pagination.page++;
                    if ($scope.pagination.page > $scope.pagination.total_page) {
                        $scope.pagination.page = $scope.pagination.total_page;
                        return;
                    }
                    $scope.changePage();
                }
            })
            .add({
                combo: 'alt+pageup',
                description: 'Move to previous page',
                callback: function(e) {
                    $scope.pagination.page--;
                    if ($scope.pagination.page < 1) {
                        $scope.pagination.page = 1;
                        return;
                    }
                    $scope.changePage();
                }
            })
            .add({
                combo: 'alt+end',
                description: 'Move to last page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = $scope.pagination.total_page;
                    $scope.changePage();

                }
            })
            .add({
                combo: 'alt+home',
                description: 'Move to first page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = 1;
                    $scope.changePage();
                }
            })
            /** Internal functions */

        //Handle Select Item
        $scope.checkAll = function() {
            var flag = $scope.selectItem.isCheckAll;
            $scope.list.checklist = [];
            $scope.list.items.forEach(function(item) {
                item.is_checked = flag;
                if (flag && !checkExisted($scope.list.checklist, item.id)) {
                    $scope.list.checklist.push(item);
                }
            })
        };

        (function onInit() {
            $scope.getListReference();
            $scope.getList();
        })();

        $scope.checkItem = function(item) {
            if (item.is_checked && !checkExisted($scope.list.checklist, item.id)) {
                $scope.list.checklist.push(item);
            } else {
                $scope.list.checklist = $scope.list.checklist.filter(function(it) {
                    return it.id != item.id;
                });
            }

            if ($scope.list.checklist.length == $scope.list.items.length) {
                $scope.selectItem.isCheckAll = true;
            } else $scope.selectItem.isCheckAll = false;
        }
        $scope.showMorefilter = function(){
            $scope.onoffFilter = !$scope.onoffFilter;
        }

        $scope.select2options = function() {
            var s2options = {
                multiple: true,
            };
            return s2options;
        };
        $scope.createOrder = function() {
            var listselectedItems = angular.copy($scope.list.checklist);
            if (listselectedItems.length == 0) return;
            //Convert string to Number
            listselectedItems.forEach(function(item) {
                if (item.price) item.sell_price = Number(item.price);
                item.order_quantity = 1;
                item.products=[];
            })
            $state.go("app.orders.sale-order.create", { items: listselectedItems })
        }

        function checkExisted(list, id) {
            return list.filter(function(item) {
                return item.item_id == id;
            }).length;
        }

        function resetFocus() {
            $scope.focusVin = false;
            $scope.focusVehicle = false;
            $scope.focusPartNumber = false;
            $scope.focusFilter = false;
        }

        $scope.currentSearch = {
            value: null,
            vin: 'focusVin',
            vehicle: 'focusVehicle',
            part: 'focusPartNumber'
        }

        function scrollToTable() {
            $timeout(function() {
                try {
                    if ($scope.list.items.length == 0) {
                        $scope[$scope.currentSearch.value] = true;
                        resetAction(1);
                        return;
                    }
                    var table = document.getElementsByClassName("custom-table")[0];
                    var top = table.offsetTop - 100;
                    resetFocus();
                    $('html, body').animate({
                        scrollTop: top
                    }, 500);
                } catch (e) {
                    console.log(e)
                }
            })
        }


        function getList() {
            var params = $listController.getParams();
            var filter = angular.copy($scope.list.filter);
            Object.keys(filter).forEach(function(item) {
                if (angular.isArray(filter[item])) {
                    filter[item] = filter[item].join(',');
                }
                return item;
            })
            params = Object.assign(params, $scope.list.search, filter);
            productAPI.getListOli(params).success(function(res) {
                try {
                    $scope.countRecord = res.results.total_items;
                    $scope.list.items = res.results.rows;

                    $listController.matchPagingOption(res.results);
                    scrollToTable();
                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function searchActionForList() {
            jQuery(':focus').blur();
            $scope.getList()
        }

        function resetAction(flag) {
            $scope.pagination.page = 1;
            if (flag) {
                $scope.list.filter = {};
                $scope.focusFilter = "reset";
                return;
            }
            $scope.list.search = {};
            $scope.list.items = [];
            $scope[$scope.currentSearch.value] = true;
            $scope.getList();

        }

        function changeTypeSearch() {
            $scope.list.search = [];
        }

        function getListReference() {
            productAPI.getReferList().success(function(res) {
                try {
                    $scope.listMaster['brands'] = res.results.brands;
                    $scope.listMaster['categories'] = res.results.categories
                    $scope.listMaster['countries'] = res.results.countries;
                    $scope.listMaster['grape_varieties'] = res.results.grape_varieties;
                } catch (e) {
                    console.log(e.message)
                }
            });

        }

        function changeToGetSubModel(id, arr) {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i]['model_id'] == id) {
                    return $scope.listMaster['sub_models'] = arr[i]['sub_models'];
                }
            }

        }

        function changeToGetSubCategory(id, arr) {
            $scope.listMaster['sub_cat'] = [];
            console.log(id, arr);
            for (var k = 0; k < id.length; k++) {
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i]['category_id'] == id[k]) {
                        $scope.listMaster['sub_cat'] = $scope.listMaster['sub_cat'].concat(arr[i]['sub_categories']);
                    }
                }
            }
        }

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }

        function activateTab(tab) {
            $timeout(function() {
                jQuery('#' + tab + 'Search').trigger('click');
            })
        };

        hotkeys.bindTo($scope).add({
                combo: 'alt+s',
                description: 'Search data based on key',
                callback: function(e) {
                    e.preventDefault();
                    $scope.searchActionForList()
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+r',
                description: 'Reset Search',
                callback: function(e) {
                    e.preventDefault();
                    $scope.resetAction()
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+shift+a',
                description: 'Filter',
                callback: function(e) {
                    e.preventDefault();
                    $scope.searchActionForList()
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+shift+r',
                description: 'Reset Filter',
                callback: function(e) {
                    e.preventDefault();
                    $scope.resetAction(1)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'ctrl+1',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Search by VIN',
                callback: function(e) {
                    e.preventDefault();
                    setFocus(1);
                    activateTab("vin");
                }
            })
            .add({
                combo: 'ctrl+3',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Search by Part Number',
                callback: function(e) {
                    e.preventDefault();
                    setFocus(3);
                    activateTab("partNumber");
                }
            })
            .add({
                combo: 'ctrl+2',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Search by Vehicle',
                callback: function(e) {
                    e.preventDefault();
                    setFocus(2);
                    activateTab("vehicle");
                }
            })
            .add({
                combo: 'ctrl+4',
                description: 'Open Filter',
                callback: function(e) {
                    e.preventDefault();
                    if($scope.list.items.length == 0) return;
                    $scope.focusFilter = true;
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            });

        function setFocus(focusMe) {
            $scope.list.search = [];
            $scope.list.checklist = [];
            if (focusMe == 1) {
                $scope.focusVin = true;
                $scope.currentSearch.value = $scope.currentSearch.vin;
            } else if (focusMe == 2) {
                $scope.focusVehicle = true;
                $scope.currentSearch.value = $scope.currentSearch.vehicle;
            } else {
                $scope.focusPartNumber = true;
                $scope.currentSearch.value = $scope.currentSearch.part;
            }
            $scope.resetAction();
        }
    }
})();
