(function () {
    'use strict';

    angular
        .module('app')
        .controller('definition.create.controller', controller);


    /** @ngInject */
    function controller($scope, productAPI , API, $rootScope, $state, $stateParams, $localStorage) {

        $scope.productCategory = [];
        $scope.product = {};
        $scope.img = '';
        $scope.listPreview = [];
        $scope.wine_images = [];
        $scope.quotation = [{id:0, name: 'NO'}, {id:1, name: 'YES'}];

        $scope.changeProductType = changeProductType;
        $scope.getProductType = getProductType;
        $scope.getGrapeVariety = getGrapeVariety;
        $scope.getGender = getGender;
        $scope.getSupplier = getSupplier;
        $scope.getColor = getColor;
        $scope.sizes = [{ name:'XXXS'},{ name:'XXS'}, { name:'XS'}, { name:'S'},{ name:'XXXS'},{ name:'M'}, { name:'L'}, { name:'XL'}, { name:'XXL'}, { name:'XXXL'}];
        $scope.getFabric = getFabric;

        (function onInit() {
            getProductType();
            getGrapeVariety();
            getGender();
            getSupplier();
            getListBand();
            getColor();
            getFabric();
            $scope.product.is_quotable = 0;
        })();

        function getProductType() {
            productAPI.getProductType().success(function(res) {
                try {
                    $scope.productType = res.results;
                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function getGrapeVariety() {
            productAPI.getGrapeVariety().success(function(res) {
                try {
                    $scope.productGrapeVarieties = res.results;
                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function getGender() {
            $scope.genders = [{id: 0, name: 'Female'},{id: 1, name: 'Male'}]
        }

        function getColor() {
            API.get('wine_color').then(function(res) {
              try {
                $scope.colors = res.data.results;
              } catch (e) {
                console.log(e);
              }
            })
        }

        function getFabric() {
            API.get('wine_fabric').then(function(res) {
              try {
                  $scope.fabrics = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
        }

        function changeProductType() {
            productAPI.getProductCategory($scope.product.product_type).success(function(res) {
                try {
                    $scope.productCategory = res.results;
                } catch (e) {
                    console.log(e.message);
                }
            });
        }


        function getSupplier() {
            API.get('company/list-option-company?is_supplier=1').then(function(res) {
              try {
                $scope.suppliers = res.data.results.rows;
              } catch (e) {
                console.log(e);
              }
            })
        }
        function getListBand() {
            productAPI.getListBand().then(function(res) {
              try {
                $scope.listBrand = res.data.results;
              } catch (e) {
                console.log(e);
              }
            })
        }

        $scope.setFiles = function(event) {
            $scope.selectedImage = 0;
            $scope.listPreview = [];
            $scope.wine_images = [];
            var files = event.target.files;
            $scope.wine_images = files;
            if(files.length>5) {
                alert('Maximum number of files is 5');
                return false;
            }
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded;
                reader.readAsDataURL(file);
            }
        }

        $scope.imageIsLoaded = function(e) {
            $scope.$apply(function() {
                $scope.listPreview.push(e.target.result);
            });
        }

        $scope.selectedImage = 0;
        $scope.selectedImages = function(index) {
            $scope.selectedImage = index;
        }

        $scope.createDefinition = function() {
            $scope.product.size = $scope.product.sized.toString();
            $scope.product.price =0;
            $scope.product.resale_price =0;            
            productAPI.postDefinition($scope.product,$scope.wine_images).then(function(res){
                try {
                    window.toastr.success('Product Definition is created successfully');
                    $state.go('app.products.definition.list');
                } catch (e) {
                    console.log(e.message);
                }
            })

        }

}

})();
