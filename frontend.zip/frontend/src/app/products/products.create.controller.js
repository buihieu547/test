(function () {
    'use strict';

    angular.module('app').controller('products.create.controller', controller);

    /** @ngInject */
    function controller($scope, productAPI, $rootScope, $state, envConfig) {

        $scope.setFiles = function(event) {
          $scope.selectedImage = 0;
          var files = event.target.files;
          $scope.listFile = files;
          for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            reader.onload = $scope.imageIsLoaded;
            reader.readAsDataURL(file);
          }

        }

    }
})();
