(function() {
    'use strict';

    angular
        .module('app')
        .service('productAPI', service);

    /** @ngInject */
    function service(API, $q, $interval, $http) {

        var _this = this;
        this.getList = getList;
        this.getListOli = getListOli;
        this.getReferList = getReferList;
        this.getListItemOption = getListItemOption;
        this.getListItemBaseSupplier = getListItemBaseSupplier;

        this.keyUpload = null;

        //definition
        this.getProductType = getProductType;
        this.getProductCategory = getProductCategory;
        this.getGrapeVariety = getGrapeVariety;
        this.postDefinition = postDefinition;
        this.getListDefinition = getListDefinition;
        this.getListBand =getListBand;

        /** Internal functions */

        function getList(params) {
            var url = ['product', 'get-by-brand'].join('/');
            return API.get(url, params);
        }

        function getListOli(params) {
            var url = ['item'].join('/');
            return API.get(url, params);
        }

        function getListItemBaseSupplier(params, id) {
            var url = 'item?supplier_id=' + id;
            return API.get(url, params);
        }
        //     function getListOliwithBuyerId(params){
        //         params.
        //         var url = ['item'].join('/');
        //        return API.get(url,params);
        //    }
        function getListItemOption() {
            var url = 'item/reference';
            return API.get(url);
        }
        //Master List
        function getReferList() {
            var url = ['reference', 'item-data'].join('/');
            return API.get(url);
        }
        function getProductType() {
            var url = 'category';
            return API.get(url);
        }
        function getProductCategory(id) {
            var url = 'category?parent_id=' + id;
            return API.get(url);
        }
        function getGrapeVariety() {
            var url = 'grape_variety';
            return API.get(url);
        }
        function getListBand() {
            var url = 'brand/reference';
            return API.get(url);
        }
        function getListDefinition(params) {
            var url = 'item';
            return API.get(url, params);
        }
        function postDefinition(data,files) {
            var url = 'item';
            url = API.getHost() + url;
            var defer = $q.defer();
            var formData = new FormData();
            formData.append('data', JSON.stringify(data));
            if ( typeof(files) !='undefined') {
                for (var i = 0; i < files.length; i++) {
                    formData.append('image' + i, files[i]);
                }
            }
            $http
                .post(url, formData, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function (result) {
                    defer.resolve(result);

                })
                .error(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }
        // function postDefinition(params, files) {
        //     var url = 'item';
        //     return API.post(url, params);
        // }
    }
})();
