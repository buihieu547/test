(function() {
    'use strict';

    angular
        .module('app')
        .controller('catalog.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $controller, $uibModal, API, catalogAPI, $stateParams, $timeout, orderAPI, $state, $localStorage, hotkeys) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });
        var $tableController = $controller('abstract.table.controller', { $scope: $scope });

        $scope.addNewItem = addNewItem;
        $scope.createCataLog =createCataLog;

        $scope.selectedImage = 0;
        $scope.setFiles = function(event) {
            $scope.selectedImage = 0;
            var files = event.target.files;
            $scope.listFile = files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded;
                reader.readAsDataURL(file);
            }

        }

        $scope.imageIsLoaded = function(e) {
            $scope.$apply(function() {
                $scope.listPreview = [];
                $scope.listPreview.push(e.target.result);
            });
        }
        $scope.selectedImage = 0;
        $scope.selectedImages = function(index) {
            $scope.selectedImage = index;
        }

        function addNewItem() {

            $uibModal.open({
                animation: true,
                templateUrl: 'app/products/e-catalog/add-new-item-order-modal.html',
                controller: ['$uibModalInstance',
                    '$scope',
                    'productAPI',
                    'promotionAPI',
                    'hotkeys',
                    function($uibModalInstance, modalScope, productAPI, promotionAPI, hotkeys) {
                        var $listController = $controller('abstract.list.controller', { $scope: modalScope });
                        var $tableController = $controller('abstract.table.controller', { $scope: modalScope });
                        modalScope.checkList = [];

                        modalScope.isCheckAllItem = false;
                        modalScope.isCheckAllBundle = false;
                        modalScope.listItem = {
                            items: [],
                            checklist: [],
                            search: {},
                            filter: {}
                        };
                        modalScope.listBundle = {
                            items: [],
                            checklist: [],
                            search: {},
                            filter: {}
                        };
                        modalScope.getList = getList;
                        modalScope.resetAction = resetAction;
                        modalScope.checkAll = checkAll;
                        modalScope.checkItem = checkItem;
                        modalScope.onoffFilter =false;


                        modalScope.countRecord = 0;

                        modalScope.getListReference = getListReference;
                        modalScope.changeToGetSubModel = changeToGetSubModel;
                        modalScope.changeToGetSubCategory = changeToGetSubCategory;
                        modalScope.searchActionForList = searchActionForList;
                        modalScope.setFocus = setFocus;

                        /**
                         * KEY CONTROL
                         */


                        function KeyShorcut() {
                            hotkeys.toggleCheatSheet();
                        }

                        function activateTab(tab) {
                            $timeout(function() {
                                jQuery('#' + tab + 'Search').trigger('click');
                            })
                        };



                        function resetFocus() {
                            modalScope.focusVin = false;
                            modalScope.focusVehicle = false;
                            modalScope.focusPartNumber = false;
                            modalScope.focusFilter = false;
                        }

                        modalScope.currentSearch = {
                            value: null,
                            vin: 'focusVin',
                            vehicle: 'focusVehicle',
                            part: 'focusPartNumber'
                        }

                        function setFocus(focusMe) {
                            // modalScope.list.search = [];
                            // modalScope.list.checklist = [];

                            if (focusMe == 1) {
                                modalScope.focusVin = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.vin;
                            } else if (focusMe == 2) {
                                modalScope.focusVehicle = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.vehicle;
                            } else {
                                modalScope.focusPartNumber = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.part;
                            }
                            // modalScope.resetAction();
                        }
                        /**
                         * SCROLL TO ELEMENT
                         */
                        function scrollToTable() {
                            $timeout(function() {
                                try {
                                    if (modalScope.listItem.items.length == 0) {
                                        modalScope[modalScope.currentSearch.value] = true;
                                        // resetAction(1);
                                        return;
                                    }
                                    if (modalScope.listBundle.items.length == 0) {
                                        modalScope[modalScope.currentSearch.value] = true;
                                        // resetAction(1);
                                        return;
                                    }
                                    var table = jQuery(".modal-dialog .custom-table")[0];
                                    var top = table.offsetTop - 100;
                                    resetFocus();
                                    $('.modal-open .modal').animate({
                                        scrollTop: top
                                    }, 500);
                                } catch (e) {
                                    console.log(e)
                                }
                            })
                        }
                        /**
                         * NAVIGATE TABLE
                         */
                        modalScope.selectedIndexItem = -1;
                        modalScope.selectedIndexBundle = -1;
                        modalScope.selectItem = function(item, _flag) {
                            console.log(_flag);
                            item.is_checked = !item.is_checked;
                            checkItem(item, _flag);
                        }
                        modalScope.onClickRowItem = function(index) {
                            modalScope.selectedIndexItem = index;
                        }
                        modalScope.onClickRowBundle = function(index) {
                            modalScope.selectedIndexBundle = index;
                        }
                        modalScope.showMorefilter = function(){
                            modalScope.onoffFilter = !modalScope.onoffFilter;
                        }


                        /**
                         * HANDLE SEARCH
                         */


                        modalScope.listMoreFilter = [{value:false,name:'Brand'},{value:false,name:'Country'},{value:false,name:'Region'}];
                        modalScope.listMaster = {
                            "brands": [],
                            "categories": [],
                            "countries": [],
                            "grape_varieties": [],
                            "state": []
                        };


                        // modalScope.searchType = [{ id: 1, name: "Vin" }, { id: 2, name: "Vehicle Model" }, { id: 3, name: "Part" }];


                        (function onInit() {
                            modalScope.getListReference();
                            modalScope.focusVin = true;
                            modalScope.getList('item','bundle');

                        })();

                        /** Internal functions */
                        function getList(flag1, flag2) {

                            if(flag1 == 'item') {
                                var params = $listController.getParams();
                                var filter = angular.copy(modalScope.listItem.filter);
                                Object.keys(filter).forEach(function(item) {
                                    if (angular.isArray(filter[item])) {
                                        filter[item] = filter[item].join(',');
                                    }
                                    return item;
                                })
                                params = Object.assign(params, modalScope.listItem.search, filter);

                                productAPI.getListOli(params).success(function(res) {
                                    try {
                                        modalScope.countRecord = res.results.total_items;
                                        modalScope.listItem.items = res.results.rows;
                                        modalScope.listItem.items.forEach(function(item) {
                                            item.is_checked = false;
                                        })
                                        $listController.matchPagingOption(res.results);
                                        scrollToTable();
                                    } catch (e) {
                                        console.log(e.message);
                                    }
                                });
                            }
                            if(flag2 == 'bundle') {
                                var params = $tableController.getParams();
                                var filter = angular.copy(modalScope.listBundle.filter);
                                Object.keys(filter).forEach(function(item) {
                                    if (angular.isArray(filter[item])) {
                                        filter[item] = filter[item].join(',');
                                    }
                                    return item;
                                })
                                params = Object.assign(params, modalScope.listBundle.search, filter);
                                promotionAPI.getBundleRef(params).success(function(res) {
                                    try {
                                        modalScope.countRecord = res.results.total_items;
                                        modalScope.listBundle.items = res.results.rows;
                                        modalScope.listBundle.items.forEach(function(item) {
                                            item.is_checked = false;
                                        })
                                        $timeout(function() {
                                            $tableController.matchPagingOption(res.results);
                                        }, 500);

                                    } catch (e) {
                                        console.log(e.message);
                                    }
                                });
                            }

                        }

                        function searchActionForList(flag1,flag2) {
                            modalScope.getList(flag1,flag2);
                        }





                        function getListReference() {
                            productAPI.getReferList().success(function(res) {
                                try {
                                    modalScope.listMaster['brands'] = res.results.brands;
                                    modalScope.listMaster['categories'] = res.results.categories
                                    modalScope.listMaster['countries'] = res.results.countries;
                                    modalScope.listMaster['grape_varieties'] = res.results.grape_varieties;
                                } catch (e) {
                                    console.log(e.message)
                                }
                            });

                        }

                        function changeToGetSubModel(id, arr) {
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i]['model_id'] == id) {
                                    return modalScope.listMaster['sub_models'] = arr[i]['sub_models'];
                                }
                            }

                        }

                        function changeToGetSubCategory(id, arr) {
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i]['category_id'] == id) {
                                    return modalScope.listMaster['sub_cat'] = arr[i]['sub_categories'];

                                }
                            }

                        }



                        modalScope.modalTitle = "SELECT ITEM";

                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        };



                        function resetAction(flag) {
                            modalScope.listItem.search = {};
                            modalScope.searchActionForList('item', '');
                        }

                        modalScope.ok = function() {
                            // console.log(modalScope.listBundle.checklist);
                            // console.log(modalScope.listItem.checklist);
                            modalScope.checkList = [].concat(modalScope.listItem.checklist,modalScope.listBundle.checklist);
                            $uibModalInstance.close(modalScope.checkList);
                        };

                        function checkExisted(list, id) {
                            return list.filter(function(item) {
                                return item.item_id == id;
                            }).length;
                        }

                        function checkAll(_flag) {

                            if(_flag == 'item') {
                                var flag = modalScope.selectItem.isCheckAllItem;
                                modalScope.listItem.checklist = [];
                                modalScope.listItem.items.forEach(function(item) {
                                    item.is_checked = flag;
                                    if (flag && !checkExisted(modalScope.listItem.checklist, item.item_id)) {
                                        modalScope.listItem.checklist.push(item);
                                    }
                                })
                            }
                            if(_flag == 'bundle') {
                                var flag = modalScope.selectItem.isCheckAllBundle;
                                modalScope.listBundle.checklist = [];
                                modalScope.listBundle.items.forEach(function(item) {
                                    item.is_checked = flag;
                                    if (flag && !checkExisted(modalScope.listBundle.checklist, item.id)) {
                                        modalScope.listBundle.checklist.push(item);
                                    }
                                })
                            }
                        };

                        function checkItem(item, _flag) {
                            if(_flag == 'item') {
                                if (item.is_checked && !checkExisted(modalScope.listItem.checklist, item.item_id)) {
                                    modalScope.listItem.checklist.push(item);
                                } else {
                                    modalScope.listItem.checklist = modalScope.listItem.checklist.filter(function(it) {
                                        return it.item_id != item.item_id;
                                    });
                                }

                                if (modalScope.listItem.checklist.length == modalScope.listItem.items.length) {
                                    modalScope.selectItem.isCheckAllItem = true;
                                } else modalScope.selectItem.isCheckAllItem = false;
                            }
                            if(_flag == 'bundle') {
                                if (item.is_checked && !checkExisted(modalScope.listBundle.checklist, item.id)) {
                                    modalScope.listBundle.checklist.push(item);
                                } else {
                                    modalScope.listBundle.checklist = modalScope.listBundle.checklist.filter(function(it) {
                                        return it.id != item.id;
                                    });
                                }


                                if (modalScope.listBundle.checklist.length == modalScope.listBundle.items.length) {
                                    modalScope.selectItem.isCheckAllBundle = true;
                                } else modalScope.selectItem.isCheckAllBundle = false;
                            }

                        }

                    }
                ],
                size: 'lg'
            }).result.then(function(res) {
                $scope.items = [];
                if (angular.isArray(res) && res.length > 0) {
                    $scope.items = res;
                    var listAdded = [];
                    angular.copy($scope.items).forEach(function(item) {
                        listAdded.push(item.item_id);

                    });

                    res.forEach(function(item) {
                        if (item.resale_price) item.resale_price = Number(item.resale_price);
                        item['products'] = [];
                        item.quantity = 1;
                        item.totalItem = item.resale_price;
                    })

                    $scope.items = $scope.items.concat(res.filter(function(item) {
                        return listAdded.indexOf(item.item_id) < 0;
                    }));
                }
            });
        }
        function createCataLog(){
            $scope.listID=[];
            $scope.items.forEach(function(item){
                $scope.listID.push(item.id);
            })
            var params= $scope.catalog;
            params.items = $scope.listID;
            catalogAPI.postECatalog(params, $scope.listFile).then(function(res){
                try{
                    if(res._type=='success'){
                        toastr.success(res.message);
                        $timeout(function() {
                            $state.go("app.products.catalog.list");
                        }, 500)

                    } else {
                        toastr.error(res.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })

        }
        $scope.cancelCatalog = function(){
            $state.go("app.products.catalog.list");
        }

    }
})();
