(function () {
	'use strict';

	angular
		.module('app')
		.controller('catalog.list.controller', controller);

	/** @ngInject */
	function controller($scope, $controller, API, catalogAPI, $localStorage, MessageService, hotkeys, $state) {

		var $listController = $controller('abstract.list.controller', {
			$scope: $scope
		});

		$scope.getList = getList;
		$scope.addNewItem = addNewItem;
		$scope.changeStatus = changeStatus;
		$scope.KeyShorcut = KeyShorcut;
		$scope.searchAction = searchAction;
		$scope.list = {
			items: [],
			search: {}
		};

		/** Internal functions */

		(function onInit() {
			 getList();
		})();

		function addNewItem() {
			$state.go("app.products.catalog.create");
		}
		$scope.editCateLog = function(id){
			$state.go("app.products.catalog.update",{id:id});
		}
		$scope.changeStatus= function(item,is_sync){
			console.log(item);			
			var params= item;
			// params.is_sync  =!is_sync;
			// params.is_sync==true ? '1':'0'; 
			console.log(params);
			catalogAPI.putECatalog(item.id,params).then(function(res){
				console.log(res);
			})
		}

		function getList() {
			var params = $listController.getParams();
			Object.keys(params).forEach(function (item) {
				if (angular.isArray(params[item])) {
					params[item] = params[item].join(',');
				}
				return item;
			})
			catalogAPI.getListEcatalog(params).then(function (res) {
					try {
						$scope.list.items = res.data.results.rows;
						$listController.matchPagingOption(res.data.results);
					} catch (e) {
						console.log(e);
					}
				});
		}

		function changeStatus(id, ac) {
			var params = {
				'ac': ac
			};
			catalogAPI.updateUOM(id, params).then(function (res) {
				try {
					if (res._type === 'success') {
						toastr.success(res.message);
					} else {
						toastr.error(res.message);
					}

				} catch (e) {
					console.log(e);
				}
			})
		}


		function KeyShorcut() {
			hotkeys.toggleCheatSheet();
		}
		hotkeys
			.bindTo($scope)
			.add({
				combo: 'alt+n',
				description: 'Create New Sales order',
				callback: function (e) {
					$scope.createOrder();
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'enter',
				description: 'Go to  detail Sales order',
				callback: function (e) {
					if ($scope.selectedIndex > -1) {
						$scope.item_detail = $scope.list.items[$scope.selectedIndex].id;
						$state.go('app.orders.detail', {
							id: $scope.item_detail
						})
					}

				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+s',
				description: 'Search',
				callback: function () {
					$scope.searchAction($scope.list.search)
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+r',
				description: 'Reset Search',
				callback: function () {
					$scope.list.search = {};
					$scope.searchAction($scope.list.search)
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+pagedown',
				description: 'Move to next page',
				callback: function (e) {
					$scope.pagination.page++;
					if ($scope.pagination.page > $scope.pagination.total_page) {
						$scope.pagination.page = $scope.pagination.total_page;
						return;
					}
					$scope.changePage();
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+pageup',
				description: 'Move to previous page',
				callback: function (e) {
					$scope.pagination.page--;
					if ($scope.pagination.page < 1) {
						$scope.pagination.page = 1;
						return;
					}
					$scope.changePage();
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+end',
				description: 'Move to last page',
				callback: function (e) {
					e.preventDefault();
					$scope.pagination.page = $scope.pagination.total_page;
					$scope.changePage();

				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
			.add({
				combo: 'alt+home',
				description: 'Move to first page',
				callback: function (e) {
					e.preventDefault();
					$scope.pagination.page = 1;
					$scope.changePage();
				},
				allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
			})
		// .add({
		//     combo: 'alt+shift+a',
		//     description: 'Filter Search',
		//     callback: function(e) {
		//         e.preventDefault();
		//         $scope.pagination.page = 1;
		//         $scope.scrollToFilter()
		//     },
		//     allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
		// })

		function scrollToTable() {
			try {
				var top = document.getElementsByClassName("custom-table")[0].offsetTop - 100;
				$('html, body').animate({
					scrollTop: top
				}, 500);
			} catch (e) {
				console.log(e)
			}
		}

		function searchAction(search) {
			var params = $listController.getParams();
			angular.merge(params, search);
			$listController.searchAction(params);
		}

	}
})();
