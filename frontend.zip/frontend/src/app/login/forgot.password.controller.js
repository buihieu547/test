(function () {
    'use strict';

    angular.module('app').controller('forgot.password.controller', controller);

    /** @ngInject */
    function controller($scope, $localStorage, $state, $timeout, loginAPI,gettextCatalog) {

        $scope.formData = {};
        $localStorage.currentLanguge =   $scope.currentLang;
        gettextCatalog.setCurrentLanguage($scope.currentLang);

        $scope.forgot = function (data) {
            var params = {
                login : data.email,
                redirect : location.origin + '/' + $state.href('reset_password')
            };

            loginAPI.forgot(params).success(function (res) {
                window.toastr.success(res.message);
                $state.go('app.login');
            });
        };

        $scope.cancel = function () {
            $state.go('app.login');
        }


    }
})();
