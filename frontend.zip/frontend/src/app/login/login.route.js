(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.login', {
                url: '/login',
                views: {
                    "@": {
                        controller: 'login.controller',
                        templateUrl: 'app/login/login.form.html'
                    }
                },
            })
            .state('app.forgot_password', {
                url: '/forgot-password',
                controller: 'forgot.password.controller',
                templateUrl: 'app/login/forgot.password.html'
            })
            .state('app.reset_password', {
                url: '/reset-password/:token',
                params:  {
                    token: {
                        value: null,
                        squash: true
                    }
                },
                controller: 'reset_password.controller',
                templateUrl: 'app/login/login.reset_password.html'
            })
    }

})();
