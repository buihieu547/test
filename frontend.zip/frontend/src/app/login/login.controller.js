(function() {
    'use strict';

    angular.module('app').controller('login.controller', controller);

    /** @ngInject */
    function controller($scope, $localStorage, $state, $timeout, loginAPI, gettextCatalog) {

        if ($localStorage.AUTHENTICATE_TOKEN) {
            $state.go('app.guide.view');
        }

        $scope.formData = {};
        $scope.brands = {};
        $scope.signIn = signIn;

        $scope.currentLang = $localStorage.currentLanguge || 'en';
        $localStorage.currentLanguge = $scope.currentLang;
        gettextCatalog.setCurrentLanguage($scope.currentLang);


        /** Internal functions */
        function signIn(data) {
            $('.alert').removeClass('in');

            var params = {
                login: data.login,
                password: data.password
            };

            loginAPI.signIn(params).then(function(res) {
                try {
                    var _data = res.data.results;

                    if (_data.info.user_type == 1) {
                        _data.info.user_id = _data.info.id;
                        $localStorage.$reset();
                        $localStorage.AUTHENTICATE_TOKEN = _data.token;
                        $localStorage.USER_DATA = _data.info;
                        $localStorage.FIRST_LOGIN = _data.first_login;
                        $localStorage.LOGGED_AT = moment().format('h:mm A');
                        $localStorage.PERMISSION = _data.group_permissions;

                        $state.go('app.guide.view');
                    } else {
                        toastr.error('Username or password is incorrect');
                    }

                    // $timeout(function () {
                    //     $state.go('app.products.manage');
                    //     // if($localStorage.USER_DATA.role_alias == 'admin') {
                    //     //     $state.go('app.products.manage');
                    //     // }

                    //     // if($localStorage.USER_DATA.role_alias == 'manager' || $localStorage.USER_DATA.role_alias == 'salesman') {

                    //     // }

                    //     // if($localStorage.USER_DATA.role_alias == 'bo') {
                    //     //     $state.go('app.products.manage');
                    //     // }
                    // }, 500);

                } catch (error) {
                    $('.alert').addClass('in');
                }

            });
        }
    }
})();
