
(function () {
    'use strict';

    angular.module('app').controller('reset_password.controller', controller);

    /** @ngInject */
    function controller($scope, $localStorage, $state, $timeout, loginAPI, $location) {

        $scope.formData = {};

        $scope.savePwdAction = savePwdAction;

        function savePwdAction(data) {
            data.token = $location.search().token;
            data.key = $location.search().key;

            loginAPI.savePassword(data).then(function(res){
                window.toastr.success(res.data.message);
                $state.go('app.login');
            },function(error){
                window.toastr.success(error.data.message);
                $state.go('app.login');
            });

        }

        $scope.cancel = function () {
            $state.go('app.login');
        }


    }
})();
