(function () {
    'use strict';

    angular.module('app').service('loginAPI', service);

    function service(API) {

        this.signIn = signIn;
        this.forgot = forgot;
        this.savePassword = savePassword;

        /** Internal functions */

        function signIn(params) {
            var url = ['auth/login'].join('/');
            return API.post(url, params);
        }

        function forgot(params) {
            var url = ['auth','forgot-password'].join('/');
            return API.post(url, params);
        }

        function savePassword(data) {
            var url = ['auth','reset-password'].join('/');
            return API.post(url,data);
        };
    }
})();
