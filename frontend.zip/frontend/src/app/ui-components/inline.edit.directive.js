
(function () {
    'use strict';

    angular.module('app').directive('inlineEdit',directive);

    /** @ngInject */
    function directive($parse) {
        return {
            restrict : 'E',
            require : '?ngModel',

            template : '<input class="form-control input-sm" ng-model="ngModel" />',
            link : function ($scope, $element, $attrs, ngModel) {

                var fn = $parse($attrs['action']);

                var callback = function() {
                    fn($scope, {$event: event});
                };

                ngModel.$render = function () {
                    $scope.ngModel = ngModel.$viewValue;
                };

                $element.find('input').blur(function (event) {
                    ngModel.$setViewValue($scope.ngModel);

                    $scope.$apply(callback);
                });
            }
        }
    }
})();
