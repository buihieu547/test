
(function() {
    'use strict';

    angular.module('app').directive('jsMainNav', function() {
        return {
            link: function(scope, element) {
                // When a submenu link is clicked
                jQuery('[data-toggle="nav-submenu"]', element).on('click', function(e) {
                    // Get link
                    var link = jQuery(this);

                    // Get link's parent
                    var parentLi = link.parent('li');                   

                    if (parentLi.hasClass('open')) { // If submenu is open, close it..
                        parentLi.removeClass('open');
                    } else { // .. else if submenu is closed, close all other (same level) submenus first before open it
                        link
                            .closest('ul')
                            .find('> li')
                            .removeClass('open');

                        parentLi
                            .addClass('open');
                    }

                    return false;
                });

                // Remove focus when clicking on a link
                jQuery('a', element).on('click', function() {
                    jQuery(this).blur();
                });

                // On state change success event, hide the sidebar in mobile devices
                scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                    scope.oneui.settings.sidebarOpenXs = false;
                });
            }
        };
    });
    angular.module('app').directive('jsClickOpen', function() {
        return {
            link: function(scope, element) {
                // When a submenu link is clicked
                jQuery('li', element).on('click', function(e) {
                    var link = jQuery(this);                   
                    var parentLi= link.parent('ul');
                    parentLi.find('li').removeClass('open');  
                    return false;
                });

                

                // On state change success event, hide the sidebar in mobile devices
                scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                    scope.oneui.settings.sidebarOpenXs = false;
                });
            }
        };
    });
    angular.module('app').directive('focusElement', function($timeout) {
        return {
            scope: { trigger: '=focusElement', focusType: '@' },
            link: function(scope, element) {
                function scrollToElement() {
                    try {
                        var top = element[0].offsetTop - 100;
                        $('html, body').animate({
                            scrollTop: top
                        }, 500);
                    } catch (e) {
                        console.log(e)
                    }
                }

                scope.$watch('trigger', function(value) {
                    if (value === true && !scope.focusType) {
                        //console.log('trigger',value);
                        $timeout(function() {
                            element[0].focus();
                            jQuery(element[0]).select2('open');
                            scope.trigger = null;
                            scrollToElement();
                        });
                        return;
                    }

                    if (value === false) {
                        $timeout(function() {
                            element[0].blur();
                            try {
                                jQuery(':focus').select2('close');
                                jQuery(':focus').blur();
                                jQuery(element[0]).select2('close');
                            } catch (e) {}

                            // jQuery('.select2-container-active').removeClass('select2-container-active');

                        });
                    }
                    if (value === "reset") {
                        try {
                            jQuery(element[0]).select2('val', '');
                            jQuery(element[0]).select2('close');
                            scope.trigger = null;
                        } catch (e) {

                        }

                    }
                });
            }
        };

    })
})();