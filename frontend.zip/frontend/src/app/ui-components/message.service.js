/**
 * Created by Vinh on 8/30/2016.
 */

(function () {
    'use strict';
    var moduleName = "app";

    angular.module(moduleName).controller('MessageController', MessageController);

    /** @ngInject **/
    function MessageController($scope, $uibModalInstance, $timeout, $interval) {

        if ($scope.$parent.autoClose) {
            $scope.progress = 0;
            $interval(function() { if ($scope.progress < 100) $scope.progress += 10 }, 50);
            $scope.$watch(function() {return $scope.progress}, function() {
                if ($scope.progress >= 100) {
                    $timeout(function() {
                        $uibModalInstance.close(true);
                    }, 1000);
                }
            });
        }

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.ok = function() {
            $uibModalInstance.close(true);
        };
    }

    angular.module(moduleName).factory('MessageService', MessageService);

    /** @ngInject **/
    function MessageService($uibModal, $rootScope) {
        /** For uiModal implementation**/
        var uiModalDefinition = {
            animation: true,
            templateUrl: 'app/ui-components/message.html',
            controller: 'MessageController',
            backdrop: 'static',
            keyboard : false
        };

        function uiModal (success, message, confirm) {
            $rootScope.success = success;
            $rootScope.message = message;
            $rootScope.confirm = confirm;
            $rootScope.autoClose = !confirm;

            if(confirm)
            {
                uiModalDefinition.size = 'sm';
            }

            return $uibModal.open(uiModalDefinition).result;
        }


        return {
            showMessage: function (success, message) {
                return uiModal (success, message, false);
            },
            showConfirm: function (message) {
                return uiModal (null, message, true);
            }
        };
    }
})();
