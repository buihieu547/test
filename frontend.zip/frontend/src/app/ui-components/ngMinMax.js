(function() {
    'use strict';

    angular.module('app').directive('ngMinMax', function() {
        return {
            require: 'ngModel',
            link: function(scope, element, attrs, modelCtrl) {

                element.on("keydown keyup", function(e) {
                 
                if (Number(element.val()) > Number(attrs.max) &&
                      e.keyCode != 46 // delete
                      &&
                      e.keyCode != 8 // backspace
                    ) {
                      e.preventDefault();
                      element.val('');
                    }
                });
            }
        };
    });
})();
