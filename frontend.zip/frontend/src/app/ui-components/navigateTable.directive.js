(function() {
    'use strict';
    angular
        .module('app')
        .directive('cdArrowTable', cdArrowTable)
        .directive('cdArrowRow', cdArrowRow);

    function cdArrowTable(hotkeys, $timeout) {
        return {
            restrict: 'A',
            scope: {
                collection: '=',
                selectedIndex: '=',
                onEnter: '&'
            },
            link: function(scope, element, attrs, ctrl) {
                // Ensure the selectedIndex doesn't fall outside the collection
                scope.$watch('collection.length', function(newValue, oldValue) {
                    if (scope.selectedIndex > newValue - 1) {
                        scope.selectedIndex = newValue - 1;
                    } else if (oldValue <= 0) {
                        scope.selectedIndex = 0;
                    }
                    hotKeyConfig();
                });

                function hotKeyConfig() {
                    hotkeys.bindTo(scope)
                        .add({
                            combo: 'up',
                            description: 'Up',
                            callback: function(e) {

                                if (scope.selectedIndex == 0) {
                                    return;
                                }
                                scope.selectedIndex--;
                                // e.preventDefault();
                            }
                        })
                        .add({
                            combo: 'down',
                            description: 'Down',
                            callback: function(e) {

                                if (scope.selectedIndex == scope.collection.length - 1) {
                                    return;
                                }
                                scope.selectedIndex++;
                                // e.preventDefault();
                            }
                        })
                        .add({
                            combo: 'space',
                            description: 'Enter',
                            callback: function(e) {
                                if (scope.selectedIndex >= 0) {
                                    scope.collection[scope.selectedIndex].wasHit = true;
                                    scope.onEnter({ row: scope.collection[scope.selectedIndex] });
                                }
                                e.preventDefault();
                            }
                        })
                }
                // element.bind('keydown', function(e) {
                //     console.log(scope.selectedIndex);
                //     if (e.keyCode == 38) { // Up Arrow
                //         if (scope.selectedIndex == 0) {
                //             return;
                //         }
                //         scope.selectedIndex--;
                //         e.preventDefault();
                //     } else if (e.keyCode == 40) { // Down Arrow
                //         if (scope.selectedIndex == scope.collection.length - 1) {
                //             return;
                //         }
                //         scope.selectedIndex++;
                //         e.preventDefault();
                //     } else if (e.keyCode == 13) { // Enter
                //         if (scope.selectedIndex >= 0) {
                //             scope.collection[scope.selectedIndex].wasHit = true;
                //             scope.onEnter({ row: scope.collection[scope.selectedIndex] });
                //         }
                //         e.preventDefault();
                //     }

                //     scope.$apply();
                // });
            }
        };
    }

    function cdArrowRow($timeout) {
        return {
            restrict: 'A',
            scope: {
                row: '=',
                selectedIndex: '=',
                rowIndex: '=',
                selectedClass: '=',
                enterClass: '=',
                enterDuration: '='
            },
            link: function(scope, element, attrs, ctr) {
                // Apply provided CSS class to row for provided duration
                scope.$watch('row.wasHit', function(newValue) {
                    if (newValue === true) {
                        element.addClass(scope.enterClass);
                        $timeout(function() { scope.row.wasHit = false; }, scope.enterDuration);
                    } else {
                        element.removeClass(scope.enterClass);
                    }
                });

                // Apply/remove provided CSS class to the row if it is the selected row.
                scope.$watch('selectedIndex', function(newValue, oldValue) {
                    if (newValue === scope.rowIndex) {
                        element.addClass(scope.selectedClass);
                    } else if (oldValue === scope.rowIndex) {
                        element.removeClass(scope.selectedClass);
                    }
                });

                // Handles applying/removing selected CSS class when the collection data is filtered.
                scope.$watch('rowIndex', function(newValue, oldValue) {
                    if (newValue === scope.selectedIndex) {
                        element.addClass(scope.selectedClass);
                    } else if (oldValue === scope.selectedIndex) {
                        element.removeClass(scope.selectedClass);
                    }
                });
            }
        }
    }
})();