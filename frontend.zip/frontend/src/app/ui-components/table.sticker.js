(function () {
    'use strict';

    angular.module('app').directive('uiTableSticker',directive);
    

    /** @ngInject **/
    function directive() {
        return {
            link : function (scope, $element,attrs) {

                var options = Object.assign({
                    fixedOffset : $('#header-navbar').innerHeight()  //outerHeight()
                },attrs);

                $(window).on('resize',function (e) {
                    $element.stickyTableHeaders(options);
                   
                });

                $('.table-responsive').scroll(function () {
                    $element.stickyTableHeaders(options);
                });

                $element.stickyTableHeaders(options);
             

            }
        };
    }
})();
// (function () {
//     'use strict';

//     angular.module('app').directive('hideHeader',directive);

//     /** @ngInject **/
//     function directive($document,$window) {
//         return {
//             link : function (scope, element,attrs) {
//             var $page = angular.element($window); 
//             $document.bind('scroll', function () {
//                 var $el   = element[0];
//                 // var $thead = $($el).find('.tableFloatingHeaderOriginal').getBoundingClientRect();
//                 console.log($el)
//                 // console.log($thead)
                

//                 var windowScrollTop = $page[0].pageYOffset
//                 console.log(windowScrollTop)
//                 var elScrollTop     = $($el).offset().top;
//                 console.log(elScrollTop);
//                 if((windowScrollTop -20 < elScrollTop)&& (windowScrollTop +10 > elScrollTop)){
//                     console.log('1')
//                     $($el).find('.tableFloatingHeaderOriginal').addClass('hidden');
//                 }
//                 else{
//                      console.log('2')
//                      $($el).find('.tableFloatingHeaderOriginal').removeClass('hidden');
//                 }
              
//             })
                    

              

//             }
//         };
//     }
// })();


