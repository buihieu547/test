
(function () {
    'use strict';

    angular.module('app').directive('lightBox',/** @ngInject */function($sce){
        return {
            link: function (scope, element, attrs) {

                var url = attrs.ngSrc || attrs.src;

                if(url)
                {
                    element.magnificPopup({
                        items: {
                            src: $sce.trustAsResourceUrl(url)
                        },
                        type: 'image' // this is default type
                    });
                }
            }
        }
    });
})();
