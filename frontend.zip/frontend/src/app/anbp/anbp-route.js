(function() {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('anbp.index', {
                url: '/',
                templateUrl: 'app/anbp/module/home/home.html',
                controller: 'home-anbp.controller',
                ncyBreadcrumb: {
                    label: 'Home'
                },
                // middleware: ['auth-client']
            })
            .state('anbp.category', {
                url: '/category?category_id',
                abstract: true,
            })
            .state('anbp.category.product', {
                url: '/product?brand_id&type&name',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/product/product.html',
                        controller: 'product-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Product',
                    parent: 'anbp.index'
                },
                // middleware: ['auth']
            })
            .state('anbp.promotion', {
                url: '/promotion/:id',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/promotion/promotion.html',
                        controller: 'promotion-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Promotion',
                    parent: 'anbp.index'
                },
                // middleware: ['auth']
            })
            .state('anbp.category.product.detail', {
                url: '/detail/:id',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/product-detail/detail.html',
                        controller: 'product-detail-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Detail'
                },
                params: {
                    item_data: null
                },
                // middleware: ['auth']
            })
            .state('anbp.cart', {
                url: '/cart',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/cart/cart.html',
                        controller: 'cart-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Cart',
                    parent: 'anbp.index'
                },
                // middleware: ['auth']
            })
            .state('anbp.quote', {
                url: '/quote',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/quote/quote.html',
                        controller: 'quote-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Quote',
                    parent: 'anbp.index'
                },
                // middleware: ['auth']
            })
            .state('anbp.cart.checkout', {
                url: '/checkout',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/checkout/checkout.html',
                        controller: 'checkout-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Checkout'
                },
                params: { data: {} },
                // middleware: ['auth']
            })
            // .state('anbp.create', {
            //     url: '/create',
            //     views: {
            //         "@anbp": {
            //             templateUrl: 'app/orders/orders.create.html',
            //             controller: 'orders.create.controller',
            //         }
            //     },
            //     ncyBreadcrumb: {
            //         label: 'Create Order'
            //     },
            //     // middleware: ['auth']
            // })
            .state('anbp.signin', {
                url: '/sign-in',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/account/account.html',
                        controller: 'anbp.account.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Sign in',
                    parent: 'anbp.index'
                },
                params: { redirect: "", id: null }
            }).state('anbp.signup', {
                url: '/sign-up',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/account/account.html',
                        controller: 'anbp.account.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Sign up',
                    parent: 'anbp.index'
                }
            })
            .state('anbp.account', {
                url: '/account',
                ncyBreadcrumb: {
                    label: 'Account',
                },
                abstract: true
            })
            .state('anbp.account.orders', {
                url: '/profile',
                ncyBreadcrumb: {
                    label: 'Profile',
                    parent: 'anbp.index'
                },
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/account/account-orders.html',
                        controller: 'account-orders-anbp.controller',
                    }
                },
                // middleware: ['auth-client']
            })
            .state('anbp.account.rma', {
                url: '/rma',
                ncyBreadcrumb: {
                    label: 'RMA',
                    parent: 'anbp.index'
                },
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/account/account-rma.html',
                        controller: 'anbp.account.rma.controller',
                    }
                },
                middleware: ['auth-client']
            })
            .state('anbp.catalog', {
                url: '/catalog',
                views: {
                    "@anbp": {
                        templateUrl: 'app/anbp/module/catalog/catalog.html',
                        controller: 'catalog-anbp.controller',
                    }
                },
                ncyBreadcrumb: {
                    label: 'Catalog',
                    parent: 'anbp.index'
                },
                // middleware: ['auth']
            })
            
    }
})();
