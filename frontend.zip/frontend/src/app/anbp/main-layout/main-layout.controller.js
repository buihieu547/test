(function () {
    'use strict';

    angular
        .module('app')
        .controller('main-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $rootScope) {

    }
})();
