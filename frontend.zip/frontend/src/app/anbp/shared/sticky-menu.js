(function() {
    'use strict';

    angular.module('app').directive('stickyMenu', directive);

    /** @ngInject */
    function directive($parse, $window) {

        function stickyMenuLink(scope, element) {
            var w = angular.element($window),
                size = element[0].clientHeight,
                top = 0;

            function toggleStickyNav() {
                if (!element.hasClass('controls-fixed') && $window.pageYOffset > top + size) {
                    element.addClass('controls-fixed');
                    element.addClass('fixed-cart');
                    
                } else if (element.hasClass('controls-fixed') && $window.pageYOffset <= top + size) {
                    element.removeClass('controls-fixed');
                    element.removeClass('fixed-cart');
                    
                }
            }

            scope.$watch(function() {
                return element[0].getBoundingClientRect().top + $window.pageYOffset;
            }, function(newValue, oldValue) {
                if (newValue !== oldValue && !element.hasClass('controls-fixed')) {
                    top = newValue;
                }
            });

            w.bind('resize', function stickyNavResize() {
                element.removeClass('controls-fixed');
                top = element[0].getBoundingClientRect().top + $window.pageYOffset;
                toggleStickyNav();
            });
            w.bind('scroll', toggleStickyNav);
        }


        return {
            scope: {},
            restrict: 'A',
            link: stickyMenuLink
        };
    }
})();