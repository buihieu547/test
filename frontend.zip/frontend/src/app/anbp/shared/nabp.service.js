(function() {
    'use strict';

    angular.module('app').service('nabpAPI', service);

    function service(API, $http) {

        this.getWine = function(params) {
            var url = 'item';
            return API.get(url, params);

        }

        this.getReportTopProductCategory = function() {
            var url = 'reports/top-product-sold-by-category';
            return API.get(url);

        }

        this.getReportOrderHistory = function() {
            var url = 'reports/order-history';
            return API.get(url);
        }

        this.getReportSOStatus = function() {
            var url = 'reports/sale-order-status';
            return API.get(url);
        }

        this.getReportTopPromtional = function() {
            var url = 'reports/top-promotional-products-received';
            return API.get(url);
        }

        this.getReportTopMoneyPromtional = function() {
            var url = 'reports/top-money-spend-for-promotional-program';
            return API.get(url);
        }

        this.getReportTotalBought = function() {
            var url = 'reports/total-bought-quantity';
            return API.get(url);
        }

        this.getReportMostBuying = function() {
            var url = 'reports/most-buying-category';
            return API.get(url);
        }

        this.getDetailWine = function(id) {
            var url = 'item/' + id;
            return API.get(url);

        }

        this.getListBundle = function(params) {
            var url = 'bundle/get-list-available';
            return API.get(url, params);
        }

        this.getListBundle = function(params) {
            var url = 'bundle/get-list-available';
            return API.get(url, params);
        }

        this.getListWinePromotion = function(id, params) {
            var url = 'item/program/' + id;
            return API.get(url, params);
        }


        this.getListCategory = function() {
            var url = 'item/reference/brands';
            return API.get(url);
        }

        this.getListFilter = function() {
            var url = 'item/reference/filter-fields';
            return API.get(url);
        }

        this.getLisProgramBuyer = function(id) {
            var url = 'buyer/active-programs/' + id;
            return API.get(url);
        }

        this.getLisProgramAll = function() {
            var url = 'program/general';
            return API.get(url);
        }

        this.getWishList = function() {
            var url = 'wish-list/index';
            return API.get(url);
        }

        this.addWishList = function(params) {
            var url = 'wish-list/create';
            return API.post(url, params);
        }

        this.updateWishList = function(id, params) {
            var url = 'wish-list/update/' + id;
            return API.post(url, params);
        }

        this.createQuotation = function(params) {
            var url = 'quotation/create';
            return API.post(url, params);
        }
    }
})();