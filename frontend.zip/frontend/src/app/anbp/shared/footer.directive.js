/**
 * Author : huy da0
 * Date   : 2017-11-08
 */

(function () {
    'use strict';

    angular.module('app').directive('footerAnbp',directive);

    /** @ngInject */
    function directive($parse) {
        return {
            restrict : 'E',
            templateUrl : 'app/anbp/shared/footer.html',
            link : function ($scope, $element, $attrs, ngModel, $state) {
                
            }
        }
    }
})();
