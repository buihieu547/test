(function() {
    'use strict';

    angular.module('app').service('storageANBP', service);

    function service($state, $stateParams, API, nabpAPI, $http, $localStorage, $sessionStorage, $rootScope) {
        $rootScope.currentWishList = [];
        $rootScope.quotationList = $sessionStorage.quotationList || [];
        /**CART */
        this.getTotalItemInCart = function() {
            var total = 0;
            for (var i in $rootScope.cartItems) {
                if ($rootScope.cartItems[i].order_quantity == undefined) {
                    continue;
                } else {
                    total += Number($rootScope.cartItems[i].order_quantity)
                }
            }
            return total;
        }

        this.enableAddCart = function(item) {
            if (!item) return;
            if (!item.item_type) {
                item.item_type = (item.detail) ? 'bundle' : 'wine';
            }
            var existed = ($rootScope.cartItems || []).find(function(it) {
                var id1 =  it.item_id || it.id;
                var id2 = item.item_id || item.id;
                return id1 == id2 && it.item_type == item.item_type;
            })
            return existed;
        }

        this.addToCart = function(addItem) {
                var item = angular.copy(addItem);
                if(!item.item_type) {
                    if (item.detail || item.buying_item_type == "bundle") {
                        item.isBundle = true;
                        item.item_type = "bundle";
                    } else {
                        item.item_type = "wine";
                    }
                }

                item.item_id = item.item_id || item.id;

                checkExisted(item);
                $rootScope.showCart = item;
                $sessionStorage.cartItems = $rootScope.cartItems;
            }
            /**WISHLIST */

        
            this.enableAddWishList = function(item) {
            if (!item) return;
            if (!item.item_type) {
                item.item_type = (item.detail) ? 'bundle' : 'wine';
            }

            var existed = $rootScope.currentWishList.find(function(it) {
                var id1 = it.item_id || it.id;
                var id2 = item.item_id || item.id;
                return id1 == id2 && it.item_type == item.item_type;
            })
            return existed;
        }

        this.enableAddQuote = function(item) {
            if (!item) return;
            if (!item.item_type) {
                item.item_type = (item.detail) ? 'bundle' : 'wine';
            }
            var existed = ($rootScope.quotationList || []).find(function(it) {
                var id1 =  it.item_id || it.id;
                var id2 = item.item_id || item.id;
                return id1 == id2 && it.item_type == item.item_type;
            })
            return existed;
        }

        this.addToQuote = function(addItem) {
                var item = angular.copy(addItem);
                if(!item.item_type) {
                    if (item.detail || item.buying_item_type == "bundle") {
                        item.isBundle = true;
                        item.item_type = "bundle";
                    } else {
                        item.item_type = "wine";
                    }
                }

                item.item_id = item.item_id || item.id;

                checkExistedQuote(item);
                $sessionStorage.quotationList = $rootScope.quotationList;
            }
            /**WISHLIST */

        
            this.enableAddWishList = function(item) {
            if (!item) return;
            if (!item.item_type) {
                item.item_type = (item.detail) ? 'bundle' : 'wine';
            }

            var existed = $rootScope.currentWishList.find(function(it) {
                var id1 = it.item_id || it.id;
                var id2 = item.item_id || item.id;
                return id1 == id2 && it.item_type == item.item_type;
            })
            return existed;
        }


        this.getWishList = function() {
                nabpAPI.getWishList().then(function(res) {
                    $rootScope.currentWishList = res.data.results.rows;
                })
        }

        var getWishList = this.getWishList;

        function initWishList() {
            if ($sessionStorage.CL_USER_DATA) {
                getWishList();
            } 
        }

        initWishList();

        this.addWishList = function(addItem) {
            if (!$sessionStorage.CL_USER_DATA) {
                 $state.go("anbp.signin", { redirect: $state.current.name, id: $stateParams.id });
                 return;
            }

            var item = angular.copy(addItem);
            if (item.detail || item.buying_item_type == "bundle") {
                item.isBundle = true;
                item.item_type = "bundle";
            } else {
                item.item_type = "wine";
            }

            var existed = $rootScope.currentWishList.find(function(it) {
                return it.item_id == item.item_id && it.item_type == item.item_type;
            })

            if (!existed) {
                nabpAPI.addWishList((item.isBundle) ? { bundle_id: item.item_id || item.id } : { wine_id: item.item_id || item.id }).then(function(res) {
                        initWishList();
                    })
                    // $localStorage.wishListItems = this.wishListItems;
            }
        }

        this.removeWishList = function(index) {
            var id =  $rootScope.currentWishList[index].id;
            $rootScope.currentWishList.splice(index, 1);
            nabpAPI.updateWishList(id, { status: 0 }).then(function(res) {})
        }

        var oneItemImages = [
            '../../../assets/img/Content/cloth-1.jpg',
            '../../../assets/img/Content/cloth-2.jpg',
            '../../../assets/img/Content/cloth-3.jpg',
            '../../../assets/img/Content/cloth-4.jpg',
            '../../../assets/img/Content/cloth-5.jpg',
        ]

        var bundleImages = [
            '../../../assets/img/Content/cloth-1.jpg',
            '../../../assets/img/Content/cloth-2.jpg',
            '../../../assets/img/Content/cloth-3.jpg',
            '../../../assets/img/Content/cloth-4.jpg',
            '../../../assets/img/Content/cloth-5.jpg',
        ]

        this.getOneItemImage = function(flag) {
            var index = Math.floor(Math.random() * 5);
            if (flag) return bundleImages[index];
            return oneItemImages[index];
        }

        this.dividNumber = function(num, discount) {
            num = num || 0;
            if (discount) {
                num = num * (100 - discount) / 100;
            }
            var n = Math.floor(num);
            var dec = String(Math.floor(((num - n).toFixed(2)) * 100));
            return { n: n, dec: padZero(2, dec) };
        }

        this.getSubTotalPrice = function() {
            var result = 0;
            for (var i in $rootScope.cartItems) {
                if ($rootScope.cartItems[i].order_quantity == undefined) {
                    continue;
                } else {
                    result += $rootScope.cartItems[i].resale_price * $rootScope.cartItems[i].order_quantity;

                }
            }
            return result;
        }

        this.getDiscountTotal = function() {
            var result = 0;
            for (var i in $rootScope.cartItems) {
                if ($rootScope.cartItems[i].order_quantity == undefined) {
                    continue;
                } else {
                    result += ($rootScope.cartItems[i].promotion_discount_amount || 0);

                }
            }
            return result;
        }

        //Helper function
        function padZero(len, c) {
            var s = c,
                c = c || '0';
            while (s.length < len) s = c + s;
            return s;
        }

        function checkExisted(itemToAdd) {
            itemToAdd['order_quantity'] = itemToAdd['order_quantity'] || 1;
            itemToAdd['resale_price'] = itemToAdd['resale_price'] || itemToAdd['sale_price'] || itemToAdd['price'];

            var index = Object.keys($rootScope.cartItems).find(function(id) {
                return $rootScope.cartItems[id].item_id == itemToAdd.item_id && $rootScope.cartItems[id].item_type == itemToAdd.item_type;
            });

            if (index) {
                $rootScope.cartItems[index].order_quantity = Number($rootScope.cartItems[index].order_quantity) + 1;

            } else {
                $rootScope.cartItems.push(itemToAdd || {});
            }
        }

        function checkExistedQuote(itemToAdd) {
            itemToAdd['order_quantity'] = itemToAdd['order_quantity'] || 1;
            itemToAdd['resale_price'] = itemToAdd['resale_price'] || itemToAdd['sale_price'] || itemToAdd['price'];

            var index = Object.keys($rootScope.quotationList).find(function(id) {
                return $rootScope.quotationList[id].item_id == itemToAdd.item_id && $rootScope.quotationList[id].item_type == itemToAdd.item_type;
            });

            if (index) {
                $rootScope.quotationList[index].order_quantity = Number($rootScope.quotationList[index].order_quantity) + 1;

            } else {
                $rootScope.quotationList.push(itemToAdd || {});
            }
        }
    }
})();