/**
 * Author : huy da0
 * Date   : 2017-11-08
 */

(function() {
    'use strict';

    angular.module('app').directive('ratingStar', directive);

    /** @ngInject */
    function directive($parse) {
        return {
            restrict: 'A',
            scope: {
                ratingNumber: '='
            },
            link: function(scope, $element, $attrs) {
                scope.currentStar = -1;
                scope.currentClick = -1;
    
                var ele = $element.find('span.fa');
                var doms = [];
                (ele || []).each(function(index, element) {
                    var dom = angular.element(ele[index]);
                    doms[index] = dom;
                    dom.bind("mouseover", function() {
                        scope.currentStar = index;
                    })

                    dom.bind("mouseleave", function() {
                            scope.currentStar = scope.currentClick;
                    })

                    dom.bind("click", function() {
                        if(scope.currentClick < 0) {
                            scope.ratingNumber =   (scope.ratingNumber|| 0) + 1;                        
                        }
                        scope.currentClick = index;                  
                        updateStar();
                    })
                });

                scope.$watch('currentStar', function(newVal, oldVal) {
                    updateStar();
                });

                function updateStar() {
                    if( scope.currentClick > -1) return;
                    var limit = (scope.currentStar >=0)? scope.currentStar: scope.currentClick;
                    for (var i = 0; i < doms.length; i++) {
                        if(i <= limit) {
                            doms[i].removeClass("fa-star-o");
                            doms[i].addClass("fa-star");
                        } else {
                            doms[i].addClass("fa-star-o");
                            doms[i].removeClass("fa-star");
                        }
                     
                    }
                }
            }
        }
    }
})();