/**
 * Author : huy da0
 * Date   : 2017-11-08
 */

(function() {
    'use strict';

    angular.module('app').directive('filterWine', directive);

    /** @ngInject */
    function directive($parse, nabpAPI) {
        return {
            restrict: 'E',
            scope: {
                params: '='
            },
            templateUrl: 'app/anbp/shared/filter.html',
            link: function($scope, $element, $attrs, ngModel) {
                $scope.listFilter = {};
                $scope.listFilter['price'] = [{ id: 1, price: '<50', max_price: 49.99, min_price: 0 }, { id: 2, price: '50-100', max_price: 99.99, min_price: 50 }, { id: 3, price: '100 - 300', max_price: 299.99, min_price: 100 }, { id: 4, price: '300-500', max_price: 499.99, min_price: 300 }, { id: 5, price: '>500',max_price: null, min_price: 500 }];


                function retrieveParam() {
                    var brands = ($scope.listFilter['brands'] || []).filter(function(item) {
                        return item.value;
                    }).map(function(item) {
                        return item.brand_id;
                    });

                    var categories = ($scope.listFilter['categories'] || []).filter(function(item) {
                        return item.value;
                    }).map(function(item) {
                        return item.category_id;
                    });

                    var countries = ($scope.listFilter['countries'] || []).filter(function(item) {
                        return item.value;
                    }).map(function(item) {
                        return item.country_code;
                    });

                    var grape_varieties = ($scope.listFilter['grape_varieties'] || []).filter(function(item) {
                        return item.value;
                    }).map(function(item) {
                        return item.grape_variety_id;
                    });

                    var  min_price = 0, max_price = 0;
                    var price = ($scope.listFilter['price'] || []).filter(function(item) {
                        return item.value;
                    }).map(function(item) {
                        if(item.min_price < min_price) {
                            min_price = item.min_price;
                        }

                        if(item.max_price > max_price) {
                            max_price = item.max_price;
                            min_price = item.min_price;
                        }
                        if(item.max_price === null) max_price = null;
                        return item;
                    });

                    return {min_price: min_price, max_price: max_price, brand_id: brands, category_id: categories, country_code: countries, grape_variety_id: grape_varieties };
                }

                function getListFilter() {
                    nabpAPI.getListFilter().then(function(result) {
                        var data = result.data.results;
                        $scope.listFilter['brands'] = data.brands;
                        $scope.listFilter['categories'] = data.categories;
                        $scope.listFilter['countries'] = data.countries;
                        $scope.listFilter['grape_varieties'] = data.grape_varieties;

                        $scope.$watch('listFilter', function(newVal, oldVal) {
                        if (newVal && !angular.equals(newVal , {}) && !angular.equals(oldVal, {})) {
                                $scope.params = retrieveParam();
                            }
                        }, true);
                    })
                }

                (function() {
                    getListFilter()
                })();

            }
        }
    }
})();