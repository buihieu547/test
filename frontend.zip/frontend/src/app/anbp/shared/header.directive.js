/**
 * Author : huy da0
 * Date   : 2017-11-08
 */

(function() {
    'use strict';

    angular.module('app').directive('headerAnbp', directive);

    /** @ngInject */
    function directive($parse, $state, $stateParams, $localStorage, storageANBP, nabpAPI, API, $sessionStorage, tmhDynamicLocale, gettextCatalog) {
        return {
            restrict: 'E',
            templateUrl: 'app/anbp/shared/header.html',
            controller: function($scope, $rootScope, $state, $controller) {
                var $listController = $controller('abstract.list.controller', { $scope: $scope });
                /**
                 * CART HANDLE
                 */
                $rootScope.cartItems = $sessionStorage.cartItems || [];
                $rootScope.showCart = false;

                $rootScope.totalItems = 0;

                $scope.getTotal = function() {
                    return storageANBP.getTotalItemInCart();
                }

                $scope.search = {};
                $rootScope.currentBuyer = angular.copy($sessionStorage.CL_USER_DATA);
                $scope.closeCart = function() {
                    $rootScope.showCart = false;
                }

                $scope.languageConfig = [
                    { value: "en", image: "./assets/img/flag/Flag_Global.png", name: "English", align: 'left' },
                    { value: "he", image: "./assets/img/flag/Flag_Israel.png", name: "Hebrew", align: 'right' },
                ]



                //Language Handle
                function setLanguage() {
                    var language = $localStorage.currentLanguge || 'en';
                    var data = $scope.languageConfig.find(function(item) {
                        return item.value == language;
                    })

                    $rootScope.currentLanguge = {
                        value: language,
                        image: data.image,
                        name: data.name,
                        align: data.align,
                    };

                    tmhDynamicLocale.set($rootScope.currentLanguge.value);
                    gettextCatalog.setCurrentLanguage($rootScope.currentLanguge.value);
                }

                function getListCategory() {
                    nabpAPI.getListCategory().then(function(result) {
                        var data = result.data.results;
                        data = (data.length > 0) ? data : null;
                        $scope.currentCategoryList = data || [

                            {
                                "category_id": 1,
                                "category_name": "Red Wine",
                                "category_code": "RW",
                                "brands": [{
                                        "brand_id": 1,
                                        "brand_name": "Brand #1",
                                        "brand_code": "B1"
                                    },
                                    {
                                        "brand_id": 2,
                                        "brand_name": "Brand #2",
                                        "brand_code": "B2"
                                    }
                                ]
                            },
                            {
                                "category_id": 2,
                                "category_name": "White Wine",
                                "category_code": "WW",
                                "brands": [{
                                        "brand_id": 3,
                                        "brand_name": "Brand #3",
                                        "brand_code": "B3"
                                    },
                                    {
                                        "brand_id": 4,
                                        "brand_name": "Brand #4",
                                        "brand_code": "B4"
                                    },
                                    {
                                        "brand_id": 5,
                                        "brand_name": "Brand #5",
                                        "brand_code": "B5"
                                    }
                                ]

                            },
                            {
                                "category_id": 3,
                                "category_name": "Alcohol",
                                "category_code": "AL",
                                "brands": [{
                                    "brand_id": 6,
                                    "brand_name": "Brand #6",
                                    "brand_code": "B6"
                                }]
                            },
                        ];
                        // $scope.currentCategoryList = data;
                    })
                }

                $scope.changeLanguage = function(value) {
                    $localStorage.currentLanguge = value;
                    setLanguage();
                    $state.go($state.current, {}, { reload: true });
                }

                $scope.searchCategory = function(type, data) {
                    var params = { type: type };
                    $state.go("anbp.category.product", angular.merge({}, params, data), { inherit: false })
                }

                $scope.searchWine = function() {
                    var params = $scope.search;
                    $state.go("anbp.category.product", Object.assign({}, params), { inherit: false })
                }

                $scope.goToCart = function() {
                    $scope.closeCart();
                    $state.go("anbp.cart");
                }

                $scope.goToCatalog = function() {
                    $state.go("anbp.catalog");
                }

                $scope.goToDetail = function(item, type) {
                    if (type) {
                        item.type = type;
                    }
                    if (item.sale_price) {
                        item.resale_price = item.sale_price;
                    }
                    if (item.id) {
                        item.item_id = item.id
                    }
                    $scope.closeCart();
                    $state.go("anbp.category.product.detail", { id: item.item_id, type: type, item_data: item });
                }

                $scope.logoutAction = function() {
                    $sessionStorage.$reset();
                    $rootScope.currentWishList = [];
                    $state.go('anbp.index');
                    $rootScope.currentBuyer = '';
                };

                function getBuyer() {
                    var id = $sessionStorage.CL_USER_DATA.company_id;
                    if (id) {
                        API.get('buyer/detail/' + id).success(function(res) {
                            $rootScope.buyerData = res.results;
                        });
                    }
                }

                function initBuyer() {
                    if ($sessionStorage.CL_USER_DATA) {
                        getBuyer();
                    }
                }

                (function init() {
                    setLanguage();
                    getListCategory();
                    initBuyer();
                })()
            }
        }
    }
})();