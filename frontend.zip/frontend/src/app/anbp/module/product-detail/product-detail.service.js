(function () {
    'use strict';

    angular.module('app').service('productDetailAPI', service);

    function service(API, $q, $interval, $http) {
        this.viewDetail = viewDetail;

        function viewDetail(id) {
            var url = [ 'bundle', id ].join( '/' );
            return API.get(url);
        }
    }
})();