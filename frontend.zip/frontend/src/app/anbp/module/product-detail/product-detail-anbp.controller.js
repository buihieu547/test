(function() {
    'use strict';

    angular
        .module('app')
        .controller('product-detail-anbp.controller', controller);

    /** @ngInject */
    function controller($sce, $scope, storageANBP, $timeout, $state, $rootScope, $sessionStorage,
        $stateParams, $controller, nabpAPI, productDetailAPI) {

        $scope.productDetail = {};
        $scope.currentWine = {};
        var $listController = $controller('abstract.list.controller', { $scope: $scope });
        $scope.list = { items: [] };

        /** Init  */
        function init() {
            $scope.isBundle = $stateParams.type == 2;
            if (!$scope.isBundle) {
                getDetailWine();
            } else {
                viewDetail();
            }

        }

        $scope.addToQuote = function(item) {
            if ($scope.enableAddQuote(item)) {
                return $state.go('anbp.quote');
            }
            // console.log($rootScope.cartItems);
            storageANBP.addToQuote(item);
        }

        $scope.enableAddQuote = function(item) {
            return storageANBP.enableAddQuote(item);
        }

        $scope.tooltips = [$sce.trustAsHtml("<span class='rating-score'>1</span><span class='rating-text'>Not For Me</span>"),
            $sce.trustAsHtml("<span class='rating-score'>2</span><span class='rating-text'>Drinkable</span>"),
            $sce.trustAsHtml("<span class='rating-score'>3</span><span class='rating-text'>Good</span>"),
            $sce.trustAsHtml("<span class='rating-score'>4</span><span class='rating-text'>Very Good</span>"),
            $sce.trustAsHtml("<span class='rating-score'>5</span><span class='rating-text'>Fantastic</span>")
        ]

        $timeout(function() {
            init();
            var randomUser = Math.floor(Math.random() * 500);
            var randomTime = Math.floor(Math.random() * 5) || 1;

            $timeout(function() {
                toastr.success(randomUser + ' others viewing this product right now.', '', {
                    toastClass: 'fa custom-toastr user-toastr',
                    positionClass: 'toast-bottom-right',
                    timeOut: 5000,
                    preventDuplicates: true,
                    preventOpenDuplicates: true,
                });
            }, 1000)

            $timeout(function() {
                toastr.success('Most recent ordering for this product: less than ' + randomTime + ' minutes ago.', '', {
                    toastClass: 'fa custom-toastr clock-toastr',
                    timeOut: 5000,
                    preventDuplicates: true,
                    preventOpenDuplicates: true,
                });
            }, 4000)

            initLightSlider();
        })

        function getDetailWine() {
            nabpAPI.getDetailWine($stateParams.id).success(function(res) {
                $scope.currentWine = res.results;
                $scope.currentWine.order_quantity = 1;
                $scope.currentWine.sizeList = $scope.currentWine.size.split(",");
                $scope.currentWine.resale_price = $scope.currentWine.sale_price_for_buyer || $scope.currentWine.resale_price || $scope.currentWine.sale_price;
            });
        }

        function viewDetail() {
            var _id = $stateParams.id;

            productDetailAPI.viewDetail(_id).then(function(res) {
                try {
                    if (res.status) {
                        $scope.currentWine = res.data.results;
                        $scope.currentWine.resale_price = $scope.currentWine.sale_price_for_buyer || $scope.currentWine.resale_price || $scope.currentWine.sale_price;
                        $scope.productDetail = res.data.results;
                    }
                } catch (e) {
                    console.log(e);
                }
            }, function(error) {

            });
        }

        $scope.addToCart = function(item) {
            if ($scope.enableAddCart(item)) {
                return $state.go('anbp.cart');
            }
            storageANBP.addToCart(item);

        }

        $scope.enableAddCart = function(item) {
            return storageANBP.enableAddCart(item);
        }


        $scope.addToWishList = function(item) {
            if ($scope.enableAddWishList(item)) {
                // $state.go();
                return;
            }
            storageANBP.addWishList(item);
            // $scope.currentWishList = storageANBP.getWishList();
        }

        $scope.enableAddWishList = function(item) {
            return storageANBP.enableAddWishList(item);
        }


        // $scope.currentWishList = storageANBP.getWishList();
        $scope.dividNumber = function(num) {
            return storageANBP.dividNumber(num);
        }

        function initLightSlider() {
            $timeout(function() {
                angular.element('#lightSliderDetail').lightSlider({
                    gallery: true,
                    item: 1,
                    rtl: $rootScope.currentLanguge.align == 'right',
                    loop: true,
                    controls: true,
                    slideMargin: 0,
                    thumbItem: 4,
                });

                var imgList = angular.element(" .lslide  img");
                for (var i = 0; i < imgList.length; i++) {
                    if (angular.isNumber(imgList[i])) continue;
                    new Drift(imgList[i], {
                        paneContainer: document.querySelector('.driftbox'),
                        inlinePane: true,
                        inlineOffsetY: 0,
                        inlineOffsetX: 0,
                        containInline: false,
                        hoverBoundingBox: true
                    })
                }

            }, 800)

        }

        $scope.changeImage = function(item) {
            // $scope.currentWine.wine_images[0].thumb_img_temp =   '../../../assets/img/Content/cloth-2.jpg';
        }

        $scope.resetImage = function(item) {
            // $scope.currentWine.wine_images[0].thumb_img_temp = null;
        }
        
        $scope.activeColor = function(e) {
            var ele = angular.element(e.currentTarget);
           angular.element(".color-box").removeClass("selected-color");
            ele.addClass("selected-color");

        }

        $scope.goToDetail = function(item) {
            item.type = 1;
            $state.go("anbp.category.product.detail", { id: item.wine_id || item.id, type: item.type, item_data: item }, { reload: true });
        }
    }
})();