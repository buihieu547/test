(function() {
    'use strict';

    angular
        .module('app')
        .controller('catalog-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, storageANBP, catalogAPI, $state, $location, $stateParams, $rootScope, $sessionStorage, $localStorage, $controller, productAPI, API, orderAPI, accountAPI) {

        $scope.currentPosition = 0;
        $scope.catalogData = {
            catalog: "",
            category: "",
            item: ""
        }

        $scope.images = {
            catalog: [
                'http://www.bluemaize.net/im/appliances/the-wine-enthusiast-11.jpg',
                'http://www.chateaukefraya.com//corporate3/images/677/PRESS-COVER-1920X2930-SOMMELIERS-INTERNATIONAL---2016.jpg'
            ],
            category: [],
        }

        $scope.config = {
            active: null
        }

        $scope.initData = [];

        var drift = null;

        $scope.moveNext = function(pos, type, data) {
            switch (type) {
                case 1:
                    $scope.catalogData.catalog = data;
                    break;
                case 2:
                    $scope.catalogData.category = data;
                    $scope.slides = [];
                    getListItem();
                    break;
                case 3:
                    $scope.catalogData.item = data;
                    // $scope.slides = angular.copy($scope.catalogData.category.items);
                    break;
                default:
                    break;
            }

            $scope.currentPosition++;
            if (pos >= 0) {
                $scope.config.active = pos;
            }
            if ($scope.currentPosition == 3) {
                initLightSlider();
                initZoom();
            }
        }
        $scope.back = function() {
            $scope.currentPosition--;
            $scope.initData = [];
        }

               
        $scope.activeColor = function(e) {
            var ele = angular.element(e.currentTarget);
           angular.element(".color-box").removeClass("selected-color");
            ele.addClass("selected-color");

        }
        
        $scope.$watch("config.active", function(newVal, oldVal) {
            if (newVal !== null && oldVal !== null) {
                $timeout(function() {
                    initLightSlider();
                    initZoom();
                    // angular.element("html").trigger('resize');
                })
            }
        })

        function getListCatalog() {
            var params = { page: 1, limit: 100 };
            API.get("catalog/list-grouped", params).then(function(res) {
                $scope.catalogList = res.data.results.rows;
            })
        }

        function getListItem() {
            var params = { page: 1, limit: 100 };
            var catalog_id = $scope.catalogData.catalog.id;
            var category_id = $scope.catalogData.category.category_id;

            API.get("catalog/" + catalog_id + "/category/" + category_id, params).then(function(res) {
                $scope.slides = angular.copy(res.data.results);
            })
        }

        function initZoom() {
            $timeout(function() {
                var id = '#lightSlider' + $scope.config.active;
                var imgList = angular.element(id + " .lslide  img");
                for (var i = 0; i < imgList.length; i++) {
                    if (angular.isNumber(imgList[i])) continue;
                    new Drift(imgList[i], {
                        paneContainer: document.querySelector('.driftbox'),
                        inlinePane: true,
                        inlineOffsetY: 0,
                        inlineOffsetX: 0,
                        containInline: false,
                        hoverBoundingBox: true
                    })
                }
            }, 350)
        }



        function initLightSlider() {
            $timeout(function() {
                var id = $scope.config.active;
                if ($scope.config.active === null || $scope.initData.indexOf(id) != -1) return;
                angular.element('#lightSlider' + id).lightSlider({
                    gallery: true,
                    item: 1,
                    rtl: $rootScope.currentLanguge.align == 'right',
                    loop: true,
                    controls: false,
                    slideMargin: 0,
                    thumbItem: 9,
                });
                $scope.initData.push(id);
            }, 300)
        }

        $timeout(function() {
            getListCatalog();
        })

    }
})();