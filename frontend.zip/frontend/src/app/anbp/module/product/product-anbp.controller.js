(function() {
    'use strict';

    angular
        .module('app')
        .controller('product-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $sessionStorage, storageANBP, nabpAPI, $stateParams, $rootScope, $controller) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.list = {};
        $scope.sortValue = 1;
        $scope.configSort = {
            1: { order: 'name', sort: 'asc' },
            2: { order: 'price', sort: 'asc' },
            3: { order: 'price', sort: 'desc' }
        }

        // $scope.currentWishList = storageANBP.getWishList();
        $scope.filterParams = {};

        $scope.$watch('filterParams', function(newVal, oldVal) {
            if (newVal && !angular.equals(newVal, {}) && !angular.equals(oldVal, {})) {
                init();
            }
        })

        $scope.goToDetail = function(item) {
           if(item.item_type == 'wine') {
               item.type = 1;
           } else item.type = 2;
           
            $state.go("anbp.category.product.detail", { id: item.item_id, type: item.type, item_data: item });
        }

        $scope.getOneItemImage = function(type) {
            return storageANBP.getOneItemImage(type);
        }

        $scope.oneImages = [];
        $scope.bundleImages = [];
        
        $scope.addToCart = function(item) {
            if ($scope.enableAddCart(item)) {
                return $state.go('anbp.cart');
            }
            storageANBP.addToCart(item);
        }

        $scope.enableAddCart = function(item) {
            return storageANBP.enableAddCart(item);
        }


        $scope.addToWishList = function(item) {
            if ($scope.enableAddWishList(item)) {
                // $state.go();
                return;
            }
            storageANBP.addWishList(item);
            // $scope.currentWishList = storageANBP.getWishList();
        }

        $scope.enableAddWishList = function(item) {
            return storageANBP.enableAddWishList(item);
        }

        $scope.addToQuote = function(item) {
            if ($scope.enableAddQuote(item)) {
                return $state.go('anbp.quote');
            }
            // console.log($rootScope.cartItems);
            storageANBP.addToQuote(item);
        }

        $scope.enableAddQuote = function(item) {
            return storageANBP.enableAddQuote(item);
        }

        
        $scope.dividNumber = function(num) {
            return storageANBP.dividNumber(num);
        }

        $scope.getList = function() {
            init();
        }

        $scope.changeImage = function(item) {
            item.wine_images[0].thumb_img_temp =   '../../../assets/img/Content/cloth-2.jpg';
        }

        $scope.resetImage = function(item) {
            item.wine_images[0].thumb_img_temp = null;
        }
        
        function getWine() {
            var params = $listController.getParams();
            params = Object.assign($stateParams, params, $scope.filterParams, $scope.configSort[$scope.sortValue]);

            nabpAPI.getWine(params).success(function(res) {
                try {
                    $scope.list.item = res.results.rows;
                    $scope.list.item.forEach(function(ele) {
                        ele.resale_price = ele.sale_price_for_buyer || ele.resale_price || ele.sale_price;
                    });

                    $listController.matchPagingOption(res.results);

                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function getBundle() {
            var params = $listController.getParams();
            params = Object.assign($stateParams, params, $scope.filterParams, $scope.configSort[$scope.sortValue]);

            nabpAPI.getListBundle(params).success(function(res) {
                try {
                    $scope.list.item = res.results;
                    
                    $scope.list.item.forEach(function(ele) {
                        ele.resale_price = ele.sale_price_for_buyer || ele.resale_price || ele.sale_price;
                        ele.item_id = ele.id;
                        ele.type = 2;
                    });

                    $listController.matchPagingOption(res.results);

                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function init() {
            if ($stateParams.type == 2) {
                $scope.isBundle = true;
                getBundle();
            } else
                getWine();
        }

        $timeout(function() {
            init();
        })
    }
})();