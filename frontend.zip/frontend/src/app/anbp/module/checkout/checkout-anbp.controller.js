(function() {
    'use strict';

    angular
        .module('app')
        .controller('checkout-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, storageANBP, configurationAPI, $state, $location, $stateParams, $rootScope, $sessionStorage, $localStorage, $controller, productAPI, API, orderAPI, accountAPI) {
        if (!$sessionStorage.CL_USER_DATA) {
            $state.go("anbp.signin", { redirect: "anbp.cart.checkout" });
            return;
        }

        $scope.data = {};

        $scope.getTotal = function() {
            return storageANBP.getSubTotalPrice();
        }

        $scope.getDiscountTotal = function() {
            return storageANBP.getDiscountTotal();
        }

        $scope.checkItem = function(item) {
            $scope.currentShipping = item;
        }

        $scope.cancel = function() {
            $state.go('anbp.index');
        }

        $scope.data.shipping_cost = 0;
        $scope.data.total = 0;

        $scope.createOrder = function() {
            try {
                var products = [];
                $rootScope.cartItems.forEach(function(item) {
                    products.push({
                        item_id: item.item_id,
                        quantity: item.order_quantity,
                        price: item.resale_price,
                        resale_price: item.resale_price,
                        discount_percent: item.discount || 0,
                        shipping_address_id: $scope.buyerData.shipping[0].address_id,
                        warehouse_id: item.warehouse_id || 1,
                        item_type: item.buying_item_type || item.item_type
                    });
                });
                console.log(products);
                var selected_programs = [];
                $rootScope.cartItems.forEach(function(item) {
                    if (item.promotion_program_id && selected_programs.indexOf(item.promotion_program_id) == -1) {
                        selected_programs.push(item.promotion_program_id);
                    }
                });

                var params = {
                    "is_client": true,
                    "brand_id": 1 || $localStorage.BRAND.id,
                    "customer_po": "random",
                    "order_date": new Date(),
                    "type": 'ONL',
                    "company_id": $rootScope.currentBuyer.company_id,
                    "buyer_type": $scope.buyerData.buyer_type,
                    "vat_percent": $scope.data.vat_percent || 0,
                    "discount_percent": $scope.data.discount_percent || 0,
                    "billing_id": $scope.buyerData.billing[0].address_id,
                    "payment_method": 'CC',
                    "selected_programs": selected_programs,
                    "items": products,
                    "shipping_cost": $scope.currentShipping.fee || 0,
                };

                orderAPI
                    .createOrder(params)
                    .then(function(res) {
                        try {
                            if (res.data.results.status === true) {
                                toastr.success(res.data.results.message);
                                $rootScope.cartItems = [];
                                $state.go("anbp.account.orders");
                            } else {
                                toastr.error(res.data.results.message);
                            }
                        } catch (e) {
                            console.log(e);
                        }
                    });
            } catch (e) {
                console.log(e);
            }
        }

        function getBuyer() {
            var id = $sessionStorage.CL_USER_DATA.company_id;
            if (id) {
                API.get('buyer/detail/' + id).success(function(res) {
                    $scope.buyerData = res.results;
                    changeCountry($scope.buyerData.shipping[0].country_code);
                    console.log($scope.buyerData);
                });
            }
        }


        function getShipmentMethod() {
            var params = { length: 1000, page: 1, sort: 'desc' };
            configurationAPI.getListShipment(params)
                .then(function(res) {
                    try {
                        $scope.data.listCarrier = res.data.results.rows;
                        console.log($scope.data.listCarrier);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function changeCountry(country_code, flag) {
            var params = {};
            if (country_code) {
                params = {
                    country: country_code
                }
                accountAPI.getListState(params).then(function(res) {
                    try {
                        if (res.data.results.length > 0) {
                            $scope.states = res.data.results;
                            getState($scope.buyerData.primary[0].state_id);
                        }
                    } catch (e) {

                    }
                })
            }
        }

        function getState(id) {
            var res = $scope.states.find(function(item) {
                return item.id == id;
            });
            $scope.buyerData.primary[0].state_name = res.name;
        }

        function initData() {
            $scope.data.month = [];
            $scope.data.year = [];
            for (var i = 1; i <= 12; i++) {
                $scope.data.month.push(('0' + i).slice(-2));
            }
            for (var i = 1; i <= 99; i++) {
                $scope.data.year.push(('0' + i).slice(-2));
            }
        }

        $timeout(function() {
            try {
                getBuyer();
                getShipmentMethod();
                initData();
            } catch (e) {
                console.log(e);
            }
        })

    }
})();