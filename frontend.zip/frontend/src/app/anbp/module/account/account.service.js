
(function () {
    'use strict';

    angular.module('app').service('accountAPI', service);

    function service(API, $q, $interval, $http) {

        this.getListCountry = getListCountry;
        this.getListState   = getListState;
        this.createAccount  = createAccount;
        this.signIn         = signIn;
        this.createRMA      = createRMA;
        this.getListOrders  = getListOrders;
        this.getOrderById   = getOrderById;
        this.getRMAInfo     = getRMAInfo;
        this.cloneOrder     = cloneOrder;
        this.getListCompanyType =getListCompanyType;

        /** Internal functions */
        function cloneOrder(id) {
            var url = "order/clone-order/" + id;
            return API.post(url);
        }

        this.createUser = function(data) {
            var url = "buyer/create";
            return API.post(url, data);
        }
        //account user
        function getListCountry() {
            var url = "country/get-all";
            return API.get(url);
        }

        function getListState(params) {
            var url = "state/get-by-country";
            return API.get(url, params);
        }
        function getListCompanyType(){
            var url ="company_type/all";
            return API.get(url);
        }
        function createAccount(data) {
            var url = ['buyer', 'sign-up'].join('/');
            url = API.getHost() + url;
            var defer = $q.defer();
            var formData = new FormData();
            formData.append('data', JSON.stringify(data));


            $http
                .post(url, formData, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function (result) {
                    defer.resolve(result);

                })
                .error(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }

        function signIn(params) {
            var url = ['auth/login'].join('/');
            return API.post(url, params);
        }

        //account rma
        function createRMA(params) {
            var url = ['rma', 'create-rma'].join('/');
            return API.post(url, params);
        }
        function getListOrders(params) {
            var url = ['reference', 'order'].join('/');
            return API.get(url, params);
        }
        function getOrderById(id) {
            var url = ['reference', 'order', id, 'items'].join('/');
            return API.get(url);
        }
        function getRMAInfo() {
            var url = ['rma', 'generate'].join('/');
            return API.get(url);
        }



    }
})();
