(function() {
    'use strict';

    angular.module('app').controller('abstract.dashboard.controller', controller);


    /** @ngInject **/
    function controller($scope, $anchorScroll, nabpAPI, $timeout) {
        $scope.data = {};

        function getReportOrderHistory() {
            nabpAPI.getReportOrderHistory().then(function(res) {
                $scope.data['order-history'] = res.data.results;
            })
        }

        function getReportSOStatus() {
            nabpAPI.getReportSOStatus().then(function(res) {
                $scope.data['sale-order-status'] = {};
                $scope.data['sale-order-status']['label'] = [];
                $scope.data['sale-order-status']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['sale-order-status']['label'].push(element.status_name);
                    $scope.data['sale-order-status']['data'].push(element.order_cnt);
                });

            })
        }

        function getReportTopPromtional() {
            nabpAPI.getReportTopPromtional().then(function(res) {
                $scope.data['top-promotional'] = {};
                $scope.data['top-promotional']['label'] = [];
                $scope.data['top-promotional']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['top-promotional']['label'].push(element.program_name);
                    $scope.data['top-promotional']['data'].push(element.total_discount_qty);
                });

            })
        }

        function getReportTopMoneyPromtional() {
            nabpAPI.getReportTopMoneyPromtional().then(function(res) {
                $scope.data['top-money-promotional'] = {};
                $scope.data['top-money-promotional']['label'] = [];
                $scope.data['top-money-promotional']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['top-money-promotional']['label'].push(element.program_name);
                    $scope.data['top-money-promotional']['data'].push(element.total_spend_money);
                });

            })
        }

        function getReportTotalBought() {
            nabpAPI.getReportTotalBought().then(function(res) {
                $scope.data['total_bought'] = {};
                $scope.data['total_bought']['label'] = [];
                $scope.data['total_bought']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['total_bought']['label'].push(element.product_name);
                    $scope.data['total_bought']['data'].push(Number(element.total_quantity));
                });

            })
        }

        function getReportMostBuying() {
            nabpAPI.getReportMostBuying().then(function(res) {
                $scope.data['most-buying'] = {};
                $scope.data['most-buying']['label'] = [];
                $scope.data['most-buying']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['most-buying']['label'].push(element.category_name);
                    $scope.data['most-buying']['data'].push(element.total_quantity);
                });

            })
        }

        function getReportTopProductCategory() {
            nabpAPI.getReportTopProductCategory().then(function(res) {
                $scope.data['top-product-category'] = {};
                $scope.data['top-product-category']['label'] = [];
                $scope.data['top-product-category']['data'] = [];

                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.data['top-product-category']['label'].push(element.category_name);
                    $scope.data['top-product-category']['data'].push(element.qty_used);
                });

            })
        }

        $timeout(function() {
            getReportOrderHistory();
            getReportSOStatus();
            
            getReportMostBuying();
            getReportTopMoneyPromtional();
            getReportTotalBought();

            getReportTopPromtional();
            // getReportTopProductCategory();
        })

        //Chart 1
        $scope.backgroundColor = ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1"];
        $scope.labels1 = ["New", "In-Process", "Partial Delivery", "Completed"];
        $scope.data1 = [300, 500, 100, 200];
        $scope.options1 = {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                xAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }],
                yAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }]
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                        var tooltipLabel = data.labels[tooltipItem.index];
                        var tooltipData = allData[tooltipItem.index];
                        var total = 0;
                        for (var i in allData) {
                            total += allData[i];
                        }
                        var tooltipPercentage = Math.round((tooltipData / total) * 100);
                        return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                    }
                }
            }
        };

        $scope.changeCategory = function() {
            $scope.data1 = [500, 100, 100, 300];
        }

        //Chart 2
        $scope.labels2 = ['Promotional A', 'Promotional B', 'Promotional C', 'Promotional D', 'Promotional E'];
        $scope.data2 = [65, 59, 80, 81, 56];
        $scope.options2 = {
            events: false,
            showTooltips: false,
            legend: {
                display: false
            },
            scales: {
                yAxes: [{
                    display: true
                }]
            }
        };
        //
        // Chart 3
        $scope.labels3 = ['Promotional A', 'Promotional B', 'Promotional C', 'Promotional D', 'Promotional E'];
        $scope.data3 = [1000, 59, 80, 81, 56];
        $scope.options3 = {
            events: false,
            showTooltips: false,
            legend: {
                display: false
            },
            scales: {
                xAxes: [{
                    display: true,
                    ticks: {
                        callback: function(value, index, values) {
                            return "$" + value;
                        }
                    },
                }]
            },
        };

        // Chart 4
        $scope.labels4 = ["Download", "In-Store", "Mail-Order", "Tuu", "Add"];
        $scope.data4 = [165, 59, 10, 61, 256];
        $scope.changeCategory = function() {
            $scope.data4 = [900, 100, 100, 100, 100];
        }

        //Chart 5
        $scope.backgroundColor5 = ["#46BFBD", "#DCDCDC"]
        $scope.labels5 = ['2006', '2007'];
        $scope.data5 = [70, 30];
        $scope.options5 = {
                cutoutPercentage: 60,
                animation: false,
                legend: {
                    display: false
                },
                responsive: false,
                maintainAspectRatio: false,
                scales: {
                    xAxes: [{
                        display: this.scalesdisplay,
                        ticks: {
                            beginAtZero: this.beginzero,
                        }
                    }],
                    yAxes: [{
                        display: this.scalesdisplay,
                        ticks: {
                            beginAtZero: this.beginzero,
                        }
                    }]
                },
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            console.log(tooltipItem);
                            console.log(data);
                            var allData = data.datasets[tooltipItem.datasetIndex].data;
                            var tooltipLabel = data.labels[tooltipItem.index];
                            var tooltipData = allData[tooltipItem.index];
                            var total = 0;
                            for (var i in allData) {
                                total += allData[i];
                            }
                            var tooltipPercentage = Math.round((tooltipData / total) * 100);
                            return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                        }
                    }
                },
                elements: {
                    center: {
                        text: $scope.data5[0] + '%',
                        color: '#4D5360', // Default is #000000
                        fontStyle: 'Arial', // Default is Arial
                        sidePadding: 15 // Defualt is 20 (as a percentage)
                    }
                }
            }
            //Chart 6
        $scope.labels6 = ['2006', '2007', '2008', '2009', '2010'];
        $scope.data6 = [165, 59, 10, 61, 256];



        //Chart TEST 
        $scope.series10 = ['Total Sold QTY', 'Total Revenues $'];
        $scope.datasetOverride10 = [{
            yAxisID: 'y-axis-1'
        }, {
            yAxisID: 'y-axis-2'
        }];
        $scope.options10 = {
            legend: {
                display: true
            },
            title: {
                display: true,
                text: 'Total Sales Orders & Total Spending Money'
            },
            scales: {
                yAxes: [{
                        id: 'y-axis-1',
                        type: 'linear',
                        display: true,
                        position: 'left',
                        ticks: {
                            // stepSize: 1,
                            beginAtZero: true
                        }
                    },
                    {
                        id: 'y-axis-2',
                        type: 'linear',
                        display: true,
                        position: 'right',
                        ticks: {
                            //   stepSize: 1,
                            callback: function(value, index, values) {
                                return '$' + value;
                            },
                            beginAtZero: true,
                            min: 0
                        },
                        scaleLabel: {
                            display: true,
                            //   labelString: 'sdgsdfg'
                        }
                    }
                ],
                xAxes: [{
                    display: true,
                    ticks: {
                        // stepSize: 2
                    }
                }]
            }
        };
        $scope.colors10 = [{ // green
                backgroundColor: 'rgb(0%, 46%, 0%)',
                pointBackgroundColor: 'rgb(0%, 46%, 0%)',
                pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
                borderColor: 'rgb(0%, 46%, 0%)',
                pointBorderColor: '#fff',
                pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
            },
            { // blue
                backgroundColor: 'rgb(2%, 85%, 92%)',
                pointBackgroundColor: 'rgb(2%, 85%, 92%)',
                pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
                borderColor: 'rgb(2%, 85%, 92%)',
                pointBorderColor: '#fff',
                pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
            }
        ];
        $scope.data10 = [$scope.data3, $scope.data3]

    }
})();