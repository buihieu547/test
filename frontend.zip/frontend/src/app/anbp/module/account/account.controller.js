(function() {
    'use strict';

    angular.module('app').controller('anbp.account.controller', controller);
    angular.module('app').controller('anbp.signin.controller', signinController);
    angular.module('app').controller('anbp.signup.controller', signupController);

    /** @ngInject */
    function controller($scope, $timeout, $state, $stateParams, accountAPI, storageANBP, $location, $rootScope, $sessionStorage) {

        $scope.changeForm = changeForm;
        $scope.data = {};
        $rootScope.cartItems = $sessionStorage.cartItems || [];
        $scope.getTotal = function() {
            var result = 0;
            for (var i in $rootScope.cartItems) {
                result += $rootScope.cartItems[i].sell_price * $rootScope.cartItems[i].order_quantity;
            }
            result += $scope.data.shipping_cost;
            return result;
        }

        $scope.$watch(function() {
            return $rootScope.cartItems;
        }, function(oldValue, newValue) {
            $scope.total = $scope.getTotal();
        }, true)

        $scope.total = 0;

        (function onInit() {
            if ($state.current.name == 'anbp.signin') {
                $scope.data.acc_info = false;
            }
            if ($state.current.name == 'anbp.signup') {
                $scope.data.acc_info = true;
            }
        })();

        function changeForm(id) {
            if (id) {

            } else {

            }
        }
    };

    function signupController($scope, $timeout, $state, buyerAPI, $stateParams, accountAPI, $location, $rootScope) {
        $scope.createUser = createUser;
        $scope.createCustomer = createCustomer;
        $scope.copyShiptoBill = copyShiptoBill;
        $scope.changeCountry = changeCountry;
        $scope.listCountry = listCountry;

        $scope.formData = {};
        $scope.formData.shipping = {};
        $scope.formData.billing = {};
        $scope.formData.billing.info = true;

        $scope.country = {
            billing: [],
            shipping: []
        };
        $scope.state = {
            billing: [],
            shipping: []
        };

        (function onInit() {
            $scope.listCountry();
            getListType();
        })();

        function getListType() {
            accountAPI.getListCompanyType().then(function(res){
                $scope.buyerTypeList =res.data.results;
            })
            //  $scope.buyerTypeList = [{ "id": 4, "name": "Mart" }, { "id": 3, "name": "Shop" }, { "id": 2, "name": "Clinic" }, { "id": 1, "name": "Hospital" }]
        }

        function createUser() {
            var params = angular.copy($scope.formData);
            var addr = {
                "address_line": params.com_addr,
                "country_code": params.country,
                "city_name": params.city,
                "zip_code": params.zip_code,
                'state_id': params.state
            }

            params = {
                "primary": [addr],
                "shipping": [addr],
                "billing": [addr],
                "user": [{
                    "email": params.email,
                    "username": params.email,
                    "password": params.password,
                    "password_confirm": params.password_confirm,
                    "first_name": params.first_name,
                    "last_name": params.last_name,
                    "full_name": params.first_name + ' ' + params.last_name,
                    "phone": params.phone,
                }],
                "credit_sts": 2,
                "phone": params.phone,
                "line_of_credit": 0,
                "buyer_type": params.role_id,
                "full_name": params.com_name,
                "email": params.email
            }

            accountAPI.createUser({ data: JSON.stringify(params) }).then(function(res) {
                try {
                    if (res.data._type == 'success') {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go('anbp.signin', {}, { reload: true });

                        }, 2000)

                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }

        function listCountry() {

            accountAPI.getListCountry().then(function(res) {
                try {
                    if (res.data.results.length > 0) {
                        $scope.countries = res.data.results;
                    }
                } catch (e) {

                }
            })

        }

        function changeCountry(country_code, flag) {

            var params = {};
            if (country_code) {
                params = {
                    country: country_code
                }
                accountAPI.getListState(params).then(function(res) {
                    try {
                        if (res.data.results.length > 0) {
                            $scope.states = res.data.results;
                            $scope.formData.state = '';
                        }
                    } catch (e) {

                    }
                })
            } else {
                $scope.state[flag] = [];
            }

        }


        function copyShiptoBill() {
            $scope.formData.billing = angular.copy($scope.formData.shipping)
            $scope.formData.billing.info = false;
        }


        function createCustomer() {
            if ($scope.formData.billing.info) {
                $scope.formData.billing = angular.copy($scope.formData.shipping)
                $scope.formData.billing.info = true;
            }
            var params = angular.copy($scope.formData);
            params['shipping'] = [params.shipping];
            params['billing'] = [params.billing];
            params['primary'] = params['shipping'];

            accountAPI.createAccount(params).then(function(res) {
                console.log(res);
                try {
                    if (res._type == 'success') {
                        window.toastr.success(res.message);
                        $state.go('anbp.signin');
                    }
                } catch (e) {
                    console.log(e);
                }


            })
        }
    };

    function signinController($scope, $localStorage, $sessionStorage, $state, $timeout, API, accountAPI, storageANBP, $rootScope, $stateParams) {

        $scope.signIn = signIn;
        $scope.data = {};

        function getBuyer() {
            var id = $sessionStorage.CL_USER_DATA.company_id;
            if (id) {
                API.get('buyer/detail/' + id).success(function(res) {
                    $rootScope.buyerData = res.results;
                });
            }
        }

        function signIn(data) {

            var params = {
                login: $scope.data.email,
                password: $scope.data.password
            };

            accountAPI.signIn(params).then(function(res) {
                try {

                    var _data = res.data.results;
                    if (_data.info.user_type == 2) {
                        _data.info.user_id = _data.info.id;
                        $sessionStorage.CL_AUTHENTICATE_TOKEN = _data.token;
                        $sessionStorage.CL_USER_DATA = _data.info;
                        $rootScope.currentBuyer = angular.copy($sessionStorage.CL_USER_DATA);

                        $timeout(function() {
                            console.log($stateParams)
                            storageANBP.getWishList();
                            $state.go($stateParams.redirect || 'anbp.index', { id: $stateParams.id });
                            //Get detail Buyer Info
                            getBuyer();
                        }, 300)
                    } else {
                        toastr.error('Username or password is incorrect');
                    }


                } catch (error) {
                    console.log(error)
                }

            });
        }

    };

})();