(function() {
    'use strict';

    angular.module('app').controller('account-orders-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $sessionStorage, nabpAPI, $stateParams, $location, $rootScope, $controller, storageANBP, API, $localStorage, accountAPI) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });
        var $chartController = $controller('abstract.dashboard.controller', { $scope: $scope });

        /**
         * CHART CONFIG
         */
        //New
        // $scope.currentWishList = storageANBP.getWishList();

        $scope.cloneOrder = function(id) {
            if (!id) return;
            accountAPI.cloneOrder(id).then(function(res) {
                try {
                    if (res.data._type) {
                        toastr.success(res.data.message);
                        getListOrder();
                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }

        $scope.getDetailOrder = function(item) {
            if (!item.showChild) return;
            getDetail(item.order_id, item);
        }

        $scope.getDetailQO = function(item) {
            if(!item.showChild) return;
            getDetail(item.id, item);
        }

        $scope.dividNumber = function(num) {
            return storageANBP.dividNumber(num);
        }

        $scope.removeWishList = function(index) {
            storageANBP.removeWishList(index);
            // $scope.currentWishList = storageANBP.getWishList();
        }

        $scope.addToCart = function(item) {
            if ($scope.enableAddCart(item)) {
                return $state.go('anbp.cart');
            }
            storageANBP.addToCart(item);
        }

        $scope.enableAddCart = function(item) {
            return storageANBP.enableAddCart(item);
        }

        $scope.goToItem = function(item) {

            if (item.wine_id) {
                item.type = 1;
            }

            if (item.bundle_id) item.type = 2;

            if (item.wine_id || item.bundle_id) {
                item.item_id = item.wine_id || item.bundle_id;
            }
            $state.go("anbp.category.product.detail", { id: item.item_id, type: item.type, item_data: item });

        }

        $scope.goToPromotion = function(params) {
            if (!params.id) return;
            params = { id: params.id };
            var promotion_id = 1;
            if ($localStorage.promotion_ids) {
                var lstPromotionId = $localStorage.promotion_ids;
                lstPromotionId.push(promotion_id);
                $localStorage.promotion_ids = lstPromotionId;
            } else {
                var lstPromotionId = [];
                lstPromotionId.push(promotion_id);
                $localStorage.promotion_ids = lstPromotionId;
            }

            $state.go("anbp.promotion", Object.assign({}, params), { inherit: false })
        }

        $scope.programImages = ['http://businesscatalogues.com.au/wp-content/uploads/2014/10/ACC_SA-787x1030.jpg',
            'https://www.mdgsb.com.my/wp-content/uploads/2017/01/promotion-12.jpg',
            'http://www.linde.co.th/internet.global.corp.tha/en/images/Promotion_PPE_all_end2013-1368_111447.png?v=1.0'
        ]

        function getLisProgramBuyer() {
            var id = $sessionStorage.CL_USER_DATA.company_id;
            nabpAPI.getLisProgramBuyer(id).then(function(result) {
                var data = result.data.results;
                $scope.currentProgramList = data;
            })
        }


        function getBuyerDetail() {
            var id = $sessionStorage.CL_USER_DATA.company_id;
            if (id) {
                API.get('buyer/detail/' + id).success(function(res) {
                    $scope.buyerData = res.results;
                    changeCountry($scope.buyerData.primary[0].country_code);
                });
            }
        }

        function getListType() {
            accountAPI.getListCompanyType().then(function(res){
                $scope.buyerTypeList =res.data.results;
            })
            // $scope.buyerTypeList = [{ "id": 4, "name": "Normal Buyers" }, { "id": 3, "name": "Pubs" }, { "id": 2, "name": "Bars" }, { "id": 1, "name": "Restaurants" }]
        }

        function listCountry() {

            accountAPI.getListCountry().then(function(res) {
                try {
                    if (res.data.results.length > 0) {
                        $scope.countries = res.data.results;
                    }
                } catch (e) {

                }
            })

        }

        function changeCountry(country_code, flag) {
            var params = {};
            if (country_code) {
                params = {
                    country: country_code
                }
                accountAPI.getListState(params).then(function(res) {
                    try {
                        if (res.data.results.length > 0) {
                            $scope.states = res.data.results;
                            $scope.formData.state = '';
                        }
                    } catch (e) {

                    }
                })
            } else {
                $scope.state[flag] = [];
            }

        }

        /********************** */
        $scope.list = {};
        $scope.currentTab = 0;
        $scope.getList = getList;
        $scope.printOrder = printOrder;

        function getDetail(id, item) {
            if (id) {
                var url = ['order', 'order-detail', id].join('/');
                API.get(url).success(function(res) {
                    item.prom_acc_bal = res.results.prom_acc_bal;
                    item.details = res.results.subs;
                    item.details.limit = 3;
                    // console.log($scope.list.items);
                });
            }
        };

        function getRMAType(id) {
            return $scope.list["RMAType"].find(function(item) {
                return item.id == id;
            }) || {};
        }

        function getRMADetail(id, item) {
            if (id) {
                API.get('rma/rma-detail/' + id).success(function(res) {
                    if (res) {
                        item.details = res.results;
                        item.details.rma_type_name = getRMAType(item.details.rma_type).name;
                        item.details.limit = 3;

                    }

                });
            }
        }

        function getDetailAll(flag) {
            if (flag < 2) {
                ($scope.list.orders || []).forEach(function(item) {
                    getDetail(item.order_id, item);
                })
            } else {
                ($scope.list.quotes || []).forEach(function(item) {
                    getDetail(item.id, item);
                })
            }
        }

        function getList(type) {
            // if (type) getListRMA();
            // else getListOrder();
        }

        function getListOrder() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            API
                .get('order/get-purchase-history/' + $rootScope.currentBuyer.company_id, params)
                .then(function(res) {

                    try {
                        $scope.list.orders = res.data.results;
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function getListQuote() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            API
                .get('order/list-sale-quote', params)
                .then(function(res) {

                    try {
                        $scope.list.quotes = res.data.results.rows;
                        // getDetailAll(3);
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        $scope.changeTab = function(index) {
            $scope.activeTab = index;
        }

        $scope.getTotalOrders = function() {
            var result = 0;
            ($scope.list.orders || []).forEach(function(item) {
                result += item.total_price;
            })
            return result;
        }

        function getListRMA() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            API.get('rma/index', params).then(function(res) {

                try {
                    $scope.list.items = res.data.results.rows;
                    $listController.matchPagingOption(res.data.results);
                    getDetailAll(1);
                } catch (e) {
                    console.log(e);
                }
            });
        }

        function getBuyer() {
            var id = $rootScope.currentBuyer.company_id;
            if (id) {
                API
                    .get(['company/information-of-company', id].join('/'))
                    .then(function(res) {
                        try {
                            $scope.list.shipping = res.data.results.address.shipping[0].label;
                            console.log($scope.list.info);
                        } catch (e) {
                            console.log(e);
                        }
                    })
            }
        }
        $scope.detail_order = {};

        function printOrder(index) {
            $scope.detail_order = $scope.list.items[index];
            console.log($scope.detail_order);
            $timeout(function() {
                var innerContents = document.getElementById('printOrder').innerHTML;
                var popupWinindow = window.open('', '_blank', 'width=860,height=600,fullscreen=yes,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
                popupWinindow.document.open();
                popupWinindow.document.write('' +
                    '<html>' +
                    '<head>' +
                    '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700"/>' +
                    '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">' +
                    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>' +
                    '<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>' +
                    '<style type="text/css">' +
                    'body{-webkit-print-color-adjust: exact; overflow: scroll; font-size: 9px;}' +
                    '@media print{body{font-size: 9px;} thead {display: table-header-group;}}' +
                    '@media print {table >tr.vendorListHeading {background-color:#cccccc !important; -webkit-print-color-adjust: exact; font-weight:normal; border-top:1px solid grey}}' +
                    '@media print { th{background-color:#cccccc !important; height: 30px; padding: 5px; font-size: 9px;}}' +
                    '@media print {' +
                    'table {tbody>tr>td {padding: 5px;}} ' +
                    '.pagebreak { page-break-before: always; }' +
                    '}' +
                    '.row {margin: 0;} .txt-title {color: #646464; font-weight: bold;}' +
                    'table{margin-bottom:15px; }' +
                    'table>tr.vendorListHeading>td { font-weight: normal; padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +
                    'table>tr>td {padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +
                    '.mrg-top {margin-top: 20px;} .mrg-none {margin: 0;}' +
                    '.float-l {float: left; width: 50%;} ' +
                    '.float-r {float: right; width: 50%;} ' +
                    '.float-l3 {float: left; width: 33%;} .float-r3 {float: right; width: 33%;} ' +
                    '.float-lcol-2 {float: left; min-width: 100px;} .float-rcol-2 {float: right; min-width: 100px;} ' +
                    '.float-l100 {float: left; width: 100%;} .float-r100 {float: right; width: 100%}' +
                    '.padding-none {padding: 0;} ' +
                    '.padding-t {padding-top: 3%}' +
                    'thead {background-color: #dddddd; } .bg-gray {background-color: #dddddd;}' +
                    'thead >tr{border-bottom:grey} ' +
                    'table>tbody>tr>td {padding: 5px; font-size: 9px;}' +
                    '#table-total>tr>td{ padding:10px;}' +
                    '#table-total>tr>td>span{font-weight:600 }' +
                    '#table-total>tr.remove-boder>td{border-left:none;border-right:none}' +
                    'table.table-footer>thead>tr>th{padding:5px;border:none}' +
                    'table.table-footer>tbody>tr>td{padding:5px;border:none}' +
                    '#footer p{margin-bottom:5px;}' +
                    '</style>' +
                    '<title>' + $scope.detail_order.code + '</title>' +
                    '</head>' +
                    '<body onload="window.print()">' + innerContents + '</html>');
                popupWinindow.document.close();

            }, 1000);


        };


        $timeout(function() {
            getLisProgramBuyer();
            getListType();
            getBuyerDetail();
            listCountry();
            getListQuote();
            getListOrder();
            // getList();
            // getBuyer();
        })
    }

})();
