(function () {
    'use strict';

    angular.module('app').controller('anbp.account.rma.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, accountAPI, $state, hotkeys, $sessionStorage) {
        //Define variable
        $rootScope.currentBuyer = angular.copy($sessionStorage.CL_USER_DATA);
        $scope.buyer_id = $rootScope.currentBuyer.id;
        $scope.full_name = $rootScope.currentBuyer.full_name;

        $scope.mainData = {
            selectedOrder: {},
            generalInfo: {},
            listOrderItem:[]
        };
        $scope.selectionData = {};
        $scope.KeyShorcut =KeyShorcut;
        $scope.changeRMA =changeRMA;

        $scope.removeItem = function(src, item) {
            var index = src.indexOf(item);
            src.splice(index, 1);
        }

        $scope.changeOrder = function(id) {
            getOrderDetail(id);
        }

        $scope.cancelRMA = function() {
            $state.go('anbp.account.orders');
        }
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
         }

       hotkeys.bindTo($scope)
         .add({
           combo: 'alt+s',
           description: 'Create RMA',
           callback: function() {
            $scope.createRMA()
           }
         })
         .add({
           combo: 'alt+c',
           description: 'Back to Return Order List',
           callback: function() {
            $scope.cancelRMA();
           }
         })

        $scope.createRMA = function() {
            var params = {
                'order_id': $scope.mainData.selectedOrder.id,
                'crtn_on': $scope.mainData.generalInfo.crt_date,
                'rqst_user_id': 1 || $scope.mainData.generalInfo.requester,
                'spcl_instrc': $scope.mainData.generalInfo.spcl_instrc,
                'rma_items': toRMAItem($scope.mainData['listOrderItem']),
                'balance_of_credit':$scope.mainData.generalInfo.balance_of_credit,
                'return_loc':$scope.mainData.generalInfo.return_loc,
                'rma_type':$scope.mainData.generalInfo.rma_type,
            };
            if($scope.mainData.generalInfo.return_loc==2){
                params['pickup_location_id']= $scope.mainData.shippingData.shipping_address_id;
            }
            console.log(params);
            accountAPI.createRMA(params).then(function(res) {
                try {
                    if (res.data._type === "success") {
                        toastr.success(res.data.message);
                        $timeout(function() {
                        $state.go('anbp.account.orders');
                        }, 1000)

                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            }, function(err) {
                console.log(err)
            });
        }

        $scope.checkValid = function() {
                return $scope.rmaForm.$valid && checkValidItem();
            }
            /**
             * INIT
             */
        function initVar() {
            $scope.selectionData["RMAType"] = [{ id: 0, name: 'Exchange' }, { id: 1, name: 'Credit' }, { id: 2, name: 'Refund' }, { id: 3, name: 'Re-certification' }];
            $scope.selectionData["ReturnLoc"]= [{id:1,name:'NAB Location'},{id:2,name:'Customer Location'}];
        }

        function initData() {
            getListOrders();
            getRMAInfo();
        }

        function toRMAItem(item) {
            var res = angular.copy(item);
            res.forEach(function(item) {
                delete item['$$hashKey']
                item.is_possible = item.is_possible == 1;
            });
            return res;
        }

        function checkValidItem() {
            for (var i in $scope.mainData['listOrderItem']) {
                if (!$scope.mainData['listOrderItem'][i].is_possible || !$scope.mainData['listOrderItem'][i].serial_num || !$scope.mainData['listOrderItem'][i].prob_des) {
                    return false;
                }
            }
            return true;
        }
        function changeRMA(id){
           if($scope.mainData['listOrderItem'].length>0){
               angular.forEach($scope.mainData['listOrderItem'],function(item){
                   item.type= id;
               })
           }
        }
        $scope.$watch('mainData.listOrderItem',function(){
           $timeout(function(){
            $scope.changeRMA($scope.mainData.generalInfo.rma_type)
           })
        })

        function getListOrders() {
            var params = {};
                params = {
                    buyer_id: $scope.buyer_id
                }
            accountAPI.getListOrders(params).then(function(result) {
                if (result) {
                    $scope.mainData['listOrders'] = result.data.results;
                }
            })
        }

        function getOrderDetail(id) {
            accountAPI.getOrderById(id).then(function(result) {
                if (result) {
                    $scope.mainData['listOrderItem'] = result.data.results;
                    $scope.mainData['listOrderItem'].forEach(function(item) {
                        item['order_detail_id'] = item['id'];
                    });

                }
            })
        }

        function getRMAInfo() {
            accountAPI.getRMAInfo().then(function(result) {
                if (result.data.results) {
                    $scope.mainData.generalInfo.rma_no = angular.copy(result.data.results).code;
                    console.log(result);
                }
            })
        }
        function printInvoice() {		   
		    var innerContents = document.getElementById('printInvoice').innerHTML;
		    var popupWinindow = window.open('', '_blank', 'width=860,height=600,fullscreen=yes,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
		    popupWinindow.document.open();
		    popupWinindow.document.write('' +
			    '<html>' +
			    '<head>' +
			    '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700"/>' +
			    '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">' +
			    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>' +
			    '<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>' +
                '<style type="text/css">' +
                    'body{-webkit-print-color-adjust: exact; overflow: scroll; font-size: 9px;}' +
                    '@media print{body{font-size: 9px;} thead {display: table-header-group;}}' +
                    '@media print {table >tr.vendorListHeading {background-color:#cccccc !important; -webkit-print-color-adjust: exact; font-weight:normal; border-top:1px solid grey}}'+
                    '@media print { th{background-color:#cccccc !important; height: 30px; padding: 5px; font-size: 9px;}}' +
				    '@media print {' +
			            'table {tbody>tr>td {padding: 5px;}} ' +
			            '.pagebreak { page-break-before: always; }' +
			        '}' +
				    '.row {margin: 0;} .txt-title {color: #646464; font-weight: bold;}' +
                    'table{margin-bottom:15px; }'+
			        'table>tr.vendorListHeading>td { font-weight: normal; padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +
			        'table>tr>td {padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +                    
                    '.mrg-top {margin-top: 20px;} .mrg-none {margin: 0;}' +
			        '.float-l {float: left; width: 50%;} ' +
			        '.float-r {float: right; width: 50%;} ' +
			        '.float-l3 {float: left; width: 33%;} .float-r3 {float: right; width: 33%;} ' +
			        '.float-lcol-2 {float: left; min-width: 100px;} .float-rcol-2 {float: right; min-width: 100px;} ' +
			        '.float-l100 {float: left; width: 100%;} .float-r100 {float: right; width: 100%}' +
			        '.padding-none {padding: 0;} ' +
			        '.padding-t {padding-top: 3%}' +
                    'thead {background-color: #dddddd; } .bg-gray {background-color: #dddddd;}' +
                    'thead >tr{border-bottom:grey} ' +
			        'table>tbody>tr>td {padding: 5px; font-size: 9px;}'+
                    '#table-total>tr>td{ padding:10px;}'+
                    '#table-total>tr>td>span{font-weight:600 }'+
                    '#table-total>tr.remove-boder>td{border-left:none;border-right:none}'+
                     'table.table-footer>thead>tr>th{padding:5px;border:none}'+
                    'table.table-footer>tbody>tr>td{padding:5px;border:none}'+
                    '#footer p{margin-bottom:5px;}'+
                '</style>' +
                    '<title>'+ $scope.detail.general.invoice_num+'</title>'+
			    '</head>' +
			    '<body onload="window.print()">' + innerContents + '</html>');
		    popupWinindow.document.close();
        };

        (function init() {
            initVar();
            initData();
        })()

    };

    })();
