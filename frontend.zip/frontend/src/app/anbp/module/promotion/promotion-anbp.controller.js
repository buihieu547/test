(function() {
    'use strict';

    angular
        .module('app')
        .controller('promotion-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $sessionStorage, nabpAPI, $stateParams, $rootScope, storageANBP, $controller, productAPI) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });
        $scope.listMaster = {};
        $scope.list = { items: [] };
        $scope.currentCategory = {};
        // $scope.currentWishList = storageANBP.getWishList();
        $scope.filterParams = {};

        $scope.$watch('filterParams', function(newVal, oldVal) {
            if (newVal && !angular.equals(newVal, {}) && !angular.equals(oldVal, {})) {
                init();
            }
        })

        $scope.goToDetail = function(item) {
            var type = (item.buying_item_type == "bundle")? 2: 1; 
            $state.go("anbp.category.product.detail", { id: item.item_id, type: type  });
        }
        
        $scope.addToQuote = function(item) {
            if ($scope.enableAddQuote(item)) {
                return $state.go('anbp.quote');
            }
            // console.log($rootScope.cartItems);
            storageANBP.addToQuote(item);
        }

        $scope.enableAddQuote = function(item) {
            return storageANBP.enableAddQuote(item);
        }

        
        $scope.addToCart = function(item) {
            if ($scope.enableAddCart(item)) {
                return $state.go('anbp.cart');
            }
            storageANBP.addToCart(item);
        }

                
        $scope.getOneItemImage = function(type) {
            return storageANBP.getOneItemImage(type);
        }

        $scope.oneImages = [];
        $scope.bundleImages = [];
        
        $scope.enableAddCart = function(item) {
            return storageANBP.enableAddCart(item);
        }


        $scope.addToWishList = function(item) {
            if ($scope.enableAddWishList(item)) {
                // $state.go();
                return;
            }
            storageANBP.addWishList(item);
            // $scope.currentWishList = storageANBP.getWishList();
        }

        $scope.enableAddWishList = function(item) {
            return storageANBP.enableAddWishList(item);
        }

        $scope.dividNumber = function(num) {
            return storageANBP.dividNumber(num);
        }

        function getList() {
            var params = $listController.getParams();
            params = Object.assign($stateParams, params, $scope.filterParams, { order: 'price', sort: 'desc' });

            nabpAPI.getListWinePromotion($stateParams.id, params).success(function(res) {
                try {
                    $scope.list.item = res.results.program_lines;
                    $scope.list['name'] = res.results.promotion_program_name;
        
                    $scope.list.item.forEach(function(ele) {
                        ele.promotion_program_id =  res.results.promotion_program_id;
                        ele.item_id = ele.buying_item_id;
                        ele.name = ele.buying_item_name;
                        ele.resale_price =  ele.sale_price_for_buyer || ele.item_resale_price;
                        ele.order_quantity = ele.buying_item_quantity
                    });

                    $listController.matchPagingOption(res.results);

                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function init() {
            getList();
        }

        $timeout(function() {
            init();
        })
    }
})();