(function() {
    'use strict';

    angular
        .module('app')
        .controller('cart-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $stateParams, $location, $rootScope,
        $sessionStorage, $localStorage, $controller,
        productAPI, API, orderAPI, storageANBP, cartAPI) {

        if (!$sessionStorage.CL_USER_DATA) {
            $state.go("anbp.signin", { redirect: "anbp.cart" });
            return;
        }
        $scope.lstProduct = [];
        $scope.notPromoList = [];

        function viewCart() {
            var selected_programs = [];

            var items = $rootScope.cartItems.filter(function(item) {
                if (item.promotion_program_id && selected_programs.indexOf(item.promotion_program_id) == -1) {
                    selected_programs.push(item.promotion_program_id);
                }
                return item.promotion_program_id;
            });

            $scope.notPromoList = $rootScope.cartItems.filter(function(item) {
                return !item.promotion_program_id;
            })
     
            if (items.length == 0) {
                $scope.lstProduct.items = [];
                return;
            }

            var params = {
                company_id: $sessionStorage.CL_USER_DATA.company_id,
                selected_programs: selected_programs,
                items: items
            }

            // change key follow Quyen Nguyen (09/02/2018)
            angular.forEach(params.items, function(item, key) {
                item.item_id = item.item_id || item.id;
                item.price = item.resale_price;
                item.quantity = item.order_quantity;
                item.item_type = item.buying_item_type;
                item.discount_percent = item.prom_discount_percent || 0
            });



            cartAPI.viewCart(params).then(function(res) {
                try {
                    if (res.data._type == 'success') {
                        $scope.lstProduct = res.data.results.promotion;

                        //New Promotion
                        $scope.specialList = angular.copy( $scope.lstProduct);
                        $rootScope.cartItems = $scope.notPromoList.concat(res.data.results.items);
                        $sessionStorage.cartItems = angular.copy($rootScope.cartItems);
                    }
                } catch (e) {
                    console.log(e);
                }
            }, function(error) {

            });
        }

        $scope.removeItem = function(index, list) {
            if(list) {
                list.splice(index, 1);
                return;
            }

            $rootScope.cartItems.splice(index, 1);
            $sessionStorage.cartItems = angular.copy($rootScope.cartItems);
            $scope.updateCart();
        }

        $scope.getTotal = function() {
            return storageANBP.getSubTotalPrice();
        }

        $scope.getDiscountTotal = function() {
            return storageANBP.getDiscountTotal();
        }

        $scope.dividNumber = function(num, discount) {
            return storageANBP.dividNumber(num, discount);
        }

        $scope.goToDetail = function(item) {
            if (item.item_type == 'bundle') {
                item.type = 2;
            } else {
                item.type = item.type || 1;
            }

            $state.go("anbp.category.product.detail", { id: item.item_id || item.id, type: item.type, item_data: item });
        }

        $scope.cancel = function() {
            $state.go('anbp.index');
        }

        $scope.checkout = function() {
            $state.go('anbp.cart.checkout', { data: $scope.data });
        }

        $scope.updateCart = function() {
            viewCart();
        }

        $timeout(function() {
            viewCart();
        })

    }
})();