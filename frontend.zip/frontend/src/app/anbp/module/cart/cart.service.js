(function () {
	'use strict';

	angular.module('app').service('cartAPI', service);

	function service(API, $q, $interval, $http) {
		this.viewCart = viewCart;

		function viewCart(params) {
			var url = ['order', 'preview-order' ].join( '/' );
			return API.post(url, params);
		}
	}
})();
