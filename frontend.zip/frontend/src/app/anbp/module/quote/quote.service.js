(function() {
    'use strict';

    angular.module('app').service('quoteAPI', service);

    function service(API, $q, $interval, $http) {
        this.createRFQ = function(params) {
            var url = ['rfq'].join('/');
            return API.post(url, params);
        }


    }
})();