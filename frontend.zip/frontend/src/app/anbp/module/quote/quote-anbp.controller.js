(function() {
    'use strict';

    angular
        .module('app')
        .controller('quote-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $stateParams, $location, $rootScope,
        $sessionStorage, $localStorage, $controller, API, quoteAPI, storageANBP) {
        $scope.data = {};
        if (!$sessionStorage.CL_USER_DATA) {
            $state.go("anbp.signin", { redirect: "anbp.quote" });
            return;
        }

        $scope.sendQuotation = function() {
            try {
                var products = [];
                $rootScope.quotationList.forEach(function(item) {
                    products.push({
                        item_id: item.item_id,
                        quantity: item.order_quantity,
                        item_type: item.buying_item_type || item.item_type
                    });
                });

                var params = {
                    "items": products,
                    "comment": $scope.data.comment,
                };

                quoteAPI
                    .createRFQ(params)
                    .then(function(res) {
                        try {
                            if (res.data._type === "success") {
                                toastr.success(res.data.message);
                                $rootScope.quotationList = [];
                                $sessionStorage.quotationList = [];
                                // $state.go("anbp.account.orders");
                            } else {
                                toastr.error(res.data.message);
                            }
                        } catch (e) {
                            console.log(e);
                        }
                    });
            } catch (e) {
                console.log(e);
            }
        }


        $scope.removeItem = function(index, list) {
            if (list) {
                list.splice(index, 1);
                return;
            }

            $rootScope.quotationList.splice(index, 1);
            $sessionStorage.quotationList = angular.copy($rootScope.quotationList);
        }


        $scope.dividNumber = function(num, discount) {
            return storageANBP.dividNumber(num, discount);
        }

        $scope.goToDetail = function(item) {
            if (item.item_type == 'bundle') {
                item.type = 2;
            } else {
                item.type = item.type || 1;
            }

            $state.go("anbp.category.product.detail", { id: item.item_id || item.id, type: item.type, item_data: item });
        }

        $scope.cancel = function() {
            $state.go('anbp.index');
        }

        $timeout(function() {
        })

    }
})();