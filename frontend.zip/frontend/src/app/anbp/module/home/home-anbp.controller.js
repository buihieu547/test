(function() {
    'use strict';

    angular
        .module('app')
        .controller('home-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $timeout, $state, $rootScope, nabpAPI, storageANBP) {
        $scope.myInterval = 3000;
        $scope.myInterval1 = 6000;

        var imageURL = [
            '../../../assets/img/header/banner_main.jpg',
            '../../../assets/img/header/banner_main.jpg',
            '../../../assets/img/header/banner_main.jpg',
        ]

        $scope.noWrapSlides = false;
        var slides = $scope.slides = [];
        $scope.slide1s = [];
        var currIndex = 0;
        var currIndex1 = 0;


        $scope.getOneItemImage = function(type) {
            return storageANBP.getOneItemImage(type);
        }

        $scope.oneImages = [];
        $scope.bundleImages = [];


        $scope.addSlide = function(data) {
            data = data || {};
            slides.push({
                image: data.image || imageURL[(currIndex + 1) % 3],
                text: data.text,
                id: currIndex++
            });

            $scope.slide1s.push({
                image: imageURL[(currIndex + 1) % 3],
                text: data.text,
                id: currIndex1++
            });

        };

        $scope.changeImage = function(item) {
            item.wine_images[0].thumb_img_temp =   '../../../assets/img/Content/cloth-2.jpg';
        }

        $scope.resetImage = function(item) {
            item.wine_images[0].thumb_img_temp = null;
        }

        $scope.addToCart = function(item) {
            if ($scope.enableAddCart(item)) {
                return $state.go('anbp.cart');
            }
            // console.log($rootScope.cartItems);
            storageANBP.addToCart(item);
        }

        $scope.enableAddCart = function(item) {
            return storageANBP.enableAddCart(item);
        }

        $scope.addToQuote = function(item) {
            if ($scope.enableAddQuote(item)) {
                return $state.go('anbp.quote');
            }
            // console.log($rootScope.cartItems);
            storageANBP.addToQuote(item);
        }

        $scope.enableAddQuote = function(item) {
            return storageANBP.enableAddQuote(item);
        }

        $scope.enableAddWishList = function(item) {
            return storageANBP.enableAddWishList(item);
        }

        $scope.addToWishList = function(item) {
            if ($scope.enableAddWishList(item)) {
                // $state.go();
            }
            storageANBP.addWishList(item);
            // $scope.currentWishList = storageANBP.getWishList();
        }

        $scope.goToDetail = function(item, type) {
            if (type) {
                item.type = type;
            }
            if (item.sale_price) {
                item.resale_price = item.sale_price;
            }
            if (item.id) {
                item.item_id = item.id
            }

            $state.go("anbp.category.product.detail", { id: item.item_id, type: type, item_data: item });
        }

        $scope.searchCategory = function(type, data) {
            var params = { type: type };
            $state.go("anbp.category.product", Object.assign({}, params, data), { inherit: false })
        }

        function getWine() {
            var params = { page: 1, limit: 15 };
            nabpAPI.getWine(params).success(function(res) {
                try {
                    $scope.listItems = res.results.rows;
                    $scope.listItems.forEach(function(ele) {
                        ele.resale_price = ele.sale_price_for_buyer || ele.resale_price || ele.sale_price;
                    });

                } catch (e) {
                    console.log(e.message);
                }
            });
        }

        function getListCategory() {
            nabpAPI.getListCategory().then(function(result) {
                var data = result.data.results;
                data = (data.length > 0) ? data : null;
                $scope.currentCategoryList = data || [

                ];
                // $scope.currentCategoryList.push( $scope.currentCategoryList[0]);
                // $scope.currentCategoryList = data;
            })
        }

        $scope.goToPromotion = function(params) {
            return;
            if (!params.id) return;
            params = { id: params.id };
            $state.go("anbp.promotion", Object.assign({}, params), { inherit: false })
        }


        function getListBundle() {
            nabpAPI.getListBundle({ length: 4, page: 1, sort: 'desc' }).then(function(result) {
                var data = result.data.results;
                data.forEach(function(ele) {
                    ele.resale_price = ele.sale_price_for_buyer || ele.sale_price;
                    ele.item_id = ele.id;
                    ele.type = 2;
                });
                $scope.currentBundleList = data;
            })
        }

        function getLisProgramAll() {
            nabpAPI.getLisProgramAll({ length: 4, page: 1, sort: 'desc' }).then(function(result) {
                var data = result.data.results;
                $scope.currentProgramList = data;
                // console.log(data);
            })
        }

        function initBanner(data) {
            for (var i = 0; i < 4; i++) {
                $scope.addSlide(data[i]);
            }
        }

        function init() {
            for (var i = 0; i < 4; i++) {
                $scope.addSlide();
            }
            getWine();
            getLisProgramAll();
            getListBundle();
            getListCategory();
        }

        init();
    }
})();