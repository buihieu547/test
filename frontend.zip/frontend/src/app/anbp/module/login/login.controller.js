
(function() {
    'use strict';

    angular.module('app').controller('login-anbp.controller', controller);

    /** @ngInject */
    function controller($scope, $localStorage, $sessionStorage, $state, $timeout, loginAPI) {

        $scope.formData = {};
        $scope.brands = {};
        $scope.signIn = signIn;

        $localStorage.$reset();

        /** Internal functions */
        function signIn(data) {
            $('.alert').removeClass('in');

            var params = {
                login: data.login,
                password: data.password
            };

            loginAPI.signIn(params).then(function(res) {
                try {

                    var _data = res.data.results;
                    _data.info.user_id = _data.info.id;
                    $sessionStorage.CL_AUTHENTICATE_TOKEN = _data.token;
                    $sessionStorage.CL_USER_DATA = _data.info;

                    // $localStorage.AUTHENTICATE_TOKEN = _data.token;
                    // $localStorage.USER_DATA = _data.info;
                    // $localStorage.FIRST_LOGIN = _data.first_login;
                    // $localStorage.LOGGED_AT = moment().format('h:mm A');
                    $timeout(function(){
                        $state.go('anbp.index');
                    }, 300)

                } catch (error) {
                    console.log(error)
                    $('.alert').addClass('in');
                }

            });
        }
    }
})();