(function() {
    'use strict';
    angular
        .module('app')
        .controller('po.edit.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, $state, hotkeys, $localStorage, purchaseAPI) {
        //Define variable
        $scope.listMaster = {};
        $scope.mainData = {};

        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];


        (function onInit() {
            getDetailPO();
         
        })();


        function getDetailPO() {
            var id = $stateParams.id;
            if(!id) return;
            purchaseAPI.getPODetail(id).then(function(res) {
                $scope.mainData  = res.data.results;
                $scope.mainData.rqst_dt = new Date($scope.mainData.rqst_dt);
                $scope.mainData.not_delivery_before = new Date($scope.mainData.not_delivery_before);
                $scope.mainData.bill_to = Number( $scope.mainData.bill_to);
                $scope.mainData.ship_to = Number( $scope.mainData.ship_to);
                initList();
            })
        }

        function initList() {
            getListQuote();
            getListIncoterm();
            getListCompanySetup();
            getListWarehouse();
            getListSupplier();
        }

        function getListQuote() {
            purchaseAPI.getListQuoteApproved().then(function(res) {
                $scope.listMaster['listquote'] = res.data.results.rows;
                // $scope.changePQ();
            })
        }

        function getListIncoterm() {
            purchaseAPI.getListIncoterm().then(function(res) {
                $scope.listMaster['incoterm'] = res.data.results;
            })
        }

        function getListCompanySetup() {
            var params = {page: 1, length: 100};
            purchaseAPI.getListCompanySetup().then(function(res) {
                $scope.listMaster['billing'] = res.data.results.rows;
                $scope.changeAddress();                
            })
        }

        function getListWarehouse() {
            purchaseAPI.getListWarehouse().then(function(res) {
                $scope.listMaster['shipping'] = res.data.results.rows;
                $scope.changeAddress(1);
                
            })
        }

        function getListProductPQ() {
            purchaseAPI.getListProductPQ().then(function(res) {

            })
        }


        function getListSupplier() {
            var params = { page: 1, length: 100 }
            purchaseAPI.getListSupplier(params).then(function(res) {
                $scope.listMaster["supplier"] = res.data.results.rows;
            })
        }

        function getPOCode() {
            purchaseAPI.getPOCode().then(function(res) {
              $scope.mainData.cd = res.data.message;
            })
        }
        
        $scope.changePQ = function() {
            var id = $scope.mainData.purchase_quote_id;
            var data = $scope.listMaster['listquote'].find(function(item) {
                return item.id == id;
            })
            if (data) {
                $scope.mainData.supplier_id = data.supplier_id;
                $scope.mainData.detail = data.purchase_quote_details;
            }
        }

        $scope.changeAddress = function(flag) {
            if (flag) {
                var id = $scope.mainData.ship_to;
                console.log(id)
                
                var ship = $scope.listMaster['shipping'].find(function(item) {
                   return item.id == id;
                })
                if (ship) {
                    $scope.mainData.ship_address = ship.full_address;
                }
            } else {
                var id = $scope.mainData.bill_to;
                var bill = $scope.listMaster['billing'].find(function(item) {
                    return item.id == id;
                })
                if (bill) {
                    $scope.mainData.bill_address = bill.full_address;
                }
            }
        }

        $scope.cancel = function() {
            $state.go("app.purchasing.order.manage");
        }

        $scope.sendToSupplier = function() {
            var params = Object.assign({}, $scope.mainData);

            purchaseAPI.createPO(params).then(function(res) {
                try {
                    console.log(res, res.data)
                    if (res.data._type == "success") {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.purchasing.order.manage");
                        }, 1000)

                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }


    }
})();