(function() {
    'use strict';
    angular
        .module('app')
        .controller('po.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, $state, hotkeys, $localStorage, purchaseAPI) {
        //Define variable
        $scope.listMaster = {};
        $scope.mainData = {};

        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];


        (function onInit() {
            getPOCode();
            getListQuote();
            getListIncoterm();
            getListCompanySetup();
            getListWarehouse();
            getListSupplier();
        })();


        function getListQuote() {
            var params = {sts: 5}
            purchaseAPI.getListQuoteApproved(params).then(function(res) {
                $scope.listMaster['listquote'] = res.data.results.rows;
            })
        }

        function getListIncoterm() {
            purchaseAPI.getListIncoterm().then(function(res) {
                $scope.listMaster['incoterm'] = res.data.results;
            })
        }

        function getListCompanySetup() {
            var params = {page: 1, length: 100};
            purchaseAPI.getListCompanySetup().then(function(res) {
                $scope.listMaster['billing'] = res.data.results.rows;
            })
        }

        function getListWarehouse() {
            purchaseAPI.getListWarehouse().then(function(res) {
                $scope.listMaster['shipping'] = res.data.results.rows;
            })
        }

        function getListProductPQ() {
            purchaseAPI.getListProductPQ().then(function(res) {

            })
        }


        function getListSupplier() {
            var params = { page: 1, length: 100 }
            purchaseAPI.getListSupplier(params).then(function(res) {
                $scope.listMaster["supplier"] = res.data.results.rows;
            })
        }

        function getPOCode() {
            purchaseAPI.getPOCode().then(function(res) {
              $scope.mainData.cd = res.data.results.code;
            })
        }
        
        $scope.changePQ = function() {
            var id = $scope.mainData.purchase_quote_id;
            var data = $scope.listMaster['listquote'].find(function(item) {
                return item.id == id;
            })
            if (data) {
                $scope.mainData.supplier_id = data.supplier_id;
                $scope.mainData.detail = data.purchase_quote_details;
            }
        }

        $scope.changeAddress = function(flag) {
            if (flag) {
                var id = $scope.mainData.ship_to;
                var ship = $scope.listMaster['shipping'].find(function(item) {
                   return item.id == id;
                })
                if (ship) {
                    $scope.mainData.ship_address = ship.full_address;
                }
            } else {
                var id = $scope.mainData.bill_to;
                var bill = $scope.listMaster['billing'].find(function(item) {
                    return item.id == id;
                })
                if (bill) {
                    $scope.mainData.bill_address = bill.full_address;
                }
            }
        }

        $scope.cancel = function() {
            $state.go("app.purchasing.order.manage");
        }

        $scope.save = function() {
            var params = Object.assign({}, $scope.mainData);

            purchaseAPI.createPO(params).then(function(res) {
                try {
                    console.log(res, res.data)
                    if (res.data._type == "success") {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.purchasing.order.manage");
                        }, 1000)

                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }


    }
})();