(function() {
    'use strict';
    angular
        .module('app')
        .controller('warehouse-receipt.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, $state, hotkeys, $localStorage, purchaseAPI) {
        //Define variable
        $scope.listMaster = {};
        $scope.mainData = {
            generalInfo:{}
        };

        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];


        (function onInit() {
            generationWarehouseReceiptCode();
            getListInbound();
            getListIncoterm();
            getListCompanySetup();
            getListWarehouse();
        })();


        function getListInbound() {
            purchaseAPI.getPurchaseOrderDelivery().then(function(res) {
                $scope.listMaster['inbound'] = res.data.results;
            })
        }

        function getListIncoterm() {
            purchaseAPI.getListIncoterm().then(function(res) {
                $scope.listMaster['incoterm'] = res.data.results;
            })
        }

        function getListCompanySetup() {
            purchaseAPI.getListCompanySetup().then(function(res) {
                $scope.listMaster['billing'] = res.data.results;
            })
        }

        function getListWarehouse() {
            purchaseAPI.getListWarehouse().then(function(res) {
                $scope.listMaster['shipping'] = res.data.results;
            })
        }

        function getListProductPQ() {
            purchaseAPI.getListProductPQ().then(function(res) {

            })
        }
        function generationWarehouseReceiptCode(){
            purchaseAPI.generationWarehouseReceiptCode().then(function(res){
                console.log(res);
                $scope.mainData.generalInfo.cd = res.data.results.code;
            })
        }

        $scope.changePQ = function(id) {
            purchaseAPI.getDetailPurchaseOrder(id).then(function(res){               
                $scope.mainData.generalInfo.supplier_name= res.data.results.supplier_name;
                $scope.mainData.generalInfo.delivery_location= res.data.results.delivery_location;
                $scope.mainData.generalInfo.receipt_location= res.data.results.delivery_location;
                $scope.mainData.generalInfo.date_of_departure= new Date(res.data.results.date_of_departure);
                $scope.mainData.generalInfo.purchase_order_oli_cd = res.data.results.purchase_order_oli_cd;
                $scope.mainData.generalInfo.purchase_order_oli_id = res.data.results.purchase_order_oli_id;
                $scope.mainData.generalInfo.warehouse_receipt_status_id = '1';
                $scope.mainData.generalInfo.supplier_id = res.data.results.supplier_id;
                
                $scope.mainData.detail = res.data.results.detail;
                // var data = $scope.listMaster['inbound'].find(function(item) {
                //     item.pq_id == id;
                // })
                // if (data) {
                //     $scope.mainData.supplier_name = data.name;
                // }
                // $scope.mainData.supplier_name = "test";
            })
           
        }

        $scope.changeAddress = function(flag) {
            if (flag) {
                var id = $scope.mainData.warehouse_id;
                var ship = $scope.listMaster['shipping'].find(function(item) {
                    item.warehouse_id == id;
                })
                if (ship) {
                    $scope.mainData.ship_address = ship.address_line + ", " + ship.country_name + ", " + ship.city + ", " + ship.state_name + ", " + ship.zip_code;
                }
                $scope.mainData.ship_address = "test"
            } else {
                var id = $scope.mainData.company_id;
                var bill = $scope.listMaster['billing'].find(function(item) {
                    item.company_id == id;
                })
                if (bill) {
                    $scope.mainData.bill_address = bill.address_line + ", " + bill.country_name + ", " + bill.city + ", " + bill.state_name + ", " + bill.zip_code;
                }
                $scope.mainData.bill_address = "test"
            }
        }

        $scope.cancel = function() {
            $state.go("app.purchasing.receipt.manage");
        }

        $scope.sendToSupplier = function() {
            var params = { data: $scope.mainData };
            purchaseAPI.createPO(params).then(function(res){
                try {
                    if (res.data.results.status === true) {
                        toastr.success(res.data.results.message);
                        // $timeout(function() {
                        //     $state.go("app.orders.sale-order.list");
                        // }, 1000)

                    } else {
                        toastr.error(res.data.results.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }
        $scope.createWarehouseReceipt = function(){
            var params = $scope.mainData.generalInfo;
            params.detail = $scope.mainData.detail;
            purchaseAPI.createWarehouseReceipt(params).then(function(res){
                try {
                    console.log(res, res.data)
                    if (res.data._type == "success") {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.purchasing.receipt.manage");
                        }, 1000)

                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }


    }
})();