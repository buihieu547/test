(function() {
    'use strict';
    angular
        .module('app')
        .controller('warehouse-receipt.edit.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, $state, hotkeys, $localStorage, purchaseAPI) {
        //Define variable
        $scope.listMaster = {};
        $scope.mainData = {};

        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];


        (function onInit() {
            getListQuote();
            getListIncoterm();
            getListCompanySetup();
            getListWarehouse();
        })();


        function getListQuote() {
            purchaseAPI.getListQuoteApproved().then(function(res) {
                $scope.listMaster['listquote'] = res.data.results;
            })
        }

        function getListIncoterm() {
            purchaseAPI.getListIncoterm().then(function(res) {
                $scope.listMaster['incoterm'] = res.data.results;
            })
        }

        function getListCompanySetup() {
            purchaseAPI.getListCompanySetup().then(function(res) {
                $scope.listMaster['billing'] = res.data.results;
            })
        }

        function getListWarehouse() {
            purchaseAPI.getListWarehouse().then(function(res) {
                $scope.listMaster['shipping'] = res.data.results;
            })
        }

        function getListProductPQ() {
            purchaseAPI.getListProductPQ().then(function(res) {

            })
        }

        $scope.changePQ = function() {
            var id = $scope.mainData.pq_id;
            var data = $scope.listMaster['listquote'].find(function(item) {
                item.pq_id == id;
            })
            if (data) {
                $scope.mainData.supplier_name = data.name;
            }
            $scope.mainData.supplier_name = "test";
        }

        $scope.changeAddress = function(flag) {
            if (flag) {
                var id = $scope.mainData.warehouse_id;
                var ship = $scope.listMaster['shipping'].find(function(item) {
                    item.warehouse_id == id;
                })
                if (ship) {
                    $scope.mainData.ship_address = ship.address_line + ", " + ship.country_name + ", " + ship.city + ", " + ship.state_name + ", " + ship.zip_code;
                }
                $scope.mainData.ship_address = "test"
            } else {
                var id = $scope.mainData.company_id;
                var bill = $scope.listMaster['billing'].find(function(item) {
                    item.company_id == id;
                })
                if (bill) {
                    $scope.mainData.bill_address = bill.address_line + ", " + bill.country_name + ", " + bill.city + ", " + bill.state_name + ", " + bill.zip_code;
                }
                $scope.mainData.bill_address = "test"
            }
        }

        $scope.cancel = function() {
            $state.go("app.purchasing.order.manage");
        }

        $scope.sendToSupplier = function() {
            var params = { data: $scope.mainData };
            purchaseAPI.createPO(params).then(function(res){
                try {
                    if (res.data.results.status === true) {
                        toastr.success(res.data.results.message);
                        // $timeout(function() {
                        //     $state.go("app.orders.sale-order.list");
                        // }, 1000)

                    } else {
                        toastr.error(res.data.results.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            })
        }


    }
})();