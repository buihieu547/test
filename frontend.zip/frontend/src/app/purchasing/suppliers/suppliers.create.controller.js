

(function() {
  'use strict';
  angular.module('app').controller('supplier.create.controller', controller);

  /** @ngInject */
  function controller($scope, $rootScope, $controller, $uibModal, API, $state, $stateParams, buyerAPI,hotkeys) {
    var $listController = $controller('abstract.list.controller', {
      $scope: $scope
    });
    $scope.buyerType = [];
    $scope.creditStatus = [{
      id: 1,
      name: 'Close'
    }, {
      id: 2,
      name: 'Open'
    }, {
      id: 3,
      name: 'Hold'
    }];
    $scope.buyer = {
      "is_supplier":true,
      primary: {
        // address_line:'1900 RIVER RD',
        // zip_code:'08016',
        // country_code:'US',
        // state_id:30,
        // city_name:'BURLINGTON',
        // email:'',
        // tax_number:'',
        // phone:'1732-348-0000'
      },
      shipping: {
        // name:'SELDAT WAREHOUSE',
        // address_line:'1900 RIVER RD',
        // zip_code:'08016',
        // country_code:'US',
        // state_id:30,
        // city_name:'BURLINGTON',
        // email:'',
        // tax_number:'',
        // phone:'1732-348-0000'
      },
      billing: {
        // name:'SELDAT WAREHOUSE',
        // address_line:'1900 RIVER RD',
        // zip_code:'08016',
        // country_code:'US',
        // state_id:30,
        // city_name:'BURLINGTON',
        // email:'',
        // tax_number:'',
        // phone:'1732-348-0000'
	  },
	  user:[]
    };
    $scope.cancelCreateBuyer = cancelCreateBuyer;
    // $scope.saveCreateBuyer = saveCreateBuyer;
    $scope.copyAddTo = copyAddTo;
    $scope.getListStateByCountry = getListStateByCountry;
    $scope.KeyShorcut =KeyShorcut;
    // $scope.getListCityByState = getListCityByState;
    $scope.companies = [];
    $scope.countries = [];

    $scope.countryTrans = {
      primary: [],
      billing: [],
      shipping: []
    };

    $scope.cityTrans = {
      primary: [],
      billing: [],
      shipping: []
    };

    $scope.stateTrans = {
      primary: [],
      billing: [],
      shipping: []
    };

    (function onInit() {
      getListCompany();
      getListCountry();
      getListBuyerType();
      getListSalePriceList();
      // getListStateByCountry($scope.buyer.primary.country_code, 'primary');
      // getListStateByCountry($scope.buyer.shipping.country_code, 'shipping');
      // getListStateByCountry($scope.buyer.billing.country_code, 'billing');

    })();

    if ($stateParams.id) {
      //Get buyer infomation
      API.get(['buyer/detail', $stateParams.id].join('/')).then(function(res) {
        try {
          $scope.buyer = res.data.results;

        } catch (e) {
          console.log(e);
        }
      })
    }

    /** Internal functions */

    function getListCompany() {
      API.get('company/list-option-company').then(function(res) {
        try {
          $scope.companies = res.data.results;
        } catch (e) {
          console.log(e);
        }
      })
    }

    function getListCountry() {
      API.get('country/get-all').then(function(res) {
        try {
          $scope.countries = res.data.results;
          $scope.countryTrans['primary'] = $scope.countryTrans['shipping'] =
            $scope.countryTrans['billing'] = $scope.countries;

        } catch (e) {
          console.log(e);
        }
      })
    }
    function getListBuyerType(){
      buyerAPI.getListBuyerType().then(function(res){
        try {
          $scope.buyerType = res.data.results;

        } catch (e) {
          console.log(e);
        }
      })
    }
    function getListSalePriceList(){
      buyerAPI.getSalePriceList().then(function(res){
        try {
          $scope.listSalePrice = res.data.results;

        } catch (e) {
          console.log(e);
        }
      })
    }

    function getListCity() {
      API.get('city/get-all').then(function(res) {
        try {
          $scope.cities = res.data.results;
        } catch (e) {
          console.log(e);
        }
      })
    }

    function getListState() {
      API.get('state/get-all').then(function(res) {
        try {
          $scope.states = res.data.results;
        } catch (e) {
          console.log(e);
        }
      })
    }

    function getListStateByCountry(country_code, typeTrans) {
      var params = {
        country: country_code
      }
      buyerAPI.getStateByCountry(params).then(function(res) {
        try {
          $scope.states = res.data.results;
          $scope.stateTrans[typeTrans] = res.data.results;
        } catch (e) {
          console.log(e);
        }
      })
    }

    // function getListCityByState(state_id, typeTrans) {
    //   var params = {
    //     state_id: state_id
    //   }
    //   buyerAPI.getCityByState(params).then(function(res) {
    //     try {
    //       $scope.cities = res.data.results;
    //       $scope.cityTrans[typeTrans] = res.data.results;
    //     } catch (e) {
    //       console.log(e);
    //     }
    //   })
    // }

    function cancelCreateBuyer() {
      $state.go('app.purchasing.supplier.manage')
      // if ($rootScope.fromCreateOrder) {
      //   $state.go('app.orders.sale-order.create', {
      //     ids: $rootScope.listIds
      //   });
      //   $rootScope.fromCreateOrder = false;
      // } else {
      //   $state.go('app.customer.buyers.manage');
      // }

    }


    function copyAddTo(buyer, buyerAddressFrom, buyerAddressTo) {
      if (!buyerAddressTo) {
        buyerAddressTo = 'shipping';
      }
      for (var prop in buyer[buyerAddressFrom]) {
        buyer[buyerAddressTo][prop] = buyer[buyerAddressFrom][prop];
      }
      $scope.countryTrans[buyerAddressTo] = $scope.countryTrans[buyerAddressFrom];
      $scope.stateTrans[buyerAddressTo] = $scope.stateTrans[buyerAddressFrom];
      $scope.cityTrans[buyerAddressTo] = $scope.cityTrans[buyerAddressFrom];

    }

    /*upload image*/
    $scope.createBuyer = createBuyer;
    $scope.listPreview = [];
    $scope.buyerImg =null;

    function createBuyer() {
      var params = angular.copy($scope.buyer);
      params['shipping'] = [params.shipping];
      params['primary'] = [params.primary];
      params['billing'] = [params.billing];
      console.log(params)

      buyerAPI.createBuyer(params, $scope.listFile).then(function(res) {
        console.log(res);
        try{
          if(res._type =='success'){
            window.toastr.success('Customer is created successfully');
            $state.go('app.purchasing.supplier.manage');
          }
          //   window.toastr.error(res.message);
          // }
        }catch(e){
          console.log(e);
        }


      })

    }

    $scope.selectedImage = 0;
    $scope.setFiles = function(event) {
      $scope.selectedImage = 0;
      var files = event.target.files;
      $scope.listFile = files;
      for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var reader = new FileReader();
        reader.onload = $scope.imageIsLoaded;
        reader.readAsDataURL(file);
      }

    }

    $scope.imageIsLoaded = function(e) {
      $scope.$apply(function() {
        $scope.listPreview = [];
        $scope.buyerImg = e.target.result

        $scope.listPreview.push(e.target.result);
      });
    }
    $scope.selectedImage = 0;
    $scope.selectedImages = function(index) {
      $scope.selectedImage = index;
	}
	$scope.clickAdd = function () {
		console.log('a');
		$scope.buyer.user.push({});
	};
	$scope.remove = function (index) {
		$scope.buyer.user.splice(index, 1);
	};

    /*end upload img */

    function parseAddressList(object) {
      var list = angular.copy($scope.formData.addressList);

      var shipping = [],
        billing = [];

      list.forEach(function(item) {
        if (item.isNew) {
          if (parseInt(item.type) === 2) shipping.push(item);
          if (parseInt(item.type) === 1) billing.push(item);
        }

      });

      object.shipping = shipping;
      object.billing = billing;
    }
    function KeyShorcut() {
      hotkeys.toggleCheatSheet();
  }
  hotkeys.bindTo($scope)
  .add({
    combo: 'alt+s',
    description: 'Search data based on key',
    callback: function() {
      $scope.searchAction($scope.search);
    },
    allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
  })
  }
})();
