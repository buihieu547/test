

(function () {
    'use strict';
    angular.module('app').controller('supplier.edit.controller', controller);

    /** @ngInject */
    function controller($scope,$rootScope, $uibModal, API,$state, $stateParams, MessageService, buyerAPI) {
    	$scope.newAddress = newAddress;
        $scope.cancelCreateBuyer = cancelCreateBuyer;
    	$scope.save = save;
        $scope.checkItem = checkItem;
        $scope.deleteAddr = deleteAddr;
        $scope.deleteAllAddr = deleteAllAddr;
        $scope.updateBuyer = updateBuyer;
        $scope.updateAddress = updateAddress;

    	$scope.formData = {};

    	$scope.ADDRESS_TYPE = {
    	    3 : 'MAIN',
            2 : 'SHIPPING',
            1 : 'BILLING'
        };
        $scope.buyerType = [];
        $scope.creditStatus=[{id:1,name:'Close'},{id:2,name:'Open'},{id:3,name:'Hold'}];

        (function onInit() {
            getDetail();
            getListCity();
            getListState();
            getListCountry();
            getListBuyerType();
            getListSalePriceList();
        })();

        $scope.list = {
            checklist : []
        };

    	/** Internal functions */

      function cancelCreateBuyer() {
        $state.go('app.purchasing.supplier.manage')
			// if($rootScope.fromCreateOrder){
			// 	console.log($rootScope.listIds);
			// 	 $state.go('app.orders.sale-order.create',{ids: $rootScope.listIds});
			// 	$rootScope.fromCreateOrder = false;
			// }else{
			// 	$state.go('app.customer.buyers.manage');
			// }

        }

    	function newAddress() {
            $uibModal.open({
                templateUrl: 'app/buyers/new.address.modal.html',
                backdrop :'static',
                size : 'lg',
                controller: ['$scope','$uibModalInstance' ,'CITIES', 'COUNTRIES', 'STATES', 'buyerAPI',
                    function (modalScope, $uibModalInstance, CITIES, COUNTRIES, STATES, buyerAPI) {

                    // modalScope.cities = CITIES;
                    modalScope.countries = COUNTRIES;
                    // modalScope.states = COUNTRIES;
                    modalScope.getListStateByCountry = getListStateByCountry;
                    modalScope.getListCityByState = getListCityByState;
                    // modalScope.genId = genId;

                    modalScope.formData = {
                        type : "1",

                    };


                    modalScope.save = function (formData) {
                        formData.isNew = true;
                        $scope.formData.addressList.push(formData);

                        $uibModalInstance.close(formData);

                    };

                    modalScope.cancel = function () {
                        $uibModalInstance.close();
                    };

                    function getListCityByState(state_id) {
                        var params = {state_id: state_id};
                        buyerAPI.getCityByState(params).then(function(res) {
                            try {
                                modalScope.cities = res.data.results;
                            } catch(e) {
                                console.log(e);
                            }
                        })
                    }

                    function getListStateByCountry(country_code) {
                        var params = {country: country_code}
                        buyerAPI.getStateByCountry(params).then(function(res) {
                            try {
                                modalScope.states = res.data.results;
                                console.log(modalScope.states[0].id)
                                modalScope.formData.state_id =  modalScope.states[0].id;
                            } catch(e) {
                                console.log(e);
                            }
                        })
                    }

                }],
                resolve : {
                    CITIES : function () {
                        if($scope.cities) return $scope.cities;
                        else
                        {
                            return getListCity().then(function (res) {
                                return res;
                            })
                        }
                    },
                    COUNTRIES : function () {
                        if($scope.countries) return $scope.countries;
                        else
                        {
                            return getListCountry().then(function (res) {
                                return res;
                            })
                        }
                    },
                    STATES : function () {
                        if($scope.states) return $scope.states;
                        else
                        {
                            return getListState().then(function (res) {
                                return res;
                            })
                        }
                    },
                    getListStateByCountry: function () {
                        return getListStateByCountry;
                    },
                    getListCityByState: function () {
                        return getListCityByState;
                    }
                }

            });
        }
        $scope.img = '';
        function getDetail() {
            var id = $stateParams.id;
            if(id)
            {
                API.get('buyer/detail/'+id).success(function (res) {
                    console.log(res);

                    $scope.formData = res.results;
                    $scope.formData.is_supplier=true;
                    $scope.img = res.results.img;
                    $scope.formData.addressList = mergeAddressList(res.results);

                });
            }
        }
        $scope.clickAdd = function () {
            console.log('a');
            $scope.formData.user.push({});
        };
        $scope.remove = function (index) {
            $scope.formData.user.splice(index, 1);
        };

        function mergeAddressList(data) {
            var addressList = [];

            if(data.shipping) addressList = addressList.concat(data.shipping);
            if(data.billing) addressList = addressList.concat(data.billing);

            // add property isCheck to array
            addressList.map( function(addr) {
                addr.isChecked = false;
                return addr;
            });
            return addressList;
        }
        function getListBuyerType(){
            buyerAPI.getListBuyerType().then(function(res){
              try {
                $scope.buyerType = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          function getListSalePriceList(){
            buyerAPI.getSalePriceList().then(function(res){
              try {
                $scope.listSalePrice = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }

        function parseAddressList(object) {
    	    var list = angular.copy($scope.formData.addressList);

            var shipping = [], billing = [];

            list.forEach(function (item) {
                if(item.isNew)
                {
                    if(parseInt(item.type) === 2) shipping.push(item);
                    if(parseInt(item.type) === 1) billing.push(item);
                }

            });

            object.shipping = shipping;
            object.billing = billing;
        }

        function getListCity() {
            return API.get('city/get-all').then(function(res) {
                try {
                    $scope.cities = res.data.results;

                    return $scope.cities;
                } catch(e) {
                    console.log(e);
                }
            })
        }

        function getListState() {
            return API.get('state/get-all').then(function(res) {
                try {
                    $scope.states = res.data.results;
                    return $scope.states;
                } catch(e) {
                    console.log(e);
                }
            })
        }

        function getListCountry() {
            return API.get('country/get-all').then(function(res) {
                try {
                    $scope.countries = res.data.results;
                    return $scope.countries;
                } catch(e) {
                    console.log(e);
                }
            })
        }

        function genUniqId(prefix) {
            var timestamp = new Date().getUTCMilliseconds();
            timestamp += '';
            if(timestamp.length != 3)
                timestamp = timestamp.length == 1 ? '00'+timestamp: '0'+timestamp;
            return prefix + '-' + timestamp;
        }

        function checkItem() {
            console.log($scope.formData.addressList);
        }

        function deleteAddr (flag) {
            var removeLst = [];
            $scope.formData.addressList.forEach(function(addr) {
                if(addr.isChecked == true ) {
                    removeLst.push(addr.address_id)
                }
            })
            if(removeLst.length == 0) {
                window.toastr.error('Please select at least one address to remove')
                return;
            }
            MessageService.showConfirm("Are you sure you want to delete " + ((flag)? "all records?" : "this record?")).then(function(yes) {
                if(yes) {

                    var addList = [];
                    var dataDelete = {
                        buyer_id : $stateParams.id,
                        address_ids: removeLst.join(',')
                    }
                    console.log(dataDelete);
                    API.delete(['buyer','delete-address'].join('/'),  dataDelete).success(function (res) {
                        window.toastr.success(res.message);

                        addList = $scope.formData.addressList.filter(function(addr) {
                            if(addr.isChecked == false ) {
                                return addr;
                            }
                        })
                        $scope.formData.addressList = addList;
                    });
                }
            })

        }

        function deleteAllAddr () {
            $scope.formData.addressList = $scope.formData.addressList.map(function(addr) {
                addr.isChecked = true;
                // if(addr.isChecked == true) {
                return addr;
                // }
            })
            deleteAddr(1)
        }

        function uploadProduct(ObjectFile) {

            var file = ObjectFile.files[0];

            if(file)
            {
                resetUpload();
                $rootScope.forceHidden = true;
                $scope.uploading = true;
            }

        }

        function resetUpload() {
            $scope.uploadResult = {

            };
        }

        function save(formData) {
            parseAddressList(formData);


            API.put(['buyer','update',$stateParams.id].join('/'),formData).success(function (res) {
                console.log(res);

                window.toastr.success(res.message);
                $state.go('app.purchasing.supplier.manage');
            });
        }

        /*upload image*/
        $scope.listPreview=[];
        function updateBuyer(formData) {
            console.log(formData)
          if(formData.credit_sts != 2) {
            delete formData.credit_sts;
            delete formData.line_of_credit;
          }
            console.log('update');
            parseAddressList(formData);
                buyerAPI.updateImageForBuyer($stateParams.id, formData, $scope.listFile).then(function(res){
                    window.toastr.success(res.message);
                    $state.go('app.purchasing.supplier.manage');

                })
        }

        $scope.selectedImage = 0;
        $scope.setFiles = function(event){
            $scope.selectedImage = 0;
            // $scope.listPreview
            var files = event.target.files;
            $scope.listFile = files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded;
                reader.readAsDataURL(file);
            }
            console.log('files',  $scope.listFile)
        }

        $scope.imageIsLoaded = function(e){
            $scope.$apply(function() {
                $scope.listPreview =[];
                $scope.listPreview.push(e.target.result);
            });
        }
        $scope.selectedImage = 0;
        $scope.selectedImages = function(index){
            $scope.selectedImage = index;
        }

        /*end upload img */

        $scope.getListStateByCountry = getListStateByCountry;
        // $scope.getListCityByState = getListCityByState;

        function getListStateByCountry(country_code) {
            var params = {country: country_code}
            $scope.states = [];
            $scope.cities = [];
            buyerAPI.getStateByCountry(params).then(function(res) {
                try {
                    $scope.states = res.data.results;
                } catch(e) {
                    console.log(e);
                }
            })
        }

        function getListCityByState(state_id) {
            var params = {state_id: state_id};
            $scope.cities = [];
            buyerAPI.getCityByState(params).then(function(res) {
                try {
                    $scope.cities = res.data.results;
                } catch(e) {
                    console.log(e);
                }
            })
        }
        function updateAddress(action,objUpdate,position) {
            var copyObj = angular.copy(objUpdate);
            console.log(position);
            $uibModal.open({
                templateUrl: 'app/buyers/new.address.modal.html',
                backdrop :'static',
                size : 'lg',
                controller: ['$scope','$uibModalInstance' ,'CITIES', 'COUNTRIES', 'STATES', 'buyerAPI',
                    function (modalScope, $uibModalInstance, CITIES, COUNTRIES, STATES, buyerAPI) {
                        modalScope.typeAction = action
                        modalScope.countries = COUNTRIES;
                        modalScope.getListStateByCountry = getListStateByCountry;
                        modalScope.getListCityByState = getListCityByState;

                        modalScope.formData = {
                            type:''
                        }

                        modalScope.formData = objUpdate;
                        modalScope.formData.type=(objUpdate.type).toString();
                        getListStateByCountry(objUpdate.country_code);
                        // getListCityByState(objUpdate.state_id);


                    modalScope.save = function (formData) {
                        if(copyObj.isNew == true){
                            formData.isNew = true;
                        }

                        $scope.formData.addressList[position] = formData;
                        $uibModalInstance.close(formData);

                    };

                    modalScope.cancel = function () {
                        $scope.formData.addressList[position] = copyObj
                        $uibModalInstance.close(copyObj);
                    };

                    function getListCityByState(state_id) {
                        var params = {state_id: state_id};
                        buyerAPI.getCityByState(params).then(function(res) {
                            try {
                                modalScope.cities = res.data.results;
                            } catch(e) {
                                console.log(e);
                            }
                        })
                    }

                    function getListStateByCountry(country_code) {
                        var params = {country: country_code}
                        buyerAPI.getStateByCountry(params).then(function(res) {
                            try {
                                modalScope.states = res.data.results;
                            } catch(e) {
                                console.log(e);
                            }
                        })
                    }

                }],
                resolve : {
                    CITIES : function () {
                        if($scope.cities) return $scope.cities;
                        else
                        {
                            return getListCity().then(function (res) {
                                return res;
                            })
                        }
                    },
                    COUNTRIES : function () {
                        if($scope.countries) return $scope.countries;
                        else
                        {
                            return getListCountry().then(function (res) {
                                return res;
                            })
                        }
                    },
                    STATES : function () {
                        if($scope.states) return $scope.states;
                        else
                        {
                            return getListState().then(function (res) {
                                return res;
                            })
                        }
                    },
                    getListStateByCountry: function () {
                        return getListStateByCountry;
                    },
                    getListCityByState: function () {
                        return getListCityByState;
                    }
                }

            });
        }
    }
})();
