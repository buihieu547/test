

(function () {
    'use strict';

    angular.module('app').controller('supplier.manage.controller', controller);

    /** @ngInject */
    function controller($scope, $controller,buyerAPI, API, $state, MessageService, hotkeys) {
    	var $listController = $controller('abstract.list.controller',{ $scope : $scope });
        $scope.itemPerPageOptions = [15,30];
        $scope.pagination = {
            length : $scope.itemPerPageOptions[0]
        };
        $scope.getList = getList;
        $scope.addNewBuyer = addNewBuyer;
        $scope.searchAction = searchAction;
        $scope.resetAction = resetAction;
        $scope.deleteBuyer = deleteBuyer;
        $scope.editBuyer = editBuyer;
        $scope.KeyShorcut =KeyShorcut;
        $scope.search = {};

        $scope.list = {
            items : []
        };
        $scope.buyerType=[];

        /** Internal functions */

        (function onInit() {
            $scope.focusFlag = false;
            getList();
            getListBuyerType();
        })();

        $scope.selectedIndex = -1;
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys.bindTo($scope)
        .add({
          combo: 'alt+s',
          description: 'Search data based on key',
          callback: function() {
            $scope.searchAction($scope.search);
          },
          allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        .add({
          combo: 'alt+r',
          description: 'Reset data search',
          callback: function() {
            $scope.resetAction();
          },
          allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        .add({
          combo: 'alt+n',
          description: 'New Buyer',
          callback: function() {
            $state.go("app.rma.create");
          }
        })
          .add({
              combo: 'enter',
              description: 'Go to  detail buyer',
              callback: function (e) {
                  if ($scope.selectedIndex > -1) {
                      $scope.item_detail = $scope.list.items[$scope.selectedIndex];
                      editBuyer($scope.item_detail);

                  }

             }
          })
          .add({
            combo: 'alt+pageup',
            description: 'Move to next page',
            callback: function(e) {
                $scope.pagination.page++;
                if ($scope.pagination.page > $scope.pagination.total_page) {
                    $scope.pagination.page = $scope.pagination.total_page;
                    return;
                }
                $scope.changePage();
            }
        })
        .add({
            combo: 'alt+pagedown',
            description: 'Move to previous page',
            callback: function(e) {
                $scope.pagination.page--;
                if ($scope.pagination.page < 1) {
                    $scope.pagination.page = 1;
                    return;
                }
                $scope.changePage();
            }
        })
        .add({
            combo: 'alt+end',
            description: 'Move to last page',
            callback: function(e) {
                e.preventDefault();
                $scope.pagination.page = $scope.pagination.total_page;
                $scope.changePage();

            }
        })
        .add({
            combo: 'alt+home',
            description: 'Move to first page',
            callback: function(e) {
                e.preventDefault();
                $scope.pagination.page = 1;
                $scope.changePage();
            }
        })

        function searchAction(search) {
            var params = $listController.getParams();
            angular.merge(params, search);
            $listController.searchAction(params);
        }

        function resetAction() {
            $scope.search = {};
            $listController.searchAction();
        }

        function addNewBuyer() {
        	$state.go("app.purchasing.supplier.create");
        }

        function deleteBuyer(buyerId) {
            MessageService.showConfirm("Are you sure you want to delete this record?").then(function(yes) {
                if(yes)
                {
                    API.delete(['buyer','delete',buyerId].join('/')).success(function (res) {
                        window.toastr.success(res.message);
                        getList();
                    });
                }
            })
        }


        function editBuyer(item) {
            if (item.id) {
                $state.go("app.purchasing.supplier.edit",{id: item.id});
            }
        }

        function getList() {
            var params = $listController.getParams();
            API.get('company/list-option-company?is_supplier=true',params).then(function(res) {
                try {
                    $scope.list.items = res.data.results.rows;
                    $listController.matchPagingOption(res.data.results);
                    $scope.focusFlag = false;
                    if(res.data.results.rows.length <= 0) {
                      $scope.focusFlag = true;
                    }
                } catch(e) {
                    console.log(e);
                }
            });
        }
        function getListBuyerType() {

            buyerAPI.getListBuyerType().then(function(res) {
                try {
                    $scope.buyerType = res.data.results;

                } catch(e) {
                    console.log(e);
                }
            });
        }

    }
})();
