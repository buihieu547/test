(function() {
    'use strict';

    angular
        .module('app')
        .service('purchaseAPI', service);

    /** @ngInject */
    function service(API, $q, $interval, $http) {
        //PURCHASE ORDER
        this.getListPO = function(params) {
            var url = 'oli_purchase_order';
            return API.get(url, params);
        }
        this.getPODetail = function(id) {
            var url = 'oli_purchase_order/' + id;
            return API.get(url);
        }
        this.getPOCode = function() {
            var url = 'oli_purchase_order/generate_code';
            return API.get(url);
        }

        this.getPOStatus = function() {
            var url = 'oli_purchase_order/status';
            return API.get(url);
        }

        //PURCHASE QUOTE ACTION
        this.PQSendMail = function(params) {
            var url = 'sale-price';
            return API.post(url, params);
        }

        this.PQApprove = function(params) {
            var url = 'sale-price';
            return API.post(url, params);
        }

        this.PQReject = function(params) {
            var url = 'sale-price';
            return API.post(url, params);
        }

        this.PQCreatePO = function(params) {
            var url = 'sale-price';
            return API.post(url, params);
        }

        this.sendMailPO = function(id, params) {
            var url = 'oli_purchase_order/status/' + id;
            return API.put(url,params);
        }

        this.getListQuoteApproved = function(params) {
            var url = 'purchase_quote';
            return API.get(url, params);
        }
        this.generateCodePurchaseQuotation = function() {
            var url = 'purchase_quote/generate_code';
            return API.get(url);
        }

        this.getListIncoterm = function() {
            var url = 'incoterm';
            return API.get(url);
        }

        this.getListCompanySetup = function(params) {
            var url = ['company-master', 'index'].join('/');
            return API.get(url, params);
        }

        this.getListWarehouse = function(params) {
            var url = 'warehouse/index';
            return API.get(url, params);
        }

        this.getListProductPQ = function() {
            var url = 'sale-price/get-list-option';
            return API.get(url);
        }

        this.createPO = function(params) {
            var url = 'oli_purchase_order';
            return API.post(url, params);
        }

        this.getListSupplier = function(params) {
            var url = 'company/list-option-company?is_supplier=true';
            return API.get(url, params);
        }
        this.getListPoOption = function() {
            var url = 'oli_purchase_order?sts=2&is_all=1';
            return API.get(url);
        }

        this.getListPurchaseQuotation = function(params) {
            var url = 'purchase_quote';
            return API.get(url, params);
        }

        this.createPurchaseQuotation = function(params) {
            var url = 'purchase_quote';
            return API.post(url, params);
        }

        this.getDetailPurchaseQuotation = function(id) {
            var url = 'purchase_quote/' + id;
            return API.get(url);
        }

        this.upddatePurchaseQuotation = function(params, id) {
            var url = 'purchase_quote/' + id;
            return API.put(url, params);
        }

        this.sentToSuppPQ = function(id) {
            var url = 'purchase_quote/sent_to_supp/' + id;
            return API.put(url);
        }

        this.aprvByMgrPQ = function(id) {
            var url = 'purchase_quote/aprv_by_mgr/' + id;
            return API.put(url);
        }

        this.rjtByMgrPQ = function(id) {
                var url = 'purchase_quote/rjt_by_mgr/' + id;
                return API.put(url);
            }
            /*Warehouse Receipt */
        this.getListWarehouseReceipt = function(params) {
            var url = 'warehouse_receipt';
            return API.get(url, params);
        }
        this.generationWarehouseReceiptCode = function() {
            var url = 'warehouse_receipt/generate_code';
            return API.get(url);
        }
        this.updateStatusWarehouseReceiptCode = function(id, params) {
            var url = 'warehouse_receipt/status/' + id;
            return API.put(url, params);
        }
        this.createWarehouseReceipt = function(params) {
            var url = 'warehouse_receipt';
            return API.post(url, params);
        }
        this.getPurchaseOrderDelivery = function() {
            var url = 'purchase_order_delivery?is_all=1&sts=2';
            return API.get(url)
        }
        this.getDetailPurchaseOrder = function(id) {
            var url = 'purchase_order_delivery/' + id;
            return API.get(url);
        }
        this.getListInboundWithPage = function(params) {
            var url = 'purchase_order_delivery';
            return API.get(url, params);
        }
        this.getListStatus = function() {
            var url = 'purchase_quote_status';
            return API.get(url);
        }
    }
})();