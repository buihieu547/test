(function() {
    'use strict';

    angular
        .module('app')
        .controller('inbound.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, API, purchaseAPI, $localStorage, MessageService, hotkeys, $state,$timeout) {

        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.getList = getList;
        $scope.KeyShorcut = KeyShorcut;
        //  $scope.scrollToFilter =scrollToFilter;
        $scope.filter = filter;
        $scope.list = {
            items: [],
            search: {}
        };
        $scope.listMaster=[];
        $scope.listStatus = [{id:1,name:'InTransit'},{id:2,name:'Arrived'}];  
        $scope.resetAction =resetAction;

        /** Internal functions */

        (function onInit() {
            getListSupplier();
            getListPoOption();
            getList();            
        })();
        
      
        $scope.goToSaleQuote = function(id) {           
            $state.go("app.orders.sales-quotation.buyerrfq",{id: id});            
         }

        function getList() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            purchaseAPI
               .getListInboundWithPage(params)
                .then(function(res) {

                    try {
                        $scope.list.items = res.data.results.rows;
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }  
        function getListSupplier() {
            var params = { page: 1, length: 100 }
            purchaseAPI.getListSupplier(params).then(function(res) {
                $scope.listMaster["supplier"] = res.data.results.rows;
            })
        }
        function getListPoOption() {           
            purchaseAPI.getListPoOption().then(function(res) {
                $scope.listMaster["po"] = res.data.results;
            })
        }
        

        function getPOStatus() {
            purchaseAPI.getPOStatus().then(function(res) {
                $scope.listMaster["status"] = res.data.results;
            })
        }
    
        function updateStatus(orderNum) {
            var params = {
                orderNum: orderNum
            };
            API
                .put('order/update-status', params)
                .then(function(res) {
                    try {
                        getList();
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+n',
                description: 'Create New Sales order',
                callback: function(e) {
                    $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'enter',
                description: 'Go to  detail Sales order',
                callback: function(e) {
                    if ($scope.selectedIndex > -1) {
                        $scope.item_detail = $scope.list.items[$scope.selectedIndex].id;
                        $state.go('app.orders.detail', { id: $scope.item_detail })
                    }

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+s',
                description: 'Search',
                callback: function() {
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+r',
                description: 'Reset Search',
                callback: function() {
                    $scope.list.search = {};
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pagedown',
                description: 'Move to next page',
                callback: function(e) {
                    $scope.pagination.page++;
                    if ($scope.pagination.page > $scope.pagination.total_page) {
                        $scope.pagination.page = $scope.pagination.total_page;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pageup',
                description: 'Move to previous page',
                callback: function(e) {
                    $scope.pagination.page--;
                    if ($scope.pagination.page < 1) {
                        $scope.pagination.page = 1;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+end',
                description: 'Move to last page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = $scope.pagination.total_page;
                    $scope.changePage();

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+home',
                description: 'Move to first page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = 1;
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            // .add({
            //     combo: 'alt+shift+a',
            //     description: 'Filter Search',
            //     callback: function(e) {
            //         e.preventDefault();
            //         $scope.pagination.page = 1;
            //         $scope.scrollToFilter()
            //     },
            //     allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            // })

        function scrollToTable() {
            try {
                var top = document.getElementsByClassName("custom-table")[0].offsetTop - 100;
                $('html, body').animate({
                    scrollTop: top
                }, 500);
            } catch (e) {
                console.log(e)
            }
        }       

        function filter(type) {
            $scope.list.search.sts = type;

            return $scope.searchAction($scope.list.search);
        }        
        $scope.dateOptions = {}
        $scope.upDateDateOption = function(key, min, max){
            $scope.dateOptions[key] = {
                showWeeks: false,
            }
            if(min) {
                $scope.dateOptions[key].minDate  = min; 
            }
            if(max) {
                $scope.dateOptions[key].maxDate  = max; 
            }
        };
        function resetAction() {
            $timeout(function() {
                angular.element(".multiple-select2").trigger("change");
            }, 1000);
            $scope.list.search = {};
            $scope.searchAction($scope.list.search);
        }
    
    }
})();