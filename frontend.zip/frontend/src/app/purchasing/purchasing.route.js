(function() {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.purchasing', {
                url: '/purchasing',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.supplier', {
                url: '/supplier',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.supplier.manage', {
                url: '/manage',
                templateUrl: 'app/purchasing/suppliers/suppliers.manage.html',
                controller: 'supplier.manage.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.supplier.create', {
                url: '/create/:redirect/:ids',
                templateUrl: 'app/purchasing/suppliers/suppliers.create.html',
                controller: 'supplier.create.controller',
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.purchasing.supplier.edit', {
                url: '/edit/:id',
                templateUrl: 'app/purchasing/suppliers/suppliers.edit.html',
                controller: 'supplier.edit.controller',
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.purchasing.order', {
                url: '/order',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.order.manage', {
                url: '/manage',
                templateUrl: 'app/purchasing/purchase-order/purchase-order.html',
                controller: 'purchase-order.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.order.create', {
                url: '/create',
                templateUrl: 'app/purchasing/purchase-order/po.create.html',
                controller: 'po.create.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.order.edit', {
                url: '/edit/:id',
                templateUrl: 'app/purchasing/purchase-order/po.edit.html',
                controller: 'po.edit.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.quotation', {
                url: '/quotation',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.quotation.manage', {
                url: '/manage',
                templateUrl: 'app/purchasing/purchase-quotation/pq.list.html',
                controller: 'pq.list.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.quotation.create', {
                url: '/create',
                templateUrl: 'app/purchasing/purchase-quotation/pq.create.html',
                controller: 'pq.create.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.quotation.edit', {
                url: '/edit/:id',
                templateUrl: 'app/purchasing/purchase-quotation/pq.edit.html',
                controller: 'pq.edit.controller',
                // middleware : ['auth', 'manager_salesman']
            })


            .state('app.purchasing.receipt', {
                url: '/receipt',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.receipt.manage', {
                url: '/manage',
                templateUrl: 'app/purchasing/warehouse-receipt/warehouse-receipt.list.html',
                controller: 'warehouse-receipt.list.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.receipt.create', {
                url: '/create',
                templateUrl: 'app/purchasing/warehouse-receipt/warehouse-receipt.create.html',
                controller: 'warehouse-receipt.create.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.receipt.edit', {
                url: '/edit/:id',
                templateUrl: 'app/purchasing/warehouse-receipt/warehouse-receipt.edit.html',
                controller: 'warehouse-receipt.edit.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.purchasing.inbound', {
                url: '/inbound',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.purchasing.inbound.manage', {
                url: '/manage',
                templateUrl: 'app/purchasing/inbound/inbound.list.html',
                controller: 'inbound.list.controller',
                // middleware : ['auth', 'manager_salesman']
            })
    }

})();