(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.fulfillment', {
                url: '/fulfillment',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.fulfillment.schedule', {
                url: '/schedule',
                templateUrl: 'app/fulfillment/schedule.html',
                controller: 'fulfillment.schedule.controller',
            })
            .state('app.fulfillment.order', {
                url: '/delivery-order',
                templateUrl: 'app/fulfillment/delivery-order.html',
                controller: 'fulfillment.schedule.controller',
            })
            .state('app.fulfillment.truck', {
                url: '/truck',
                templateUrl: 'app/fulfillment/truck.html',
                controller: 'fulfillment.schedule.controller',
            })
            .state('app.fulfillment.truck-type', {
                url: '/truck-type',
                templateUrl: 'app/fulfillment/truck-type.html',
                controller: 'fulfillment.schedule.controller',
            })
            .state('app.fulfillment.driver', {
                url: '/driver',
                templateUrl: 'app/fulfillment/driver.html',
                controller: 'fulfillment.schedule.controller',
            })
            .state('app.fulfillment.route', {
                url: '/route',
                templateUrl: 'app/fulfillment/routes.html',
                controller: 'fulfillment.schedule.controller',
            })
           
    }

})();
