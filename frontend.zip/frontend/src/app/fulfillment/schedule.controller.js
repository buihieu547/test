(function() {
    'use strict';

    angular.module('app').controller('fulfillment.schedule.controller', controller);
    /** @ngInject */
    function controller($sce, $scope, productAPI, $rootScope, $state, envConfig) {
        $scope.SRS_URL = envConfig.SRS_URL;
        $scope.trustAsResourceUrl = $sce.trustAsResourceUrl;
    } 
  

})();
