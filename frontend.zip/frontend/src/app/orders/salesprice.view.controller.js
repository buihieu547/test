(function () {
    'use strict';
    angular
        .module('app')
        .controller('salesprice.view.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,  productAPI,salespriceAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            products: []
        };
        $scope.listStatus = [
            {
                id: 0,
                name: "In-Active"
            }, {
                id: 1,
                name: "Active "
            }
        ];
        $scope.productList = [];
        // $scope.changeQTY =changeQTY;
        (function onInit() {
            getProductList();
            var id = $stateParams.id;
            if(id)
            {
                getDetailSalePrice(id);
            }
        })();
        $scope.clickAdd = function () {

            $scope
                .mainData
                .products
                .push({});
        };
        $scope.remove = function (index) {
            $scope
                .mainData
                .products
                .splice(index, 1);
                // $scope.changeQTY();
        };
        $scope.cancelSalePrice= function(){
            $state.go("app.orders.sale-price.list");
        }
        // $scope.createSalePrice = function(){
        //     console.log($scope.mainData);
        //     var params = $scope.mainData.generalInfo;
        //     params.products = $scope.mainData.products;
        //     console.log(params);
        //     salespriceAPI.createSalePrice(params).then(function(res){
        //         try{
        //             if(res.data._type=='success'){
        //                 toastr.success(res.data.message);
        //                 $timeout(function() {
        //                     $state.go("app.salesprice.list");
        //                 }, 500)

        //             } else {
        //                 toastr.error(res.data.message);
        //             }

        //         }catch(e){
        //             console.log(e)
        //         }
        //     })
        // }
        function getDetailSalePrice(id){
            salespriceAPI.getDetailSalePrice(id).then(function(res){
                try{
                    if(res.data._type=='success'){
                        $scope.mainData.generalInfo = res.data.results;
                        $scope.mainData.generalInfo.start_dt = new Date($scope.mainData.generalInfo.start_dt);
                        $scope.mainData.generalInfo.end_dt = new Date($scope.mainData.generalInfo.end_dt);
                        $scope.mainData.products = res.data.results.products;
                        angular.forEach($scope.mainData.products,function(item){
                            item.sale_price = parseFloat(item.sale_price);
                            $scope.changeProductLine(item)
                        })

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }

        $scope.updateSalePrice = function(id){
            console.log($scope.mainData);
            var params = $scope.mainData.generalInfo;
            params.products = $scope.mainData.products;
            salespriceAPI.updateSalePrice(id,params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.sale-price.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        $scope.changeProductLine = function(item,index){
            console.log(index)
            var itemID=$scope.productList.filter(function(product){
                if(product.item_id == item.wine_id)
                    return product;
            });
            item.name = itemID[0].name;
            item.uom_name=itemID[0].uom_name;
            item.price=itemID[0].price;
            item.resale_price = itemID[0].resale_price;
        }

        function getProductList(){
            productAPI.getListItemOption().then(function(res){
                $scope.productList = res.data.results;
            })
        }
    }
})();
