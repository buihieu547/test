(function () {
    'use strict';
    angular
        .module('app')
        .controller('delivery-orders.view.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,  productAPI,deliveryOrderAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            products: []
        };       
        $scope.listStatus = [
            {
                id: '0',
                name: "In-Active"
            }, {
                id: '1',
                name: "Active "
            }
        ];
        $scope.listPickupTime = [
            {
                id: '8-17',
                name: "8-17"
            }
        ];
        $scope.listStatus = [
         {
            id: 3,
            name: "IN TRANSIT"
        }, {
            id: 4,
            name: "DELIVERED"
        }];
        $scope.listDeliveryType=[
            {id:2,name:'Home Delivery'},
            {id:3,name:'Courier Delivery'},
            {id:1,name:' Customer Pickup'}            
        ];
        $scope.productList = [];
        $scope.changeSaleOrder =changeSaleOrder;
        (function onInit() {
            getListSaleOrder();
            getPickupLocation();
            var id = $stateParams.id;
            if(id)
            {
                getDetailDeliveryOrder(id);
            }
        })();
        $scope.clickAdd = function () {

            $scope
                .mainData
                .products
                .push({});
        };
        $scope.remove = function (index) {
            $scope
                .mainData
                .products
                .splice(index, 1);
                // $scope.changeQTY();
        };
        $scope.cancelSalePrice= function(){
            $state.go("app.orders.delivery-order.list");
        }
        $scope.getListProduct= function(order_id,addr_id){
            var itemID= $scope.listDelivery.filter(function(address){
                if(address.address_id == addr_id)
                    return address;
            });
            $scope.mainData.generalInfo.delivey_address = itemID[0].full_address;
          
        }
        // $scope.createSalePrice = function(){
        //     console.log($scope.mainData);
        //     var params = $scope.mainData.generalInfo;
        //     params.products = $scope.mainData.products;
        //     console.log(params);
        //     salespriceAPI.createSalePrice(params).then(function(res){
        //         try{
        //             if(res.data._type=='success'){
        //                 toastr.success(res.data.message);
        //                 $timeout(function() {
        //                     $state.go("app.salesprice.list");
        //                 }, 500)

        //             } else {
        //                 toastr.error(res.data.message);
        //             }

        //         }catch(e){
        //             console.log(e)
        //         }
        //     })
        // }
        function getDetailDeliveryOrder(id){
            deliveryOrderAPI.getDetailDeliveryOrder(id).then(function(res){
                try{
                    if(res.data._type=='success'){
                        $scope.mainData.generalInfo = res.data.results;
                        $scope.mainData.generalInfo.delivery_date = new Date($scope.mainData.generalInfo.delivery_date);
                        $scope.mainData.generalInfo.pickup_date = new Date($scope.mainData.generalInfo.pickup_date);
                        $scope.mainData.products = res.data.results.details;
                        $scope.mainData.generalInfo.status = res.data.results.status_id;
                        $timeout(function(){
                            $scope.changeSaleOrder(res.data.results.order_id);
                            $scope.getListProduct(res.data.results.order_id,res.data.results.address_id);
                        },500)
                        

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }

        $scope.updateDelivery = function(){           
            var params = $scope.mainData.generalInfo;
            // params.status = $scope.mainData.products.status;
            deliveryOrderAPI.updateDeliveryStatus($scope.mainData.generalInfo.id,params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.delivery-order.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        $scope.changeProductLine = function(item,index){
            console.log(index)
            var itemID=$scope.productList.filter(function(product){
                if(product.item_id == item.wine_id)
                    return product;
            });
            item.name = itemID[0].name;
            item.uom_name=itemID[0].uom_name;
            item.price=itemID[0].price;
            item.resale_price = itemID[0].resale_price;
        }

        function getProductList(){
            productAPI.getListItemOption().then(function(res){
                $scope.productList = res.data.results;
            })
        }
        function getListSaleOrder(){
            deliveryOrderAPI.getListOrderDelivery().then(function(res){
                $scope.listSaleOrder = res.data.results;
                if($scope.mainData.generalInfo.order_id){
                    changeSaleOrder($scope.mainData.generalInfo.order_id);
                }                
            })
        }  
        function getPickupLocation(){
            deliveryOrderAPI.getWarehouseOption().then(function(res){
                $scope.listPickupLocation = res.data.results;
            })
        } 
        function changeSaleOrder(id){
            if($scope.listSaleOrder.length>0){
                var itemID = $scope.listSaleOrder.filter(function(order){
                    if(order.id == id)
                        return order;
                });
                console.log(itemID);
                // $scope.mainData.generalInfo.buyer_name = itemID[0].buyer_name;
                // $scope.mainData.generalInfo.buyer_id = itemID[0].buyer_id;
                $scope.listDelivery = itemID[0].shipping_address;
            }   
            $scope.cancelDeliveryOrder= function(){
                $state.go("app.orders.delivery-order.list");
            }  
            }
           
    }
})();
