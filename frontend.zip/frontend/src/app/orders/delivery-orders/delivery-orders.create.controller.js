(function () {
    'use strict';
    angular
        .module('app')
        .controller('delivery-orders.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,  productAPI,deliveryOrderAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.changeSaleOrder =changeSaleOrder;
        $scope.mainData = {
            generalInfo: {},
            products: []
        };
        $scope.listStatus = [
            {
                id: '0',
                name: "In-Active"
            }, {
                id: '1',
                name: "Active "
            }
        ];
        $scope.listPickupTime = [
            {
                id: '8-17',
                name: "8-17"
            }
        ];
        $scope.listDeliveryType=[
            {id:2,name:'Home Delivery'},
            {id:3,name:'Courier Delivery'},
            {id:1,name:' Customer Pickup'}            
        ];
        $scope.productList = [];   
        $scope.changePickuplocation =changePickuplocation;
        
        (function onInit() {
            getDocNum();
            getListSaleOrder();
            getPickupLocation();
        })();
        $scope.clickAdd = function () {

            $scope
                .mainData
                .products
                .push({});
        };
        $scope.remove = function (index) {
            $scope
                .mainData
                .products
                .splice(index, 1);
                // $scope.changeQTY();
        };
        $scope.cancelDeliveryOrder= function(){
            $state.go("app.orders.delivery-order.list");
        }
        $scope.createDeliveryOrder = function(){
            console.log($scope.mainData);
            var params = $scope.mainData.generalInfo;
            params.delivery_order_detail = $scope.mainData.products;
            console.log(params);
            deliveryOrderAPI.createDeliveryOrder(params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.delivery-order.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        function changeSaleOrder(id){   
            console.log(id);         
            var itemID=$scope.listSaleOrder.filter(function(order){
                if(order.id == id)
                    return order;
            });
            $scope.mainData.generalInfo.buyer_name = itemID[0].buyer_name;
            $scope.mainData.generalInfo.buyer_id = itemID[0].buyer_id;
            $scope.listDelivery = itemID[0].shipping_address;
        }
        function changePickuplocation(pickup_location){
            console.log(pickup_location);
            var itemID= $scope.listPickupLocation.filter(function(warehouse){
                if(warehouse.id == pickup_location)
                    return warehouse;
            });
            $scope.mainData.generalInfo.full_address = itemID[0].full_address;
            $scope.mainData.generalInfo.contact_name = itemID[0].contact_name;
            $scope.mainData.generalInfo.contact_phone = itemID[0].contact_phone;            
        }
        $scope.getListProduct= function(order_id,addr_id){
            var itemID= $scope.listDelivery.filter(function(address){
                if(address.address_id == addr_id)
                    return address;
            });
            $scope.mainData.generalInfo.delivey_address = itemID[0].full_address;
            var params ={
                "order_id":order_id,
                "address_id":addr_id,
            }
            deliveryOrderAPI.getProductByOrderAndAddr(params).then(function(res){
                $scope.mainData.products = res.data.results;
            })
        }

        function getDocNum(){
            deliveryOrderAPI.getDeliveryCode().then(function(res){
                $scope.mainData.generalInfo.code = res.data.results.code
            })
        }
        function getListSaleOrder(){
            deliveryOrderAPI.getListOrderDelivery().then(function(res){
                $scope.listSaleOrder = res.data.results;
                console.log($scope.listSaleOrder);
            })
        }  
        function getPickupLocation(){
            deliveryOrderAPI.getWarehouseOption().then(function(res){
                $scope.listPickupLocation = res.data.results;
            })
        }      

    }
})();
