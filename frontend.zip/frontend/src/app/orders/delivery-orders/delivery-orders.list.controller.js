(function() {
    'use strict';

    angular
        .module('app')
        .controller('delivery-orders.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, API, deliveryOrderAPI, $localStorage, MessageService, hotkeys, $state,$timeout) {

        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.getList = getList;
        $scope.KeyShorcut = KeyShorcut;
        $scope.updateSalePrice =updateSalePrice;
        //  $scope.scrollToFilter =scrollToFilter;
        $scope.filter = filter;
        $scope.list = {
            items: [],
            search: {}
        };
        $scope.listStatus = [{
            id: '1',
            name: "NEW"
        }, {
            id: '2',
            name: "READY TO SHIP"
        },
         {
            id: '3',
            name: "IN TRANSIT"
        }, {
            id: '4',
            name: "DELIVERED"
        }];

        /** Internal functions */

        (function onInit() {
            getList();
        })();
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            item.is_checked = !item.is_checked;
            $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
            $scope.selectedIndex = index;
        }
        $scope.createDeliveryOrder = function() {
            $state.go("app.orders.delivery-order.create");
        }
        $scope.editDeliveryOrder = function(id){
            $state.go("app.orders.delivery-order.view",{id: id});
        }

        function getList() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            deliveryOrderAPI
                .getList(params)
                .then(function(res) {

                    try {
                        $scope.list.items = res.data.results.rows;
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }
         function updateSalePrice(item){
            console.log($scope.mainData);
            var params = item;
            // params.products = $scope.mainData.products;
            deliveryOrderAPI.updateSalePrice(item.id,params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.sale-price.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }



        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+n',
                description: 'Create New Sales order',
                callback: function(e) {
                    $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'enter',
                description: 'Go to  detail Sales order',
                callback: function(e) {
                    if ($scope.selectedIndex > -1) {
                        $scope.item_detail = $scope.list.items[$scope.selectedIndex].id;
                        $state.go('app.orders.sale-order.detail', { id: $scope.item_detail })
                    }

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+s',
                description: 'Search',
                callback: function() {
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+r',
                description: 'Reset Search',
                callback: function() {
                    $scope.list.search = {};
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pagedown',
                description: 'Move to next page',
                callback: function(e) {
                    $scope.pagination.page++;
                    if ($scope.pagination.page > $scope.pagination.total_page) {
                        $scope.pagination.page = $scope.pagination.total_page;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pageup',
                description: 'Move to previous page',
                callback: function(e) {
                    $scope.pagination.page--;
                    if ($scope.pagination.page < 1) {
                        $scope.pagination.page = 1;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+end',
                description: 'Move to last page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = $scope.pagination.total_page;
                    $scope.changePage();

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+home',
                description: 'Move to first page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = 1;
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            // .add({
            //     combo: 'alt+shift+a',
            //     description: 'Filter Search',
            //     callback: function(e) {
            //         e.preventDefault();
            //         $scope.pagination.page = 1;
            //         $scope.scrollToFilter()
            //     },
            //     allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            // })

        function scrollToTable() {
            try {
                var top = document.getElementsByClassName("custom-table")[0].offsetTop - 100;
                $('html, body').animate({
                    scrollTop: top
                }, 500);
            } catch (e) {
                console.log(e)
            }
        }
        // function scrollToFilter() {
        //     $scope.focusAuto = "true";
        //     try {
        //         var top = document.getElementsByClassName("anchor-scroll")[0].offsetTop;
        //         $('html, body').animate({
        //             scrollTop: top
        //         }, 500);
        //     } catch (e) {
        //         console.log(e)
        //     }
        // }

        function filter(type) {
            $scope.list.search.sts = type;

            return $scope.searchAction($scope.list.search);
        }
        $scope.dateOptions = {}
        $scope.upDateDateOption = function(key, min, max){
            $scope.dateOptions[key] = {
                showWeeks: false,
            }
            if(min) {
                $scope.dateOptions[key].minDate  = min;
            }
            if(max) {
                $scope.dateOptions[key].maxDate  = max;
            }
        };
        $scope.updateStatus= function(id){
            deliveryOrderAPI.updateStatus(id).then(function(res){
                if(res.data._type=='success'){
                    toastr.success(res.data.message);
                    $timeout(function() {
                        getList();
                    }, 500);
                }else{
                    toastr.success(res.data.message);
                }
            })
        }

    }
})();
