(function () {

    'use strict';

    angular.module('app').service('deliveryOrderAPI', service);


    function service(API) {

        this.createDeliveryOrder = createDeliveryOrder;
        this.getList = getList;
        this.getDetailDeliveryOrder = getDetailDeliveryOrder;
        this.updateSalePrice = updateSalePrice;
        this.getDeliveryCode =getDeliveryCode;
        this.getProductByOrderAndAddr =getProductByOrderAndAddr;
        this.getListOrderDelivery = getListOrderDelivery;
        this.getWarehouseOption =getWarehouseOption;
        this.updateStatus =updateStatus;
        this.updateDeliveryStatus =updateDeliveryStatus;
        
       
        /** Internal functions */    

        function getList(params) {
           var url='delivery-order/index';
            return API.get(url,params);
        }       
        function createDeliveryOrder(params) {
            var url ='delivery-order/create';
            return API.post(url, params);
        }
        function getDetailDeliveryOrder(id) {
            var url ='delivery-order/detail/'+id;
            return API.get(url);
        }
        function updateSalePrice(id,params){
            var url ='sale-price/'+id;
            return API.put(url, params);
        }
        function updateDeliveryStatus(id,params){
            var url ='delivery-order/update-manual/'+id;
            return API.post(url, params);
        }
        function getProductByOrderAndAddr(params){
            var url ='order/list-item-order';
            return API.get(url,params);
        }
        function getListOrderDelivery(){
            var url ='order/list-order-delivery';
            return API.get(url);
        }
        function getDeliveryCode(){
            var url ='delivery-order/get-delivery-order-code';
            return API.get(url);
        }
        function getWarehouseOption(){
            var url='warehouse/get-all';
            return API.get(url);
        }
        function updateStatus(id){
            var url ='delivery-order/update/'+id;
            return API.post(url);
        }
        
    }
})();
