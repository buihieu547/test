(function () {

    'use strict';

    angular.module('app').service('rmaAPI', service);


    function service(API) {

        this.getAllSts = getAllSts;
        this.getListOrders = getListOrders;
        this.getOrderById = getOrderById;
        this.createRMA = createRMA;
        this.getRMAInfo = getRMAInfo;
        /** Internal functions */

        function getAllSts(params) {
            var url = ['reports', 'get-all-orders-status'].join('/');
            return API.get(url, params);
        }

        function getRMAInfo() {
            var url = ['rma', 'generate'].join('/');
            return API.get(url);
        }

        function getListOrders() {
            var url = ['reference', 'order'].join('/');
            return API.get(url);
        }
        function getOrderById(id) {
            var url = ['reference', 'order', id, 'items'].join('/');
            return API.get(url);
        }
        function createRMA(params) {
            var url = ['rma', 'create-rma'].join('/');
            return API.post(url, params);
        }
    }
})();
