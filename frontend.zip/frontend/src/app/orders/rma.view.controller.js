(function() {
    'use strict';
    angular
        .module('app')
        .controller('rma.view.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, rmaAPI, $state, API,hotkeys) {
        //Define variable
        $scope.mainData = { };
        $scope.selectionData = {};
        $scope.KeyShorcut=KeyShorcut;
        (function onInit() {
          initVar();
          getRMADetail();
        })();
        function initVar() {
            $scope.selectionData["RMAType"] = [{ id: 0, name: 'Exchange' }, { id: 1, name: 'Credit' }, { id: 2, name: 'Refund' }, { id: 3, name: 'Re-certification' }];
            $scope.selectionData["ReturnLoc"]= [{id:1,name:'NAB Location'},{id:2,name:'Customer Location'}];           
            
        }
        function getRMADetail() {
            var id = $stateParams.id;
            if(id)
            {
                API.get('rma/rma-detail/'+id).success(function (res) {
                  if (res) {
                      $scope.mainData = res.results;                      
                  }

                });
            }
        }
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
         }
 
       hotkeys.bindTo($scope)
         





    }
})();
