(function() {
    'use strict';

    angular
        .module('app')
        .controller('orders.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, API, orderAPI, $localStorage, MessageService, hotkeys, $state, $timeout) {

        var $listController = $controller('abstract.list.controller', { $scope: $scope });

        $scope.getList = getList;
        $scope.KeyShorcut = KeyShorcut;
        $scope.putApproveOrder =putApproveOrder;
        $scope.resetAction = resetAction;
        $scope.filter = filter;
        $scope.list = {
            items: [],
            search: {}
        };
        $scope.listOrderType = [{
            id: 'PKU',
            name: "Pickup "
        }, {
            id: 'CE',
            name: "Call"
        }, {
            id: 'ONL',
            name: "Ecommerce"
        },
        {
            id: 'NO',
            name: "Normal Order"
        }];
        $scope.onoffFilter = false;
        $scope.listMoreFilter = [{value:false,name:'Date Type'}];
        $scope.listSearchDate =[{id:'OD',name:'Order Date'},{id:'DL',name:'Delivery Date'}];

        /** Internal functions */

        (function onInit() {
            countOrderStatus();
            getList();
            getListStatus();
        })();
        function resetAction() {
            $timeout(function() {
                angular.element(".multiple-select2").trigger("change");
            }, 1000);
            $scope.list.search = {};
            $scope.searchAction($scope.list.search );
        }
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            item.is_checked = !item.is_checked;
            $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
            $scope.selectedIndex = index;
        }
        $scope.showMorefilter = function(){
            $scope.onoffFilter = !$scope.onoffFilter;
        }
        $scope.cloneOrder = function(order_id){
            orderAPI.cloneOrder(order_id).then(function(res){
                if(res.data._type=='success'){
                    toastr.success(res.data.message);
                    $timeout(function(){
                        getList();
                    },500);
                }else{
                    toastr.error(res.data.message);
                }
            })
        }


        $scope.createOrder = function() {
            $state.go("app.orders.sale-order.create", { items: [] })
        }
        function countOrderStatus(){
            orderAPI.countOrderStatus().then(function(res){
                $scope.countStatus = res.data.results[0];
            })
        }
        function getList() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            params.order='id';
            params.sort ='desc';
            API
                .get('order/list-order', params)
                .then(function(res) {

                    try {
                        $scope.list.items = res.data.results.rows;
                        $listController.matchPagingOption(res.data.results);
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function getListStatus() {
            API
                .get('order/list-status')
                .then(function(res) {
                    try {
                        $scope.listStatus = res.data.results;
                    } catch (e) {
                        console.log(e);
                    }
                })
        }
        function putApproveOrder(order_id){
            orderAPI.approveOrd(order_id).then(function(res){
                if(res.data._type=='success'){
                    toastr.success(res.data.message);
                    $timeout(function() {
                        getList();
                    }, 500);
                }else{
                    toastr.success(res.data.message);
                }
            })
        }
        $scope.checkItem = function(item) {
            console.log(item)
            $scope.item_detail = item.id;
        }

        function updateStatus(orderNum) {
            var params = {
                orderNum: orderNum
            };
            API
                .put('order/update-status', params)
                .then(function(res) {
                    try {
                        getList();
                    } catch (e) {
                        console.log(e);
                    }
                });
        }

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+n',
                description: 'Create New Sales order',
                callback: function(e) {
                    $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'enter',
                description: 'Go to  detail Sales order',
                callback: function(e) {
                    if ($scope.selectedIndex > -1) {
                        $scope.item_detail = $scope.list.items[$scope.selectedIndex].id;
                        $state.go('app.sale-order.orders.detail', { id: $scope.item_detail })
                    }

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+s',
                description: 'Search',
                callback: function() {
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+r',
                description: 'Reset Search',
                callback: function() {
                    $scope.list.search = {};
                    $scope.searchAction($scope.list.search)
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pagedown',
                description: 'Move to next page',
                callback: function(e) {
                    $scope.pagination.page++;
                    if ($scope.pagination.page > $scope.pagination.total_page) {
                        $scope.pagination.page = $scope.pagination.total_page;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+pageup',
                description: 'Move to previous page',
                callback: function(e) {
                    $scope.pagination.page--;
                    if ($scope.pagination.page < 1) {
                        $scope.pagination.page = 1;
                        return;
                    }
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+end',
                description: 'Move to last page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = $scope.pagination.total_page;
                    $scope.changePage();

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+home',
                description: 'Move to first page',
                callback: function(e) {
                    e.preventDefault();
                    $scope.pagination.page = 1;
                    $scope.changePage();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            // .add({
            //     combo: 'alt+shift+a',
            //     description: 'Filter Search',
            //     callback: function(e) {
            //         e.preventDefault();
            //         $scope.pagination.page = 1;
            //         $scope.scrollToFilter()
            //     },
            //     allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            // })

        function scrollToTable() {
            try {
                var top = document.getElementsByClassName("custom-table")[0].offsetTop - 100;
                $('html, body').animate({
                    scrollTop: top
                }, 500);
            } catch (e) {
                console.log(e)
            }
        }
        // function scrollToFilter() {
        //     $scope.focusAuto = "true";
        //     try {
        //         var top = document.getElementsByClassName("anchor-scroll")[0].offsetTop;
        //         $('html, body').animate({
        //             scrollTop: top
        //         }, 500);
        //     } catch (e) {
        //         console.log(e)
        //     }
        // }

        function filter(type) {
            $scope.list.search.sts = type;

            return $scope.searchAction($scope.list.search);
        }
        // $scope.list.search.date_to = new Date();
        // $scope.list.search.date_from = new Date();
        // $scope.date_to_option={
        //     showWeeks: false,
        //     maxDate:$scope.list.search.date_from
        // }
        // console.log($scope.date_to_option);
        // $scope.date_from_option={
        //     showWeeks: false,
        //     minDate:$scope.list.search.date_to
        // }
        // console.log($scope.date_from_option);
        $scope.dateOptions = {}
        $scope.upDateDateOption = function(key, min, max){
            $scope.dateOptions[key] = {
                showWeeks: false,
            }
            if(min) {
                $scope.dateOptions[key].minDate  = min;
            }
            if(max) {
                $scope.dateOptions[key].maxDate  = max;
            }
        };

    }
})();
