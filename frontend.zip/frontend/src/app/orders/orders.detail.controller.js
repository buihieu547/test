(function () {
    'use strict';

    angular.module('app').controller('orders.detail.controller',controller);

    /** @ngInject */
    function controller($scope, $stateParams, API,$uibModal,orderAPI,$localStorage,$sce,hotkeys,$timeout) {   

        $scope.detail = {
            information : [],
            history : []
        };
         $scope.addNewEmail = addNewEmail;
         $scope.getSrcIframe = getSrcIframe;
         $scope.printInvoice = printInvoice;
         $scope.printOrder = printOrder;
         $scope.KeyShorcut =KeyShorcut;
        //  $scope.getHistoryByOrder =getHistoryByOrder;
        //  $scope.getInvoice =getInvoice;
         $scope.showDetail =showDetail;

        (function onInit() {
            getDetail();
            // $scope.getInvoice($stateParams.id);
        })();

        /** Internal functions */
        function getDetail() {
            var id = $stateParams.id;
            if(id)
            {
                var url = ['order','order-detail',id].join('/');
                API.get(url).success(function (res) {                   
                    $scope.detail.information = res.results.order_detail;                   
                     $scope.detail.billing = res.results.billing_info[0];                   
                    $scope.detail.general =  res.results;
                    $scope.detail.subs = res.results.subs;                   
                    $scope.detail.buyer_info =  res.results.buyer_info;
                    // $scope.getHistoryByOrder(res.results.code);

                    $scope.linkIframe = $scope.getSrcIframe($scope.detail.general.code);
                });

                // API.get(['reports','get-orders-history'].join('/'),{order_id : id}).success(function (res) {                   
                //     $scope.detail.history = res.results.rows;
                // });
            }
        };
        function addNewEmail(){           
            $uibModal.open({
                animation: true,
                templateUrl: 'app/orders/send_email.html',
                controller: ['$uibModalInstance', '$scope', 'orderAPI',
                    function ($uibModalInstance, modalScope, orderAPI) {	
                        modalScope.list={
                            to:'',
                            subject:$scope.detail.general.code,
                            message:'Dear '+$scope.detail.general.buyer_infor.information.company_name+',\n\nThank you for your order.\nYou will be notified once the order has been shipped.\nIf you have any question, feel free to contact us at '+$localStorage.USER_DATA.email+'.\n\nThank you.'
                        }               
                        modalScope.cancel = function () {
                            $uibModalInstance.close();
                        }; 
                        modalScope.ok = function () {
                            $uibModalInstance.close(modalScope.list);
                        };                        

                    }],
                size: 'modal-md'
            }).result.then(function (res) {                
                if(typeof(res) != 'undefined'){
                   orderAPI.sendEmail(res).then(function(res){
                        if (res.data._type === "success") {
                            var msg ='Email is sent successfully!'
                                toastr.success();
                            }

                   },function(error){
                    console.log(errors)
                   }
                )
                }
               

            });

        }
        function getHistoryByOrder(code){
            orderAPI.getHistoryByCode(code).then(function(res){                
                $scope.history = res.data.results.rows;
            })
        }
        function getInvoice(order_id){
            orderAPI.getInvoice(order_id).then(function(res){
               $scope.invList = res.data.results.rows;
               console.log($scope.invList)
            })
        }
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }
        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+shift+o',
                description: 'Print Sales Order',
                callback: function (e) {
                    $scope.printOrder();
                }
            })
            .add({
                combo: 'alt+shift+i',
                description: 'Print Invoice',
                callback: function (e) {
                  $scope.printInvoice();

                }
            })  
            .add({
                combo: 'alt+shift+e',
                description: 'Send Email',
                callback: function (e) {                  

                }
            }) 
            .add({
                combo: 'ctrl+1',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Infomation',
                callback: function(e) {
                    e.preventDefault();                   
                    activateTab("information");
                }
            })
           
            .add({
                combo: 'ctrl+2',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                description: 'Document',
                callback: function(e) {
                    e.preventDefault();                    
                    activateTab("document");
                }
            })   
            
            function activateTab(tab) {
                $timeout(function() {
                    jQuery('#' + tab+'Tab').trigger('click');
                })
            };           

	    function printOrder() {		   
		    var innerContents = document.getElementById('printOrder').innerHTML;
		    var popupWinindow = window.open('', '_blank', 'width=860,height=600,fullscreen=yes,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
		    popupWinindow.document.open();
		    popupWinindow.document.write('' +
			    '<html>' +
			    '<head>' +
			    '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700"/>' +
			    '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">' +
			    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>' +
			    '<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>' +
                '<style type="text/css">' +
                    'body{-webkit-print-color-adjust: exact; overflow: scroll; font-size: 9px;}' +
                    '@media print{body{font-size: 9px;} thead {display: table-header-group;}}' +
                    '@media print {table >tr.vendorListHeading {background-color:#cccccc !important; -webkit-print-color-adjust: exact; font-weight:normal; border-top:1px solid grey}}'+
                    '@media print { th{background-color:#cccccc !important; height: 30px; padding: 5px; font-size: 9px;}}' +
				    '@media print {' +
			            'table {tbody>tr>td {padding: 5px;}} ' +
			            '.pagebreak { page-break-before: always; }' +
			        '}' +
				    '.row {margin: 0;} .txt-title {color: #646464; font-weight: bold;}' +
                    'table{margin-bottom:15px; }'+
			        'table>tr.vendorListHeading>td { font-weight: normal; padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +
			        'table>tr>td {padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +                    
                    '.mrg-top {margin-top: 20px;} .mrg-none {margin: 0;}' +
			        '.float-l {float: left; width: 50%;} ' +
			        '.float-r {float: right; width: 50%;} ' +
			        '.float-l3 {float: left; width: 33%;} .float-r3 {float: right; width: 33%;} ' +
			        '.float-lcol-2 {float: left; min-width: 100px;} .float-rcol-2 {float: right; min-width: 100px;} ' +
			        '.float-l100 {float: left; width: 100%;} .float-r100 {float: right; width: 100%}' +
			        '.padding-none {padding: 0;} ' +
			        '.padding-t {padding-top: 3%}' +
                    'thead {background-color: #dddddd; } .bg-gray {background-color: #dddddd;}' +
                    'thead >tr{border-bottom:grey} ' +
			        'table>tbody>tr>td {padding: 5px; font-size: 9px;}'+
                    '#table-total>tr>td{ padding:10px;}'+
                    '#table-total>tr>td>span{font-weight:600 }'+
                    '#table-total>tr.remove-boder>td{border-left:none;border-right:none}'+
                     'table.table-footer>thead>tr>th{padding:5px;border:none}'+
                    'table.table-footer>tbody>tr>td{padding:5px;border:none}'+
                    '#footer p{margin-bottom:5px;}'+
                '</style>' +
                    '<title>'+ $scope.detail.general.code+'</title>'+
			    '</head>' +
			    '<body onload="window.print()">' + innerContents + '</html>');
		    popupWinindow.document.close();
        };
        function printInvoice() {		   
		    var innerContents = document.getElementById('printInvoice').innerHTML;
		    var popupWinindow = window.open('', '_blank', 'width=860,height=600,fullscreen=yes,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
		    popupWinindow.document.open();
		    popupWinindow.document.write('' +
			    '<html>' +
			    '<head>' +
			    '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700"/>' +
			    '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">' +
			    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>' +
			    '<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>' +
                '<style type="text/css">' +
                    'body{-webkit-print-color-adjust: exact; overflow: scroll; font-size: 9px;}' +
                    '@media print{body{font-size: 9px;} thead {display: table-header-group;}}' +
                    '@media print {table >tr.vendorListHeading {background-color:#cccccc !important; -webkit-print-color-adjust: exact; font-weight:normal; border-top:1px solid grey}}'+
                    '@media print { th{background-color:#cccccc !important; height: 30px; padding: 5px; font-size: 9px;}}' +
				    '@media print {' +
			            'table {tbody>tr>td {padding: 5px;}} ' +
			            '.pagebreak { page-break-before: always; }' +
			        '}' +
				    '.row {margin: 0;} .txt-title {color: #646464; font-weight: bold;}' +
                    'table{margin-bottom:15px; }'+
			        'table>tr.vendorListHeading>td { font-weight: normal; padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +
			        'table>tr>td {padding:10px; font-size:13px;line-height: 1.42857143;vertical-align: top;} ' +                    
                    '.mrg-top {margin-top: 20px;} .mrg-none {margin: 0;}' +
			        '.float-l {float: left; width: 50%;} ' +
			        '.float-r {float: right; width: 50%;} ' +
			        '.float-l3 {float: left; width: 33%;} .float-r3 {float: right; width: 33%;} ' +
			        '.float-lcol-2 {float: left; min-width: 100px;} .float-rcol-2 {float: right; min-width: 100px;} ' +
			        '.float-l100 {float: left; width: 100%;} .float-r100 {float: right; width: 100%}' +
			        '.padding-none {padding: 0;} ' +
			        '.padding-t {padding-top: 3%}' +
                    'thead {background-color: #dddddd; } .bg-gray {background-color: #dddddd;}' +
                    'thead >tr{border-bottom:grey} ' +
			        'table>tbody>tr>td {padding: 5px; font-size: 9px;}'+
                    '#table-total>tr>td{ padding:10px;}'+
                    '#table-total>tr>td>span{font-weight:600 }'+
                    '#table-total>tr.remove-boder>td{border-left:none;border-right:none}'+
                     'table.table-footer>thead>tr>th{padding:5px;border:none}'+
                    'table.table-footer>tbody>tr>td{padding:5px;border:none}'+
                    '#footer p{margin-bottom:5px;}'+
                '</style>' +
                    '<title>'+ $scope.detail.general.invoice_num+'</title>'+
			    '</head>' +
			    '<body onload="window.print()">' + innerContents + '</html>');
		    popupWinindow.document.close();
        };
        function getSrcIframe(order_num){
            var url = 'http://wms360.nabp-demo.seldatdirect.com/fe-upload/?transaction='+order_num;
            return $sce.trustAsResourceUrl(url);
        }
        function showDetail(objInv) {
            $uibModal.open({
                animation: true,
                templateUrl: 'app/orders/popup-invoice.html',
                controller: ['$uibModalInstance','$scope',
                    function($uibModalInstance, modalScope) {   
                        (function onInit() {                            
    
                        })();
                        modalScope.detail =objInv;
                        console.log(modalScope.detail);
                        modalScope.modalTitle = "INVOICE NO :"+modalScope.detail.general.invoice_num;    
                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        }; 
                        modalScope.ok = function() {
                            $uibModalInstance.close();
                            $scope.printInvoice();
                        };
    
                    }
                ],
                size: 'lg'
            }).result.then(function(res) {
                console.log(res);
              
               
            });
        }
    }

    

})();
