(function () {
    'use strict';

    angular.module('app').service('salequotationAPI', service);

    function service(API, $http) {

        this.getListItemById = getListItemById;
        this.createOrder = createOrder;
        this.updateOrder =updateOrder;
        this.getStatisticalOrder = getStatisticalOrder;
        this.approveOrd = approveOrd;
        this.cancelOrd = cancelOrd;
        this.sendEmail = sendEmail;
        this.getOrderNumber = getOrderNumber;
        this.generateSO= generateSO;
        this.getSalesQuotation =getSalesQuotation;
        this.getHistoryByCode =getHistoryByCode;
        this.getInvoice = getInvoice;
        this.previewOrder = previewOrder;
        this.updateSaleQuoteStatus =updateSaleQuoteStatus;
        this.sentMailToBuyer =sentMailToBuyer;
        this.getListSaleQuotationStatus =getListSaleQuotationStatus;
        this.getHistoryBySaleQuote =getHistoryBySaleQuote;

        /** Internal functions */
        function getListItemById(params) {
            var url = 'product/list-product-to-order';
            return API.get(url, params);
        }
        function createOrder(params) {
            var url = 'order/create-order';
            return API.post(url, params);
        }
        function updateOrder(id,params) {
            var url = 'order/update-order/'+id;
            return API.put(url, params);
        }
        function getOrderNumber(id){
             var url = ['order', 'generate-order-number',id].join('/');
            return API.get(url);
        }

        function getStatisticalOrder(params) {
            var url = 'order/statistical-order';
            return API.get(url, params);
        }

        function approveOrd(ordId) {
            var url = 'order/approved/' + ordId;
            return API.put(url);
        }

        function cancelOrd(ordId) {
            var url = 'order/cancel/' + ordId;
            return API.put(url);
        }
        function sendEmail(params){
            var url ='order/sent-message';
            return API.put(url, params);
        }
        function generateSO(){
            var url ='order/get-order-code';
            return API.get(url);
        }
        function getHistoryByCode(code){
            var url ="order/history?order_cd="+code;
            return API.get(url);
        }
        function getHistoryBySaleQuote(sale_id){
            var url ="order/sale-quote/history/"+sale_id;
            return API.get(url);
        }
        function getInvoice(id){
            var url ="order/invoice/"+id;
            return API.get(url);
        }
        function previewOrder(params) {
            var url = 'order/preview-order';
            return API.post(url, params);
        }
        function getSalesQuotation(){
            var url ='order/get-sale-quote-code';
            return API.get(url);
        }
        function updateSaleQuoteStatus(sale_quote_id,params) {
            var url = 'order/update-sale-quote-status/' + sale_quote_id;
            return API.put(url,params);
        }
        function sentMailToBuyer(sale_quote_id){
            var url='order/sale-quote/sent-to-buyer/'+sale_quote_id;
            return API.get(url);
        }
        function getListSaleQuotationStatus(){
            var url='order/sale-quote/list-status';
            return API.get(url);
        }
            
    }
})();
