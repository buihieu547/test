(function() {
    'use strict';
    angular
        .module('app')
        .controller('sales-quotation.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $controller, $uibModal, API, $stateParams, $timeout, salequotationAPI, $state, $localStorage, hotkeys) {
        var $listController = $controller('abstract.list.controller', { $scope: $scope });
        var $tableController = $controller('abstract.table.controller', { $scope: $scope });


        $scope.addNewItem = addNewItem;
        $scope.deleteAction = deleteAction;
        $scope.selectCompany = selectCompany;
        $scope.createOrder = createOrder;
        $scope.updateTotal = updateTotal;
        $scope.selectAddress = selectAddress;
        $scope.cancelOrder = cancelOrder;
        $scope.addNewBuyer = addNewBuyer;
        $scope.cloneRecord = cloneRecord;
        $scope.removeAddress = removeAddress;
        $scope.removeSubProduct = removeSubProduct;
        $scope.getListCompanySearch = getListCompanySearch;
        $scope.resetPaymentMethod = resetPaymentMethod;
        $scope.checkExistShippingAddress = checkExistShippingAddress;
        $scope.checkCloneRecord = checkCloneRecord;
        $scope.KeyShorcut = KeyShorcut;
        $scope.generateCode = generateCode;
        $scope.generateSaleQuote =  generateSaleQuote;
        $scope.calcPromotion = calcPromotion;
        $scope.getBuyerType = getBuyerType;
        $scope.checkListPromotion = checkListPromotion;
        $scope.resetPromo =resetPromo;

        $scope.isFirstRecord = isFirstRecord;

        $scope.getTotalAmount = getTotalAmount;

        $scope.order_info = {
            total: 0,
            sub_total: 0,
            order_date: '',
            customer_po: '',
            total_discount: 0,
            company_id: ''
        };
        $scope.order_info.selected_programs = [];
        $scope.list = {
            items: $stateParams.items || [],
            backItems: []
        };
        $scope.promotionList={};

        $scope.paytype = [{
                id: 'PKU',
                label: 'Pickup'
            }, {
                id: 'CE',
                label: 'Call'
            },
            {
                id: 'ONL',
                label: 'Ecommerce'
            }
        ]

        $scope.payment = {
            paymentMethod: [
                { id: 'AB', name: "Account Balance" },
                { id: 'BT', name: "Bank Transfer" },
                { id: 'CS', name: "Cash" },
                { id: 'CC', name: "Credit Card" }
            ],
            paymentTerm: [
                { id: 15, name: "15 days" },
                { id: 30, name: "30 days" }
            ]
        }

        // Date picker Config
        $scope.datePicker = {}
            /**
             * NAVIGATE TABLE
             */
        $scope.selectedIndex = -1;
        $scope.selectItem = function(item) {
            // item.is_checked = !item.is_checked;
            // $scope.checkItem(item);
        }
        $scope.onClickRow = function(index) {
            $scope.selectedIndex = index;
        }
        $scope.checkShipId = false;

        var ids = $stateParams.ids;

        (function onInit() {
            $localStorage.BRAND = $localStorage.BRAND || { id: 1 };
            var brand_id = $localStorage.BRAND.id;
            $scope.order_info.sale_executive_name = $localStorage.USER_DATA.full_name;
            $scope.focusMe = true;
            $scope.generateCode();
            $scope.generateSaleQuote();
            $scope.getBuyerType();
        })();

        /** Internal functions */

        function resetPaymentMethod() {
            $scope.order_info.payment_term = "";
            $scope.order_info.payment_due_date = ""
        }

        function checkExistShippingAddress() {
            try {
                for (var i in $scope.list.items) {
                    if (!$scope.list.items[i].shipping_address_id || ($scope.list.items[i].products && $scope.list.items[i].products.length > 0 && !$scope.list.items[i].products[0].shipping_address_id)) {
                        return false;
                    }
                }
                return $scope.list.items.length;
            } catch (e) { console.log(e) }
        }

        function isFirstRecord(list) {

            var _list = list || $scope.list.items || $scope.list.backItems;

            var length = _list.length;
            var check = [];

            for (var i = 0; i < length; i++) {
                var item = _list[i];
                delete item.isFirst;
                if (check.indexOf(item.product_detail_id) === -1) {
                    check.push(item.product_detail_id);
                    item.isFirst = true;
                }
            }
        }

        function getTotalAmount(product, list) {
            var idProduct = product.product_detail_id;

            var total = 0;

            angular.forEach(list, function(item) {
                if (item.product_detail_id === idProduct) {
                    total = total + (item.order_quantity * item.resale_price - (item.order_quantity * item.resale_price) * item.discount / 100);

                }
            });
            total = parseFloat(total).toFixed(2);

            return angular.copy(total);
        }

        function addNewBuyer() {
            $rootScope.fromCreateOrder = true;
            $rootScope.listIds = ids;
            $state.go('app.buyers.create', {
                redirect: $state.current.name,
                ids: $stateParams.ids
            });
        }

        function cancelOrder() {
            $state.go("app.orders.sales-quotation.list");
        }

        function getBuyerType() {
            API.get('company_type/all').then(function(res) {
              try {
                    $scope.buyerType = res.data.results;
              } catch (e) {
                console.log(e);
              }
            })
        }

        function selectAddress(id, type) {
            try {
                switch (type) {
                    case 'shipping':
                        $scope.ship = findDataById(id, $scope.order.address.shipping);
                        break;
                    case 'billing':
                        $scope.bill = findDataById(id, $scope.order.address.billing);
                        break;
                }
            } catch (e) {
                console.log(e);
            }
        }

        function generateCode() {
            salequotationAPI.generateSO().then(function(res) {
                $scope.order_info.order_number = res.data.results.code;
            })
        }
        function generateSaleQuote(){
            salequotationAPI.getSalesQuotation().then(function(res){
                $scope.order_info.sale_quote_num = res.data.results.code;
            })
        }

        function findDataById(id, arr) {
            var result;
            if (angular.isArray(arr)) {
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i].id == id) {
                        result = arr[i];
                        break;
                    }
                }
            }
            return result;
        }

        function createOrder() {

            var products = [];
            $scope.list.items.forEach(function(item) {
                products.push({
                    item_id: item.item_id,
                    quantity: item.order_quantity,
                    price: item.sell_price,
                    discount_percent: item.discount,
                    shipping_address_id: item.shipping_address_id,
                    warehouse_id: item.warehouse_id || 1
                });

                if (item.products.length > 0) {
                    angular.forEach(item.products, function(subItem, index) {
                        products.push({
                            item_id: subItem.item_id,
                            quantity: subItem.order_quantity,
                            price: subItem.sell_price,
                            discount_percent: subItem.discount,
                            shipping_address_id: subItem.shipping_address_id,
                            warehouse_id: subItem.warehouse_id || 1
                        });
                    });
                }
            });

            var params = {
                "brand_id": $localStorage.BRAND.id,
                "customer_po": $scope.order_info.customer_po,
                "order_number": $scope.order_info.order_number,
                "order_date": $scope.order_info.order_date,
                "delivery_date": $scope.order_info.delivery_date,
                "type": 'SAQ',
                "rfq_id":$scope.order_info.rfq_id,
                "ref_num":$scope.order_info.ref_num,
                "quote_date":$scope.order_info.quote_date,
                "expiry_date":$scope.order_info.expiry_date,
                "rep_comment":$scope.order_info.rep_comment,
                "company_id": $scope.order.information.company_id,
                "buyer_type": $scope.order_info.buyer_type,
                "shipping_cost": $scope.order_info.shipping_cost,
                "vat_percent": $scope.order_info.vat_percent,
                "discount_percent": $scope.order_info.discount_percent,
                "description": $scope.order_info.description,
                "approval_num": $scope.order_info.approval_num,
                "shipping_id": $scope.shipping,
                "billing_id": $scope.billing,
                "payment_method": $scope.order_info.payment_method,
                "payment_term": $scope.order_info.payment_term,
                "payment_due_date": $scope.order_info.payment_due_date,
                "selected_programs" :$scope.order_info.selected_programs,
                "items":$scope.list.items
            };

            salequotationAPI
                .createOrder(params)
                .then(function(res) {
                    try {
                        if (res.data.results.status === true) {
                            toastr.success(res.data.results.message);
                            $timeout(function() {
                                $state.go("app.orders.sales-quotation.list");
                            }, 1000)

                        } else {
                            toastr.error(res.data.results.message);
                        }
                    } catch (e) {
                        console.log(e);
                    }
                });

        }

        function selectCompany(id) {
            if (id) {
                API
                    .get(['company/information-of-company', id].join('/'))
                    .then(function(res) {
                        try {
                            $scope.order = res.data.results;
                            if ($scope.list.items.length > 0) {
                                for (var i = 0; i < $scope.list.items.length; i++) {
                                    $scope.list.items[i]['shipping_address_id'] =
                                        $scope.order.address.shipping[0].id;

                                }
                            }
                        } catch (e) {
                            console.log(e);
                        }
                    })
            }
        }

        function getListCompanySearch(type_buyer) {
            $scope.listCompanySearch = [];
            $("#search_type").select2("val", "");
            $scope.search = undefined;
            $scope.order = { address: { billing: [] } };
            API
                .get('company/list-option-company?buyer_type=' + type_buyer)
                .then(function(res) {
                    try {
                        $scope.listCompanySearch = res.data.results.rows;
                        // $scope.listCompanySearch.sort(function(a, b) {
                        //     var nameA = a.name.toLowerCase();
                        //     var nameB = b.name.toLowerCase();
                        //     if (nameA < nameB) return -1;
                        //     if (nameA > nameB) return 1;
                        //     return 0;
                        // });
                    } catch (e) {
                        console.log(e);
                    }
                })
        }

        function getGeneratorOrderNumber(id) {
            salequotationAPI
                .getOrderNumber(id)
                .then(function(res) {
                    try {
                        $scope.order_info.order_number = res.data.results.order_number;
                    } catch (e) {
                        console.log(e);
                    }
                })
        }

        function deleteAction(id) {
            $scope.list.items = $scope.list.items.filter(function(item) {
                return item.item_id != id
            })
            $timeout(function() {
                updateTotal();
            }, 500);
        }
        function resetPromo(){
            $scope.promotionList =[];
            $scope.list.items.forEach(function(item) {
            item.promotion_discount_amount = 0;
            });
        }

        function updateTotal() {
            $scope.order_info.total = 0;
            $scope.order_info.sub_total = 0;
            if ($scope.list.items != undefined) {
                $scope.list.items.forEach(function(item) {
                    console.log(item);
                        var sub_quantity = 0;                        
                        item.discount_percent = item.discount_percent != undefined ? item.discount_percent:0;
                        angular.forEach(item.products, function(subItem, index) {
                            if (item.products.length > 0) { 
                                sub_quantity += Number(subItem.quantity);
                            }
                        });

                        var value = (Number(item.resale_price) * (Number(item.quantity) + sub_quantity) - (Number(item.resale_price) * (Number(item.quantity )+ sub_quantity)) * Number(item.discount_percent) / 100) - (item.promotion_discount_amount? item.promotion_discount_amount :0);

                        item.totalItem = value;

                        if (value) {
                            $scope.order_info.sub_total += value;
                        }
                    });

            }
            $scope.order_info.shipping_cost = ($scope.order_info.shipping_cost != undefined ? $scope.order_info.shipping_cost : 0);
            $scope.order_info.alt_vat_percent = ($scope.order_info.vat_percent != undefined ? $scope.order_info.vat_percent : 0);
            $scope.order_info.alt_discount_percent = ($scope.order_info.discount_percent != undefined ? $scope.order_info.discount_percent : 0);
            $scope.promotionList.total_invoice_discount =($scope.promotionList.total_invoice_discount ? $scope.promotionList.total_invoice_discount:0);

            $scope.order_info.total_discount = parseFloat(($scope.order_info.sub_total * Number($scope.order_info.alt_discount_percent) / 100).toFixed(2))
            $scope.order_info.vat_percent = parseFloat(($scope.order_info.sub_total * Number($scope.order_info.alt_vat_percent) / 100).toFixed(2));
            $scope.order_info.total = $scope.order_info.sub_total + Number($scope.order_info.shipping_cost) + $scope.order_info.vat_percent - $scope.order_info.total_discount -$scope.promotionList.total_invoice_discount ;
        }

        function cloneRecord(record, list) {
            var newRecord = angular.copy(record);
            var index = list.indexOf(record);
            var objIndex = list[index];

            objIndex.products.push(newRecord);
            $scope.list.items = list;

            $timeout(function() {
                isFirstRecord(list);
                updateTotal();
            }, 500);
        }

        function removeAddress(record, list) {
            var index = list.indexOf(record);
            list.splice(index, 1);

            $timeout(function() {
                isFirstRecord(list);
                updateTotal();
            });
        }

        function removeSubProduct(record, list, listall) {
            var index = list.indexOf(record);
            list.splice(index, 1);

            $timeout(function() {
                isFirstRecord(list);
                updateTotal();
            });
        }

        function checkCloneRecord(item, list) {
            // console.log(item);
            // console.log(list);
            try {
                var length = $scope.order.address.shipping.length;
                console.log(length)

                if (!item.hasOwnProperty('length')) {
                    item.length = function() {
                        return checkLengthRecord(item, list);
                    }
                }

                if (length) {
                    var countItem = 1;

                    if (list.products.length > 0) {
                        countItem += list.products.length;
                    }

                    return countItem < length;
                }
            } catch (e) {
                return false;
            }
        };

        function checkLengthRecord(id, list) {
            var total = 0;
            var _list = list || $scope.list.items;

            _list.forEach(function(record) {
                if (id === record.item_id) {
                    total++;
                }
            });

            return total;
        };
        function calcPromotion(company_id) {
            API.get('buyer/active-programs/' + company_id).then(function(res) {
              try {
                 checkListPromotion(res.data.results);
              } catch (e) {
                console.log(e);
              }
            })
        }

        function checkListPromotion(data) {
            $uibModal.open({
                animation: true,
                templateUrl: 'app/orders/list-promotion.html',
                controller: ['$uibModalInstance',
                    '$scope',
                    'salequotationAPI',
                    'hotkeys',
                    function($uibModalInstance, modalScope, salequotationAPI, hotkeys) {
                        modalScope.listPromotion = [];
                        modalScope.checkList = [];

                        modalScope.listPromotion = data;
                        modalScope.listPromotion.forEach(function(item) {
                            item.is_checked = false;
                        })


                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        };

                        modalScope.ok = function() {
                            modalScope.listPromotion.forEach(function(item) {
                                if(item.is_checked) {
                                    modalScope.checkList.push(item.id);
                                }
                            })
                            $uibModalInstance.close(modalScope.checkList);
                        };
                    } ],
                        size: 'lg'
                    }).result.then(function(res) {
                        if (angular.isArray(res) && res.length > 0) {
                            $scope.order_info.selected_programs = res;
                            console.log($scope.order_info);
                            console.log($scope.list);
                            var params = {};
                            params['company_id'] = $scope.order_info.company_id;
                            params['selected_programs'] = $scope.order_info.selected_programs;
                            params['items'] = $scope.list.items;
                            salequotationAPI.previewOrder(params).success(function(res) {
                                try {
                                console.log(res);
                                $scope.promotionList = res.results.promotion;

                                $scope.list.items = res.results.items;
                                } catch (e) {
                                    console.log(e.message);
                                }
                            });
                        }
                    });
        }

        function addNewItem(list, type_get) {
            $uibModal.open({
                animation: true,
                templateUrl: 'app/orders/add-new-item-order-modal.html',
                controller: ['$uibModalInstance',
                    '$scope',
                    'productAPI',
                    'promotionAPI',
                    'hotkeys',
                    function($uibModalInstance, modalScope, productAPI, promotionAPI, hotkeys) {
                        var $listController = $controller('abstract.list.controller', { $scope: modalScope });
                        var $tableController = $controller('abstract.table.controller', { $scope: modalScope });
                        modalScope.checkList = [];

                        modalScope.isCheckAllItem = false;
                        modalScope.isCheckAllBundle = false;
                        modalScope.listItem = {
                            items: [],
                            checklist: [],
                            search: {},
                            filter: {}
                        };
                        modalScope.listBundle = {
                            items: [],
                            checklist: [],
                            search: {},
                            filter: {}
                        };
                        modalScope.getList = getList;
                        // modalScope.resetAction = resetAction;
                        modalScope.checkAll = checkAll;
                        modalScope.checkItem = checkItem;
                        modalScope.onoffFilter =false;


                        modalScope.countRecord = 0;

                        modalScope.getListReference = getListReference;
                        modalScope.changeToGetSubModel = changeToGetSubModel;
                        modalScope.changeToGetSubCategory = changeToGetSubCategory;
                        modalScope.searchActionForList = searchActionForList;
                        modalScope.setFocus = setFocus;
                        modalScope.changePage = function(flag) {
                            if (!flag) {
                                getList('item');
                            } else {
                                getList(null, 'bundle');
                            }
                        }

                        /**
                         * KEY CONTROL
                         */


                        function KeyShorcut() {
                            hotkeys.toggleCheatSheet();
                        }

                        function activateTab(tab) {
                            $timeout(function() {
                                jQuery('#' + tab + 'Search').trigger('click');
                            })
                        };



                        function resetFocus() {
                            modalScope.focusVin = false;
                            modalScope.focusVehicle = false;
                            modalScope.focusPartNumber = false;
                            modalScope.focusFilter = false;
                        }

                        modalScope.currentSearch = {
                            value: null,
                            vin: 'focusVin',
                            vehicle: 'focusVehicle',
                            part: 'focusPartNumber'
                        }

                        function setFocus(focusMe) {
                            // modalScope.list.search = [];
                            // modalScope.list.checklist = [];

                            if (focusMe == 1) {
                                modalScope.focusVin = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.vin;
                            } else if (focusMe == 2) {
                                modalScope.focusVehicle = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.vehicle;
                            } else {
                                modalScope.focusPartNumber = true;
                                modalScope.currentSearch.value = modalScope.currentSearch.part;
                            }
                            // modalScope.resetAction();
                        }
                        /**
                         * SCROLL TO ELEMENT
                         */
                        function scrollToTable() {
                            $timeout(function() {
                                try {
                                    if (modalScope.listItem.items.length == 0) {
                                        modalScope[modalScope.currentSearch.value] = true;
                                        // resetAction(1);
                                        return;
                                    }
                                    if (modalScope.listBundle.items.length == 0) {
                                        modalScope[modalScope.currentSearch.value] = true;
                                        // resetAction(1);
                                        return;
                                    }
                                    var table = jQuery(".modal-dialog .custom-table")[0];
                                    var top = table.offsetTop - 100;
                                    resetFocus();
                                    $('.modal-open .modal').animate({
                                        scrollTop: top
                                    }, 500);
                                } catch (e) {
                                    console.log(e)
                                }
                            })
                        }
                        /**
                         * NAVIGATE TABLE
                         */
                        modalScope.selectedIndexItem = -1;
                        modalScope.selectedIndexBundle = -1;
                        modalScope.selectItem = function(item, _flag) {
                            console.log(_flag);
                            item.is_checked = !item.is_checked;
                            checkItem(item, _flag);
                        }
                        modalScope.onClickRowItem = function(index) {
                            modalScope.selectedIndexItem = index;
                        }
                        modalScope.onClickRowBundle = function(index) {
                            modalScope.selectedIndexBundle = index;
                        }
                        modalScope.showMorefilter = function(){
                            modalScope.onoffFilter = !modalScope.onoffFilter;
                        }


                        /**
                         * HANDLE SEARCH
                         */


                        modalScope.listMoreFilter = [{value:false,name:'Brand'},{value:false,name:'Country'},{value:false,name:'Region'}];
                        modalScope.listMaster = {
                            "brands": [],
                            "categories": [],
                            "countries": [],
                            "grape_varieties": [],
                            "state": []
                        };


                        // modalScope.searchType = [{ id: 1, name: "Vin" }, { id: 2, name: "Vehicle Model" }, { id: 3, name: "Part" }];


                        (function onInit() {
                            modalScope.getListReference();
                            modalScope.focusVin = true;
                            modalScope.getList('item','bundle');

                        })();

                        /** Internal functions */
                        function getList(flag1, flag2) {

                            if(flag1 == 'item') {
                                var params = $listController.getParams();
                                var filter = angular.copy(modalScope.listItem.filter);
                                Object.keys(filter).forEach(function(item) {
                                    if (angular.isArray(filter[item])) {
                                        filter[item] = filter[item].join(',');
                                    }
                                    return item;
                                })
                                params = Object.assign(params, modalScope.listItem.search, filter);

                                productAPI.getListOli(params).success(function(res) {
                                    try {
                                        modalScope.countRecord = res.results.total_items;
                                        modalScope.listItem.items = res.results.rows;
                                        modalScope.listItem.items.forEach(function(item) {
                                            item.is_checked = false;
                                        })
                                        $listController.matchPagingOption(res.results);
                                        scrollToTable();
                                    } catch (e) {
                                        console.log(e.message);
                                    }
                                });
                            }
                            if(flag2 == 'bundle') {
                                var params = $tableController.getParams();
                                var filter = angular.copy(modalScope.listBundle.filter);
                                Object.keys(filter).forEach(function(item) {
                                    if (angular.isArray(filter[item])) {
                                        filter[item] = filter[item].join(',');
                                    }
                                    return item;
                                })
                                params = Object.assign(params, modalScope.listBundle.search, filter);
                                promotionAPI.getBundleRef(params).success(function(res) {
                                    try {
                                        modalScope.countRecord = res.results.total_items;
                                        modalScope.listBundle.items = res.results.rows;
                                        modalScope.listBundle.items.forEach(function(item) {
                                            item.is_checked = false;
                                        })
                                        $timeout(function() {
                                            $tableController.matchPagingOption(res.results);
                                        }, 500);

                                    } catch (e) {
                                        console.log(e.message);
                                    }
                                });
                            }

                        }

                        function searchActionForList(flag1,flag2) {
                            modalScope.getList(flag1,flag2);
                        }





                        function getListReference() {
                            productAPI.getReferList().success(function(res) {
                                try {
                                    modalScope.listMaster['brands'] = res.results.brands;
                                    modalScope.listMaster['categories'] = res.results.categories
                                    modalScope.listMaster['countries'] = res.results.countries;
                                    modalScope.listMaster['grape_varieties'] = res.results.grape_varieties;
                                } catch (e) {
                                    console.log(e.message)
                                }
                            });

                        }

                        function changeToGetSubModel(id, arr) {
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i]['model_id'] == id) {
                                    return modalScope.listMaster['sub_models'] = arr[i]['sub_models'];
                                }
                            }

                        }

                        function changeToGetSubCategory(id, arr) {
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i]['category_id'] == id) {
                                    return modalScope.listMaster['sub_cat'] = arr[i]['sub_categories'];

                                }
                            }

                        }



                        modalScope.modalTitle = "SELECT ITEM";

                        modalScope.cancel = function() {
                            $uibModalInstance.close();
                        };



                        // function resetAction(flag) {
                        //     modalScope.pagination.page = 1;
                        //     if (flag) {
                        //         modalScope.list.filter = {};
                        //         modalScope.focusFilter = "reset";
                        //         return;
                        //     }
                        //     modalScope[modalScope.currentSearch.value] = true;
                        //     modalScope.list.search = {};
                        //     modalScope.list.items = [];
                        //
                        // }

                        modalScope.ok = function() {
                            // console.log(modalScope.listBundle.checklist);
                            // console.log(modalScope.listItem.checklist);
                            modalScope.checkList = [].concat(modalScope.listItem.checklist,modalScope.listBundle.checklist);
                            $uibModalInstance.close(modalScope.checkList);
                        };

                        function checkExisted(list, id) {
                            return list.filter(function(item) {
                                return item.item_id == id;
                            }).length;
                        }

                        function checkAll(_flag) {

                            if(_flag == 'item') {
                                var flag = modalScope.selectItem.isCheckAllItem;
                                modalScope.listItem.checklist = [];
                                modalScope.listItem.items.forEach(function(item) {
                                    item.is_checked = flag;
                                    if (flag && !checkExisted(modalScope.listItem.checklist, item.item_id)) {
                                        modalScope.listItem.checklist.push(item);
                                    }
                                })
                            }
                            if(_flag == 'bundle') {
                                var flag = modalScope.selectItem.isCheckAllBundle;
                                modalScope.listBundle.checklist = [];
                                modalScope.listBundle.items.forEach(function(item) {
                                    item.is_checked = flag;
                                    if (flag && !checkExisted(modalScope.listBundle.checklist, item.id)) {
                                        modalScope.listBundle.checklist.push(item);
                                    }
                                })
                            }
                        };

                        function checkItem(item, _flag) {
                            if(_flag == 'item') {
                                if (item.is_checked && !checkExisted(modalScope.listItem.checklist, item.item_id)) {
                                    modalScope.listItem.checklist.push(item);
                                } else {
                                    modalScope.listItem.checklist = modalScope.listItem.checklist.filter(function(it) {
                                        return it.item_id != item.item_id;
                                    });
                                }

                                if (modalScope.listItem.checklist.length == modalScope.listItem.items.length) {
                                    modalScope.selectItem.isCheckAllItem = true;
                                } else modalScope.selectItem.isCheckAllItem = false;
                            }
                            if(_flag == 'bundle') {
                                if (item.is_checked && !checkExisted(modalScope.listBundle.checklist, item.id)) {
                                    modalScope.listBundle.checklist.push(item);
                                } else {
                                    modalScope.listBundle.checklist = modalScope.listBundle.checklist.filter(function(it) {
                                        return it.id != item.id;
                                    });
                                }


                                if (modalScope.listBundle.checklist.length == modalScope.listBundle.items.length) {
                                    modalScope.selectItem.isCheckAllBundle = true;
                                } else modalScope.selectItem.isCheckAllBundle = false;
                            }

                        }

                    }
                ],
                size: 'lg'
            }).result.then(function(res) {
                if (angular.isArray(res) && res.length > 0) {
                    var listAdded = [];
                    angular.copy($scope.list.items).forEach(function(item) {
                        listAdded.push(item.item_id);

                    });

                    res.forEach(function(item) {
                        if (item.resale_price) item.resale_price = Number(item.resale_price);
                        item['products'] = [];
                        item.quantity = 1;
                        item.totalItem = item.resale_price;
                    })

                    $scope.list.items = $scope.list.items.concat(res.filter(function(item) {
                        return listAdded.indexOf(item.item_id) < 0;
                    }));
                }
                scrollToTable();
            });
        }

        function getSignature() {
            return $uibModal.open({
                templateUrl: 'app/orders/signature.modal.html',
                size: 'lg',
                backdrop: 'static',
                controller: [
                    '$scope',
                    '$uibModalInstance',
                    function(modalScope, $uibModalInstance) {
                        var sketcher;

                        $uibModalInstance
                            .rendered
                            .then(function() {

                                var $parent = $('#signature').closest('.modal-body');

                                sketcher = atrament('#signature', $parent.width(), 300);
                            });

                        modalScope.ok = function() {

                            if (sketcher.dirty) {
                                $uibModalInstance.close(sketcher.toImage());
                            } else {
                                toastr.error('Please sign your signature!');
                            }

                        };

                        modalScope.cancel = function() {
                            $uibModalInstance.close(false);
                        };
                    }
                ]
            });
        }
        $scope.$watch('list.items', function() {
            $timeout(function() {
                updateTotal();
            }, 500);
        })

        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
        }

        /**
         * SCROLL TO ELEMENT
         */
        function scrollToTable() {
            $timeout(function() {
                try {
                    var table = jQuery(".custom-table")[0];
                    var top = table.offsetTop;
                    $('html, body').animate({
                        scrollTop: top
                    }, 500);

                    var focusFirstRow = jQuery('.custom-table tbody tr button');
                    if (focusFirstRow && focusFirstRow[0]) {
                        focusFirstRow[0].focus();
                    }
                } catch (e) {
                    console.log(e)
                }
            })
        }

        hotkeys
            .bindTo($scope)
            .add({
                combo: 'alt+s',
                description: 'Create New Sales Order',
                callback: function(e) {
                    e.preventDefault();
                    $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+shift+n',
                description: 'Add New Item',
                callback: function(e) {
                    e.preventDefault();
                    $scope.addNewItem($scope.list.items, 1);
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+shift+b',
                description: 'Back to Order List',
                callback: function(e) {
                    e.preventDefault();
                    $state.go("app.sale-order.orders.list");
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+shift+c',
                description: 'Create Order',
                callback: function(e) {
                    e.preventDefault();
                    if ($scope.formOrder.$valid && $scope.order.information.company_id && $scope.billing)
                        $scope.createOrder();
                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+d',
                description: 'Delete Item',
                callback: function(e) {
                    e.preventDefault();
                    try {
                        $scope.deleteAction($scope.list.items[$scope.selectedIndex].item_id);
                    } catch (e) {}

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })
            .add({
                combo: 'alt+x',
                description: 'Add new shipping address',
                callback: function(e) {
                    e.preventDefault();
                    try {
                        var item = $scope.list.items[$scope.selectedIndex];
                        if ($scope.checkCloneRecord(item, item)) {
                            $scope.cloneRecord(item, $scope.list.items)
                        }
                    } catch (e) {}

                },
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
            })

    }
})();
