(function() {
    'use strict';
    angular
        .module('app')
        .controller('rma.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout, rmaAPI, $state,hotkeys,$localStorage) {
        //Define variable

        $scope.full_name=$localStorage.USER_DATA.full_name;
        $scope.mainData = {
            selectedOrder: {},
            generalInfo: {},
            listOrderItem:[]
        };
        $scope.selectionData = {};
        $scope.KeyShorcut =KeyShorcut;
        $scope.changeRMA =changeRMA;

        $scope.removeItem = function(src, item) {
            var index = src.indexOf(item);
            src.splice(index, 1);
        }

        $scope.changeOrder = function(id) {
            getOrderDetail(id);
        }

        $scope.cancelRMA = function() {
            $state.go('app.rma.list');
        }
        function KeyShorcut() {
            hotkeys.toggleCheatSheet();
         }

       hotkeys.bindTo($scope)
         .add({
           combo: 'alt+s',
           description: 'Create RMA',
           callback: function() {
            $scope.createRMA()
           }
         })
         .add({
           combo: 'alt+c',
           description: 'Back to Return Order List',
           callback: function() {
            $scope.cancelRMA();
           }
         })

        $scope.createRMA = function() {
            var params = {
                'order_id': $scope.mainData.selectedOrder.id,
                'crtn_on': $scope.mainData.generalInfo.crt_date,
                'rqst_user_id': 1 || $scope.mainData.generalInfo.requester,
                'spcl_instrc': $scope.mainData.generalInfo.spcl_instrc,
                'rma_items': toRMAItem($scope.mainData['listOrderItem']),
                'balance_of_credit':$scope.mainData.generalInfo.balance_of_credit,
                'return_loc':$scope.mainData.generalInfo.return_loc,
                'rma_type':$scope.mainData.generalInfo.rma_type,
            };
            if($scope.mainData.generalInfo.return_loc==2){
                params['pickup_location_id']= $scope.mainData.shippingData.shipping_address_id;
            }
            rmaAPI.createRMA(params).then(function(res) {
                try {
                    if (res.data._type === "success") {
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.rma.list");
                        }, 1000)

                    } else {
                        toastr.error(res.data.message);
                    }
                } catch (e) {
                    console.log(e);
                }
            }, function(err) {
                console.log(err)
            });
        }

        $scope.checkValid = function() {
                return $scope.rmaForm.$valid && checkValidItem();
            }
            /**
             * INIT
             */
        function initVar() {
            $scope.selectionData["RMAType"] = [{ id: 0, name: 'Exchange' }, { id: 1, name: 'Credit' }, { id: 2, name: 'Refund' }, { id: 3, name: 'Re-certification' }];
            $scope.selectionData["ReturnLoc"]= [{id:1,name:'NAB Location'},{id:2,name:'Customer Location'}];
        }

        function initData() {
            getListOrders();
            getRMAInfo();
        }

        function toRMAItem(item) {
            var res = angular.copy(item);
            res.forEach(function(item) {
                delete item['$$hashKey']
                item.is_possible = item.is_possible == 1;
            });
            return res;
        }

        function checkValidItem() {
            for (var i in $scope.mainData['listOrderItem']) {
                if (!$scope.mainData['listOrderItem'][i].is_possible || !$scope.mainData['listOrderItem'][i].serial_num || !$scope.mainData['listOrderItem'][i].prob_des) {
                    return false;
                }
            }
            return true;
        }
        function changeRMA(id){
           if($scope.mainData['listOrderItem'].length>0){
               angular.forEach($scope.mainData['listOrderItem'],function(item){
                   item.type= id;
               })
           }
        }
        $scope.$watch('mainData.listOrderItem',function(){
           $timeout(function(){
            $scope.changeRMA($scope.mainData.generalInfo.rma_type)
           })
        })

        function getListOrders() {
            rmaAPI.getListOrders().then(function(result) {
                if (result) {
                    $scope.mainData['listOrders'] = result.data.results;
                }
            })
        }

        function getOrderDetail(id) {
            rmaAPI.getOrderById(id).then(function(result) {
                if (result) {
                    $scope.mainData['listOrderItem'] = result.data.results;
                    $scope.mainData['listOrderItem'].forEach(function(item) {
                        item['order_detail_id'] = item['id'];
                    });

                }
            })
        }

        function getRMAInfo() {
            rmaAPI.getRMAInfo().then(function(result) {
                if (result.data.results) {
                    $scope.mainData.generalInfo.rma_no = angular.copy(result.data.results).code;
                    console.log(result);
                }
            })
        }

        (function init() {
            initVar();
            initData();
        })()
    }
})();
