(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.orders', {
                url: '/orders',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.buyerrfq', {
                url: '/buyerrfq',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.buyerrfq.list', {
                url: '/list',
                templateUrl: 'app/orders/buyer_rfq/buyer_rfq.list.html',
                controller: 'buyerrfq.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sale-order', {
                url: '/sale-order',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.sale-order.list', {
                url: '/list',
                templateUrl: 'app/orders/orders.list.html',
                controller: 'orders.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sale-order.create', {
                url: '/create',
                templateUrl: 'app/orders/orders.create.html',
                controller: 'orders.create.controller',
                params: {
                    items: []
                }
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.orders.sale-order.detail', {
                url: '/detail/:id',
                templateUrl: 'app/orders/orders.detail.html',
                controller: 'orders.detail.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.delivery-order', {
                url: '/delivery-order',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.delivery-order.list', {
                url: '/list',
                templateUrl: 'app/orders/delivery-orders/delivery-orders.list.html',
                controller: 'delivery-orders.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.delivery-order.create', {
                url: '/create',
                templateUrl: 'app/orders/delivery-orders/delivery-orders.create.html',
                controller: 'delivery-orders.create.controller',               
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.orders.delivery-order.view', {
                url: '/view/:id',
                templateUrl: 'app/orders/delivery-orders/delivery-orders.view.html',
                controller: 'delivery-orders.view.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sales-quotation', {
                url: '/sales-quotation',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.sales-quotation.list', {
                url: '/list',
                templateUrl: 'app/orders/sales-quotation/sales-quotation.list.html',
                controller: 'sales-quotation.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sales-quotation.create', {
                url: '/create',
                templateUrl: 'app/orders/sales-quotation/sales-quotation.create.html',
                controller: 'sales-quotation.create.controller',               
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.orders.sales-quotation.detail', {
                url: '/detail/:id',
                templateUrl: 'app/orders/sales-quotation/sales-quotation.detail.html',
                controller: 'sales-quotation.detail.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sales-quotation.update', {
                url: '/update/:id',
                templateUrl: 'app/orders/sales-quotation/sales-quotation.update.html',
                controller: 'sales-quotation.update.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sales-quotation.buyerrfq', {
                url: '/buyerrfq/:id',
                templateUrl: 'app/orders/sales-quotation/sales-quotation.update.html',
                controller: 'sales-quotation.buyerrfq.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.rma', {
                url: '/rma',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.rma.list', {
                url: '/list',
                templateUrl: 'app/orders/rma.list.html',
                controller: 'rma.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.rma.create', {
                url: '/create',
                templateUrl: 'app/orders/rma.create.html',
                controller: 'rma.create.controller'
            })
            .state('app.orders.rma.view', {
                url: '/view/:id',
                templateUrl: 'app/orders/rma.view.html',
                controller: 'rma.view.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sale-price', {
                url: '/sales-price',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.orders.sale-price.list', {
                url: '/list',
                templateUrl: 'app/orders/salesprice.list.html',
                controller: 'salesprice.list.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
            .state('app.orders.sale-price.create', {
                url: '/create',
                templateUrl: 'app/orders/salesprice.create.html',
                controller: 'salesprice.create.controller'
            })
            .state('app.orders.sale-price.edit', {
                url: '/view/:id',
                templateUrl: 'app/orders/salesprice.view.html',
                controller: 'salesprice.view.controller',
                // middleware: ['auth', 'manager_salesman_bo']
            })
    }

})();
