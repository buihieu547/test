(function () {

    'use strict';

    angular.module('app').service('salespriceAPI', service);


    function service(API) {

        this.createSalePrice = createSalePrice;
        this.getList = getList;
        this.getDetailSalePrice = getDetailSalePrice;
        this.updateSalePrice = updateSalePrice;
       
        /** Internal functions */    

        function getList(params) {
           var url='sale-price/get-list';
            return API.get(url,params);
        }       
        function createSalePrice(params) {
            var url ='sale-price';
            return API.post(url, params);
        }
        function getDetailSalePrice(id) {
            var url ='sale-price/'+id;
            return API.get(url);
        }
        function updateSalePrice(id,params){
            var url ='sale-price/'+id;
            return API.put(url, params);
        }
    }
})();
