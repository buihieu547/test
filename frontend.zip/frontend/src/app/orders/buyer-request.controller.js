(function() {
    'use strict';

    angular
        .module('app')
        .controller('buyer-request.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, API, buyerRFQ, $localStorage, MessageService, $stateParams, hotkeys, $state) {

        $scope.log = '';
        (function onInit() {
            console.log($stateParams);
            getDetail();
        })();


        function getDetail() {
            var id = $stateParams.token;

            if(id) {
                API.get('order/sale-quote/buyer-approved?token=' + id).success(function (res) {
                    $scope.log = res;
                    alert(res);
                });
            }
        }


    }
})();
