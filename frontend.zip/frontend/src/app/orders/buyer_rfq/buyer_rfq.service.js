(function () {

    'use strict';

    angular.module('app').service('buyerRFQ', service);


    function service(API) {

        this.createSalePrice = createSalePrice;
        this.getList = getList;
        this.getDetailBuyerRFQ = getDetailBuyerRFQ;
        this.updateSalePrice = updateSalePrice;
       
        /** Internal functions */    

        function getList(params) {
           var url='rfq';
            return API.get(url,params);
        }       
        function createSalePrice(params) {
            var url ='sale-price';
            return API.post(url, params);
        }
        function getDetailBuyerRFQ(id) {
            var url ='rfq/'+id;
            return API.get(url);
        }
        function updateSalePrice(id,params){
            var url ='sale-price/'+id;
            return API.put(url, params);
        }
    }
})();
