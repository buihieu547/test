(function () {
    'use strict';
    angular
        .module('app')
        .controller('salesprice.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,  productAPI,salespriceAPI, $state, hotkeys, $localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            products: []
        };
        $scope.listStatus = [
            {
                id: '0',
                name: "In-Active"
            }, {
                id: '1',
                name: "Active "
            }
        ];
        $scope.productList = [];
        // $scope.changeQTY =changeQTY;
        (function onInit() {
            getProductList();
        })();
        $scope.clickAdd = function () {

            $scope
                .mainData
                .products
                .push({});
        };
        $scope.remove = function (index) {
            $scope
                .mainData
                .products
                .splice(index, 1);
                // $scope.changeQTY();
        };
        $scope.cancelSalePrice= function(){
            $state.go("app.orders.sale-price.list");
        }
        $scope.createSalePrice = function(){
            console.log($scope.mainData);
            var params = $scope.mainData.generalInfo;
            params.products = $scope.mainData.products;
            console.log(params);
            salespriceAPI.createSalePrice(params).then(function(res){
                try{
                    if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.orders.sale-price.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }
        $scope.changeProductLine = function(item,index){
            console.log(index)
            var itemID=$scope.productList.filter(function(product){
                if(product.item_id == item.wine_id)
                    return product;
            });
            item.name = itemID[0].name;
            item.uom_name=itemID[0].uom_name;
            item.price=itemID[0].price;
            item.resale_price = itemID[0].resale_price;
        }

        function getProductList(){
            productAPI.getListItemOption().then(function(res){
                $scope.productList = res.data.results;
            })
        }
        // function changeQTY(){
        //     $scope.mainData.generalInfo.bundle_cost_price = 0;
        //     var list = $scope.mainData.products;
        //     if(list.length==0){
        //         return;
        //     }else{
        //         var priceLine = 0;
        //         for(var i =0; i<list.length; i++){
        //             if(list[i].qty!=0){
        //                 priceLine += (list[i].qty * list[i].price);
        //             }
        //         }
        //         $scope.mainData.generalInfo.bundle_cost_price  = priceLine;
        //     }
        // }

    }
})();
