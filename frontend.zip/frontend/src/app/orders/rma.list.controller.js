(function () {
    'use strict';

    angular.module('app').controller('rma.list.controller', controller);

    /** @ngInject */
    function controller($scope, $controller, $state, API, orderAPI,$localStorage, MessageService, hotkeys) {

        var $listController = $controller('abstract.list.controller',{ $scope : $scope });

        // if($localStorage.USER_DATA) {
        //     $scope.permission = $localStorage.USER_DATA.role_alias;
        // }

        $scope.getList = getList;
        $scope.listOrderType = [{id:'PKU',name:"Pickup "},{id:'CE',name:"Call"},{id:'ONL',name:"Ecommerce"}];
        $scope.KeyShorcut = KeyShorcut;
        $scope.resetAction = resetAction;


        $scope.filter = filter;

        $scope.list = {
            items : [],
            search: {}
        };

        /** Internal functions */

        (function onInit() {
            $scope.focusFlag = false;
            getList();
            getListStatus();
        })();

       function KeyShorcut() {
           hotkeys.toggleCheatSheet();
        }

      hotkeys.bindTo($scope)
        .add({
          combo: 'alt+s',
          description: 'Search data based on key',
          callback: function() {
            $scope.searchAction($scope.list.search);
          },
          allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        .add({
          combo: 'alt+r',
          description: 'Reset data search',
          callback: function() {
            $scope.resetAction();
          },
          allowIn: ['INPUT', 'SELECT', 'TEXTAREA']
        })
        .add({
          combo: 'alt+n',
          description: 'New RMA',
          callback: function() {
            $state.go("app.rma.create");
          }
        })
        .add({
              combo: 'enter',
              description: 'Go to  detail RMA',
              callback: function (e) {
                  if ($scope.selectedIndex > -1) {
                      $scope.item_detail = $scope.list.items[$scope.selectedIndex].rma_id;
                        $state.go("app.orders.rma.view",{id: $scope.item_detail});

                  }

             }
          });


        function resetAction() {
            $scope.list.search = {};
            $listController.searchAction();
        }

        function getListStatus() {
            API.get('order/list-status').then(function(res) {
                try {
                    $scope.listStatus = res.data.results;
                } catch (e) {
                    console.log(e);
                }
            })
        }


        function getList() {
            var params = $listController.getParams();
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
            API.get('rma/index',params).then(function(res) {

                try {
                    $scope.list.items = res.data.results.rows;
                    $listController.matchPagingOption(res.data.results);
                    $scope.focusFlag = false;
                    if(res.data.results.rows.length <= 0) {
                      $scope.focusFlag = true;
                    }
                } catch(e) {
                    console.log(e);
                }
            });
        }


        function filter(type) {
            $scope.list.search.sts = type;

            return $scope.searchAction($scope.list.search);
        }


    }
})();
