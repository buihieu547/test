
(function () {
    'use strict';

    angular
        .module('app')
        .service('dashboardAPI', service);

    /** @ngInject */
    function service(API, $q, $interval, $http) {

        // promotion dashboard
        this.getPromotionReport = getPromotionReport;
        this.getOverAllCount = getOverAllCount;
        this.topEffectCampaignSaleAmount = topEffectCampaignSaleAmount;
        this.topProductRevenue = topProductRevenue;
        this.topProductSoldByCategory = topProductSoldByCategory;
        this.topExpenseOnBudget = topExpenseOnBudget;
        this.topCustomerCampaignPeriod = topCustomerCampaignPeriod;
        this.topBuyerBySaleAmount = topBuyerBySaleAmount;
        // overall dashboard
        this.recentSaleOrder = recentSaleOrder;
        this.saleOrderByStatus =saleOrderByStatus;
        this.numberOfOrderByCustomerType = numberOfOrderByCustomerType;
        this.numberOfNewCustomerByType = numberOfNewCustomerByType;
        this.topBuyer = topBuyer;
        this.newOfBuyerByType = newOfBuyerByType;
        this.annualSaleRevenue = annualSaleRevenue;
        this.topSellingSKU = topSellingSKU;


        function getPromotionReport(params) {
            var url = ['promotion-report', 'get-statistics'].join('/');
            return API.get(url, params);
        }
        function getOverAllCount(params){
            var url = ['reports', 'count-overall'].join('/');
            return API.get(url, params);
        }
        function topEffectCampaignSaleAmount(){
            var url =['reports','top-effective-campaign-by-sales-amount'].join('/');
            return API.get(url);
        }
        function topProductRevenue(){
            var url =['reports','top-products-revenue'].join('/');
            return API.get(url);
        }
        function topProductSoldByCategory(){
            var url =['reports','top-product-sold-by-category'].join('/');
            return API.get(url);
        }
        function topExpenseOnBudget(params) {
            var url = ['reports', 'expense-on-budget'].join('/');
            return API.get(url, params);
        }
        function topCustomerCampaignPeriod() {
            var url =['reports','new-customer-during-campaign-period'].join('/');
            return API.get(url);
        }
        function topBuyerBySaleAmount() {
            var url =['reports', 'top-buyers-by-sales-amount'].join('/');
            return API.get(url);
        }
        function recentSaleOrder() {
            var url = ['reports', 'order-history'].join('/');
            return API.get(url);
        }
        function saleOrderByStatus() {
            var url =['reports', 'sale-order-status'].join('/');
            return API.get(url);
        }
        function numberOfOrderByCustomerType() {
            var url = ['reports', 'number-of-orders-by-customer-type'].join('/');
            return API.get(url);
        }
        function numberOfNewCustomerByType() {
            var url = ['reports', 'number-of-new-customer-by-type'].join('/');
            return API.get(url);
        }
        function topBuyer() {
            var url = ['reports', 'top-buyer'].join('/');
            return API.get(url);
        }
        function newOfBuyerByType() {
            var url = ['reports', 'new-of-buyer-by-type'].join('/');
            return API.get(url);
        }
        function annualSaleRevenue() {
            var url = ['reports', 'annual-sale-revenue'].join('/');
            return API.get(url);
        }
        function topSellingSKU() {
            var url = ['reports', 'top-selling-sku'].join('/');
            return API.get(url);
        }


    }
})();
