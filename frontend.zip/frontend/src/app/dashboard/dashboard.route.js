(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.dashboard', {
                url: '/dashboard',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.dashboard.promotion', {
                url: '/promotion',
                templateUrl: 'app/dashboard/dashboard.promotion.html',
                controller: 'dashboard.promotion.controller',
            })
            .state('app.dashboard.overall', {
                url: '/overall',
                templateUrl: 'app/dashboard/dashboard.overall.html',
                controller: 'dashboard.overall.controller',
            })
    }

})();
