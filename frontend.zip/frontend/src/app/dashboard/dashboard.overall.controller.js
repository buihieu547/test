(function() {
    'use strict';

    angular.module('app').controller('dashboard.overall.controller', controller);

    angular.module('app').config(function(ChartJsProvider) {
        // Configure all charts
        ChartJsProvider.setOptions({
            colors: ['#2f38ed', '#7f4c4c', '#d13e42', '#16afad', '#d88015', '#3b4c68', '#257a06']
        });
    });

    /** @ngInject */
    function controller($scope, $controller, productAPI, $state, $uibModal, $localStorage,dashboardAPI) {


        $scope.listCategory = [{id:1, name: 'WINE'}, {id:2, name: 'ALCOHOL'}]

        //Chart 1
        // $scope.canvas = document.getElementById("pie1");
        // $scope.canvas.onclick = function (event) {
        // console.log('chartClick');
        // console.log($scope.myPieChart.getSegmentsAtEvent(event));
        // }
        $scope.data ={};
        $scope.listOrderHistory = [];

        (function onInit() {
            countNumber();
            recentSaleOrder();
            numberOfNewCustomerByType();
            numberOfOrderByCustomerType();
            saleOrderByStatus();
            topBuyer();
            newOfBuyerByType();
            annualSaleRevenue();
            topSellingSKU();
        })();

        function countNumber(){
            var params = {};
            dashboardAPI.getOverAllCount(params).then(function(res) {
                try {
                    $scope.data.total_available_sku = res.data.results.total_available_sku;
                    $scope.data.total_bundle = res.data.results.total_bundle;
                    $scope.data.total_completed_order = res.data.results.total_completed_order;
                    $scope.data.total_customer = res.data.results.total_customer;
                    $scope.data.total_out_stock_sku = res.data.results.total_out_stock_sku;
                    $scope.data.total_purchase_order = res.data.results.total_purchase_order;
                    $scope.data.total_sale_order = res.data.results.total_sale_order;
                    $scope.data.total_slow_stock_sku = res.data.results.total_slow_stock_sku;

                } catch(e) {
                    console.log(e);
                }
            });
        }

        function recentSaleOrder() {
            dashboardAPI.recentSaleOrder().then(function (res) {
                try {
                    $scope.listOrderHistory = res.data.results;
                } catch (e) {
                    console.log(e);
                }
            })
        }



        $scope.onClickTry = function (points, evt) {
            console.log(points, evt);
        };
        $scope.backgroundColor = ["#F7464A","#46BFBD","#FDB45C","#949FB1","#4D5360"];


        //chart 1
        $scope.labels1 = [];
        $scope.data1 = [];
        function saleOrderByStatus(){
            dashboardAPI.saleOrderByStatus().then(function(res){
                try{
                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.labels1.push(element.status_name);
                    $scope.data1.push(element.order_cnt);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }

        $scope.options1 = {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                xAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }],
                yAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }]
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {

                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                          var tooltipLabel = data.labels[tooltipItem.index];
                          var tooltipData = allData[tooltipItem.index];
                        var total = 0;
                        for (var i in allData) {
                            total += allData[i];
                        }
                        var tooltipPercentage = Math.round((tooltipData / total) * 100);
                        return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                    }
                }
            }
        };
        $scope.changeCategory = function () {
            $scope.data1 = [500, 100, 100, 300, 300];
        }

        //Chart 2
        $scope.labels2=[];
        $scope.data2=[];

        function numberOfNewCustomerByType(){
            dashboardAPI.numberOfNewCustomerByType().then(function(res){
                try{

                var data = res.data.results;

                data.forEach(function(element) {
                    $scope.labels2.push(element.customer_type)
                    $scope.data2.push(element.customer_cnt);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }

        $scope.options2 = {
            // events: true,
            tooltips: {enabled: true},
            legend: {
                display: false
            },
            scales: {
                yAxes: [{
                    display: true
                }]
            }
        };

        // Chart 3
        $scope.labels3 = [];
        $scope.data3 = [];

        function numberOfOrderByCustomerType(){
            dashboardAPI.numberOfOrderByCustomerType().then(function(res){
                try{
                var data = res.data.results;
                // console.log(data);
                data.forEach(function(element) {
                    $scope.labels3.push(element.customer_type);
                    $scope.data3.push(element.order_cnt);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }

        $scope.changeCategory = function () {
            $scope.data3 = [500, 100, 100, 300, 300];
        }

        // Chart 4
        $scope.labels4 = [];
        $scope.data4 = [];
        function newOfBuyerByType(){
            dashboardAPI.newOfBuyerByType().then(function(res){
                try{
                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.labels4.push(element.customer_type);
                    $scope.data4.push(element.buyer_cnt);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.changeCategory = function () {
            $scope.data4 = [900, 100, 100, 100, 100];
        }

        //Chart 5
        $scope.backgroundColor5 = [ { // green
           backgroundColor: 'rgb(0%, 46%, 0%)',
           pointBackgroundColor: 'rgb(0%, 46%, 0%)',
           pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
           borderColor: 'rgb(0%, 46%, 0%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
         },
         { // blue
           backgroundColor: 'rgb(2%, 85%, 92%)',
           pointBackgroundColor: 'rgb(2%, 85%, 92%)',
           pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
           borderColor: 'rgb(2%, 85%, 92%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
       }];

        $scope.labels5 = [];
        $scope.data5 = [];
        var first = [];
        var second = [];
        function topBuyer(){
            dashboardAPI.topBuyer().then(function(res){
                try{
                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.labels5.push(element.buyer_name);
                    first.push(element.order_cnt);
                    second.push(element.total_revenue);
                });
                $scope.data5 = [ first, second ];
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
        $scope.series5 = ['Total sales orders', 'Total Revenues $']
        $scope.options5 = {
            legend: { display: true },
            // title: { display: true, text: 'Top Selling Repair Shop Chart' },
            scales: {
            yAxes: [
                {
                  id: 'y-axis-1',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    //    stepSize: 1,
                       beginAtZero: true
                     }
                },
                {
                  id: 'y-axis-2',
                  type: 'linear',
                  display: true,
                  position: 'right',
                  ticks: {
                     //   stepSize: 1,
                       callback: function(value, index, values) {
                          return '$' + value;
                      },
                      beginAtZero: true,
                      min: 0
                 },
                 scaleLabel: {
                   display: true,
                 //   labelString: 'sdgsdfg'
                 }
                }
              ],
              xAxes: [{
               display: true,
               ticks: {
                 // stepSize: 2
               }
             }]
            }
        }
        //Chart 6
        $scope.labels6 = [];
        $scope.data6 = [];
        function annualSaleRevenue(){
            dashboardAPI.annualSaleRevenue().then(function(res){
                try{
                var data = res.data.results;
                data.forEach(function(element) {
                    $scope.labels6.push(element.month_name);
                    $scope.data6.push(element.total_revenue);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.backgroundColor6 = [
            // { // green
        //    backgroundColor: 'rgb(0%, 46%, 0%)',
        //    pointBackgroundColor: 'rgb(0%, 46%, 0%)',
        //    pointHoverBackgroundColor: 'rgb(0%, 46%, 0%)',
        //    borderColor: 'rgb(0%, 46%, 0%)',
        //    pointBorderColor: '#fff',
        //    pointHoverBorderColor: 'rgb(0%, 46%, 0%)'
        //  },
         { // blue
           backgroundColor: 'rgb(2%, 85%, 92%)',
           pointBackgroundColor: 'rgb(2%, 85%, 92%)',
           pointHoverBackgroundColor: 'rgb(2%, 85%, 92%)',
           borderColor: 'rgb(2%, 85%, 92%)',
           pointBorderColor: '#fff',
           pointHoverBorderColor: 'rgb(2%, 85%, 92%)'
       }];

       //chart 7
       $scope.labels7 = [];
       $scope.data7 = [];
       var first7 = [];
       var second7 = [];

       function topSellingSKU(){
           dashboardAPI.topSellingSKU().then(function(res){
               try{
               var data = res.data.results;
               data.forEach(function(element) {
                  $scope.labels7.push(element.sku)
                  first7.push(element.total_quantity);
                  second7.push(element.total_revenue);
               });
                 $scope.data7 = [first7, second7];
               }catch(e){
                   console.log(e);
               }
           })
       }




    //SETUP FONT TEXT IN DOUGHNUT Chart
    Chart.pluginService.register({
        beforeDraw: function (chart) {
            if (chart.config.options.elements.center) {
        //Get ctx from string
        var ctx = chart.chart.ctx;

                //Get options from the center object in options
        var centerConfig = chart.config.options.elements.center;
        var fontStyle = centerConfig.fontStyle || 'Arial';
                var txt = centerConfig.text;
        var color = centerConfig.color || '#000';
        var sidePadding = centerConfig.sidePadding || 20;
        var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
        //Start with a base font of 30px
        ctx.font = "30px " + fontStyle;

                //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
        var stringWidth = ctx.measureText(txt).width;
        var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

        // Find out how much the font can grow in width.
        var widthRatio = elementWidth / stringWidth;
        var newFontSize = Math.floor(30 * widthRatio);
        var elementHeight = (chart.innerRadius * 2);

        // Pick a new font size so it will not be larger than the height of label.
        var fontSizeToUse = Math.min(newFontSize, elementHeight);

                //Set font settings to draw it correctly.
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
        var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
        ctx.font = fontSizeToUse+"px " + fontStyle;
        ctx.fillStyle = color;

        //Draw text in center
        ctx.fillText(txt, centerX, centerY);
            }
        }
    });


    }

})();
