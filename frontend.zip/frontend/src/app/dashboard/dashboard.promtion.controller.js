(function() {
    'use strict';

    angular.module('app').controller('dashboard.promotion.controller', controller);

    angular.module('app').config(function(ChartJsProvider) {
        // Configure all charts
        ChartJsProvider.setOptions({
            colors: ['#2f38ed', '#7f4c4c', '#d13e42', '#16afad', '#d88015', '#3b4c68', '#257a06']
        });
    });

    /** @ngInject */
    function controller($scope, $controller, productAPI, $state, $uibModal, $localStorage, dashboardAPI) {

        $scope.date_from = '';
        $scope.date_to = '';
        $scope.listCategory = [{id:1, name: 'WINE'}, {id:2, name: 'ALCOHOL'}];
        $scope.data = {};

        $scope.onChangeDatePicker = onChangeDatePicker;
        $scope.resetSearch = resetSearch;

        function onChangeDatePicker() {
            var params = {
                from:$scope.date_from,
                to:$scope.date_to
            };
            dashboardAPI.getOverAllCount(params).then(function(res) {
                try {
                    $scope.data.budgets = res.data.results.total_budget;
                    $scope.data.campaign = res.data.results.total_campaign;
                    $scope.data.programs = res.data.results.total_program;
                    console.log(res.data.results.programs);
                } catch(e) {
                    console.log(e);
                }
            });
            topExpenseOnBudget();
        }

        function resetSearch() {
            $scope.date_from = '';
            $scope.date_to = '';

        }
        (function onInit(){
            topEffectCampaignSaleAmount();
            topProductRevenue();
            topProductSoldByCategory();
            topCustomerCampaignPeriod();
            topBuyerBySaleAmount();
        })();

        //Chart 1
        // $scope.canvas = document.getElementById("pie1");
        // $scope.canvas.onclick = function (event) {
        // console.log('chartClick');
        // console.log($scope.myPieChart.getSegmentsAtEvent(event));
        // }
        $scope.onClickTry = function (points, evt) {
            console.log(points, evt);
        };
        $scope.backgroundColor = ["#F7464A","#46BFBD","#FDB45C","#949FB1","#4D5360"];
        function topProductSoldByCategory(){
            dashboardAPI.topProductSoldByCategory().then(function(res){
                try{
                //     $scope.data['top-product-category'] = {};
                // $scope.data['top-product-category']['label'] = [];
                // $scope.data['top-product-category']['data'] = [];

                var data = res.data.results;
                // console.log(data);
                data.forEach(function(element) {
                    $scope.labels1.push(element.category_name);
                    $scope.data1.push(element.qty_used);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.labels1 = [];
        $scope.data1 = [];
        $scope.options1 = {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                xAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }],
                yAxes: [{
                    display: this.scalesdisplay,
                    ticks: {
                        beginAtZero: this.beginzero,
                    }
                }]
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {

                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                          var tooltipLabel = data.labels[tooltipItem.index];
                          var tooltipData = allData[tooltipItem.index];
                        var total = 0;
                        for (var i in allData) {
                            total += allData[i];
                        }
                        var tooltipPercentage = Math.round((tooltipData / total) * 100);
                        return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                    }
                }
            }
        };
        $scope.changeCategory = function () {
            $scope.data1 = [500, 100, 100, 300, 300];
        }

        //Chart 2
        function topEffectCampaignSaleAmount(){
            dashboardAPI.topEffectCampaignSaleAmount().then(function(res){
                try{
                //     $scope.data['top-product-category'] = {};
                // $scope.data['top-product-category']['label'] = [];
                // $scope.data['top-product-category']['data'] = [];

                var data = res.data.results;
                // console.log(data);
                data.forEach(function(element) {
                    $scope.labels2.push(element.campaign_name);
                    $scope.data2.push(element.total_price);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.labels2 = [];
        $scope.data2 = [];
        $scope.options2 = {
            // events: true,
            tooltips: {enabled: true},
            legend: {
                display: false
            },
            scales: {
                yAxes: [{
                    display: true
                }]
            }
        };

        // Chart 3
        function topProductRevenue(){
            dashboardAPI.topProductRevenue().then(function(res){
                try{
                //     $scope.data['top-product-category'] = {};
                // $scope.data['top-product-category']['label'] = [];
                // $scope.data['top-product-category']['data'] = [];

                var data = res.data.results;
                // console.log(data);
                data.forEach(function(element) {
                    $scope.labels3.push(element.item_name);
                    $scope.data3.push(element.total_item_price);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.labels3 = [];
        $scope.data3 = [];
        $scope.changeCategory = function () {
            $scope.data3 = [500, 100, 100, 300, 300];
        }

        // Chart 4
        $scope.labels4 = [];
        $scope.data4 = [];
        function topCustomerCampaignPeriod(){
            dashboardAPI.topCustomerCampaignPeriod().then(function(res){
                try{
                //     $scope.data['top-product-category'] = {};
                // $scope.data['top-product-category']['label'] = [];
                // $scope.data['top-product-category']['data'] = [];

                var data = res.data.results;
                // console.log(data);
                data.forEach(function(element) {
                    $scope.labels4.push(element.campaign_mane);
                    $scope.data4.push(element.user_count);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }
        $scope.changeCategory = function () {
            $scope.data4 = [900, 100, 100, 100, 100];
        }

        //Chart 5
        $scope.chart5Model = '';
        $scope.chart5Data = {}
        $scope.changeBudget = changeBudget;
        $scope.listBudgets = [{id:1, name: 'PRODUCT'}, {id:2, name: 'MONEY'}];
        $scope.data5 = [];

        function topExpenseOnBudget(){
            var params = {
                from_date:$scope.date_from,
                to_date:$scope.date_to
            };
            dashboardAPI.topExpenseOnBudget(params).then(function(res){
                try{
                $scope.chart5Data = res.data.results;
                }catch(e){
                    console.log(e);
                }
            })
        }
        function changeBudget(name) {
            if(name == 'PRODUCT') {
                $scope.data5 = [$scope.chart5Data.product.used_quantity_percent, $scope.chart5Data.product.remain_quantity_percent]
            }
            if(name == 'MONEY') {
                $scope.data5 = [$scope.chart5Data.money.used_amount_percent, $scope.chart5Data.money.remain_amount_percent]
            }
            $scope.backgroundColor5 = ["#46BFBD","#DCDCDC"]
            $scope.labels5 = ['used_amount_percent', 'remain_amount_percent'];
            $scope.options5 = {
                cutoutPercentage: 60,
                 animation: false,
                 legend: {
                     display: false
                 },
                 responsive: false,
                 maintainAspectRatio: false,
                 scales: {
                     xAxes: [{
                         display: this.scalesdisplay,
                         ticks: {
                             beginAtZero: this.beginzero,
                         }
                     }],
                     yAxes: [{
                         display: this.scalesdisplay,
                         ticks: {
                             beginAtZero: this.beginzero,
                         }
                     }]
                 },
                 tooltips: {
                     callbacks: {
                         label: function(tooltipItem, data) {

                             var allData = data.datasets[tooltipItem.datasetIndex].data;
                               var tooltipLabel = data.labels[tooltipItem.index];
                               var tooltipData = allData[tooltipItem.index];
                             var total = 0;
                             for (var i in allData) {
                                 total += allData[i];
                             }
                             var tooltipPercentage = Math.round((tooltipData / total) * 100);
                             return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                         }
                     }
                 },
                 elements: {
                     center: {
                         text: $scope.data5[0] + '%',
                         color: '#4D5360', // Default is #000000
                         fontStyle: 'Arial', // Default is Arial
                         sidePadding: 15 // Defualt is 20 (as a percentage)
                     }
                }
            }
        }

        //Chart 6
        $scope.labels6 = [];
        $scope.data6 = [];
        function topBuyerBySaleAmount(){
            dashboardAPI.topBuyerBySaleAmount().then(function(res){
                try{
                var data = res.data.results;
                console.log(data);
                data.forEach(function(element) {
                    $scope.labels6.push(element.buyer_name);
                    $scope.data6.push(element.total_amount);
                });
                }catch(e){
                    console.log(e);
                }
            })
        }







    //SETUP FONT TEXT IN DOUGHNUT Chart
    Chart.pluginService.register({
        beforeDraw: function (chart) {
            if (chart.config.options.elements.center) {
        //Get ctx from string
        var ctx = chart.chart.ctx;

                //Get options from the center object in options
        var centerConfig = chart.config.options.elements.center;
        var fontStyle = centerConfig.fontStyle || 'Arial';
                var txt = centerConfig.text;
        var color = centerConfig.color || '#000';
        var sidePadding = centerConfig.sidePadding || 20;
        var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
        //Start with a base font of 30px
        ctx.font = "30px " + fontStyle;

                //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
        var stringWidth = ctx.measureText(txt).width;
        var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

        // Find out how much the font can grow in width.
        var widthRatio = elementWidth / stringWidth;
        var newFontSize = Math.floor(30 * widthRatio);
        var elementHeight = (chart.innerRadius * 2);

        // Pick a new font size so it will not be larger than the height of label.
        var fontSizeToUse = Math.min(newFontSize, elementHeight);

                //Set font settings to draw it correctly.
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
        var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
        ctx.font = fontSizeToUse+"px " + fontStyle;
        ctx.fillStyle = color;

        //Draw text in center
        ctx.fillText(txt, centerX, centerY);
            }
        }
    });


    }

})();
