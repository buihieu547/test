(function() {
    'use strict';
    angular
        .module('app')
        .controller('segment.create.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, promotionAPI, buyerAPI, $state,hotkeys,$localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            segmentList:[]
        };
        $scope.countries=[];
        $scope.all_customer_type ='1';
        $scope.listApplyFor = [{
            id: '1',
            name: "All customers"
        }, {
            id: '2',
            name: "Specific Customers "
        }];
        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];
        $scope.customerType=[];
        $scope.allCustomerType=[
            {
               id: '1',
               name: "All customers "
           },

       ];

        (function onInit() {
            getListCountry();
            getListBuyerType();
            $scope.mainData.generalInfo.crtd_on = new Date();

          })();
        $scope.clickAdd= function() {
            console.log('a');
            $scope.mainData.segmentList.push({'has_specific_customer':false});
        };
        $scope.remove= function(index) {
            $scope.mainData.segmentList.splice(index, 1);
        };
        function getListCountry() {
            API.get('country/get-all').then(function(res) {
              try {
                $scope.countries = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          function getListBuyerType(){
            buyerAPI.getListBuyerType().then(function(res){
              try {
                $scope.customerType = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          $scope.changeToGetCustomer= function(segment,index){

              var params = {'type': segment.type, 'country_code':segment.country_code}
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
              promotionAPI.getCustomerSegment(params).then(function(res){
                try{
                    $scope.mainData.segmentList[index].customerList = res.data.results;
                }catch(e){
                    console.log(e);
                }
              })
          }
          $scope.checkCustomerList = function(segment){
              if(segment.customers.length>0){
                segment.has_specific_customer = true;
              }else{
                segment.has_specific_customer = false;
              }
          }
          $scope.cancelSegment = function(){
              $state.go('app.customer.customer-segment.list');
          }
          $scope.createSegment = function(){
              var params = $scope.mainData.generalInfo;
              params.detail = $scope.mainData.segmentList;
              promotionAPI.postSegment(params).then(function(res){
                  try{
                      if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.customer.customer-segment.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                      }

                  }catch(e){
                      console.log(e);
                  }
              })

          }

    }
})();
