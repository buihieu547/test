

(function () {
    'use strict';

    angular
        .module('app')
        .config(config);

    /** @ngInject */
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        $stateProvider
            .state('app.customer', {
                url: '/customer',
                template: '<ui-view></ui-view>',
                abstract: true
            })
           .state('app.customer.buyers', {
                url: '/buyers',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.customer.buyers.manage', {
                url: '/manage',
                templateUrl: 'app/buyers/buyers.manage.html',
                controller: 'buyers.manage.controller',
                // middleware : ['auth', 'manager_salesman']
            })
            .state('app.customer.buyers.create', {
                url: '/create/:redirect/:ids',
                templateUrl: 'app/buyers/buyers.create.html',
                controller: 'buyers.create.controller',
                // middleware: ['auth', 'manager_salesman']
            })
            .state('app.customer.buyers.edit', {
                url: '/edit/:id',
                templateUrl: 'app/buyers/buyers.edit.html',
                controller: 'buyers.edit.controller',
                // middleware: ['auth', 'manager_salesman']
            }).state('app.customer.customer-segment', {
                url: '/customer-segment',
                template: '<ui-view></ui-view>',
                abstract: true
            })
            .state('app.customer.customer-segment.list', {
                url: '/list',
                templateUrl: 'app/buyers/customer.segment.html',
                controller: 'customer.segment.controller',
            })
            .state('app.customer.customer-segment.create', {
                url: '/create',
                templateUrl: 'app/buyers/segment.create.html',
                controller: 'segment.create.controller',
            })
            .state('app.customer.customer-segment.edit', {
                url: '/view/:id',
                templateUrl: 'app/buyers/segment.view.html',
                controller: 'segment.view.controller',
            })
    }

})();
