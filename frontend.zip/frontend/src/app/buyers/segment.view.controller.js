(function() {
    'use strict';
    angular
        .module('app')
        .controller('segment.view.controller', controller);

    /** @ngInject */
    function controller($scope, $rootScope, $stateParams, $timeout,API, promotionAPI, buyerAPI, $state,hotkeys,$localStorage) {
        //Define variable
        $scope.mainData = {
            generalInfo: {},
            segmentList:[]
        };
        $scope.countries=[];
        $scope.all_customer_type ='1';
        $scope.listApplyFor = [{
            id: 1,
            name: "All customers"
        }, {
            id: 2,
            name: "Specific Customers "
        }];
        $scope.listStatus = [{
            id: 'IA',
            name: "In-Active"
        }, {
            id: 'AT',
            name: "Active "
        }];
        $scope.customerType=[];
        $scope.allCustomerType=[
            {
               id: '1',
               name: "All customers "
           },

       ];
       $scope.updateStateSelect2 = updateStateSelect2;

        (function onInit() {
            getListCountry();
            getListBuyerType();
            var id = $stateParams.id;
            if(id)
            {
                getDetailSegment(id);
            }

          })();
        $scope.clickAdd= function() {           
            $scope.mainData.segmentList.push({'has_specific_customer':false});
        };
        $scope.remove= function(index) {
            $scope.mainData.segmentList.splice(index, 1);
        };
        function getListCountry() {
            API.get('country/get-all').then(function(res) {
              try {
                $scope.countries = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          function getListBuyerType(){
            buyerAPI.getListBuyerType().then(function(res){
              try {
                $scope.customerType = res.data.results;

              } catch (e) {
                console.log(e);
              }
            })
          }
          $scope.changeToGetCustomer= function(segment,index){

              var params = {'type': segment.company_type_id, 'country_code':segment.country_code}
            Object.keys(params).forEach(function(item) {
                if (angular.isArray(params[item])) {
                    params[item] = params[item].join(',');
                }
                return item;
            })
              promotionAPI.getCustomerSegment(params).then(function(res){
                try{
                    $scope.mainData.segmentList[index].customerList = res.data.results;
                }catch(e){
                    console.log(e);
                }
              })
          }
          $scope.getCustomer = function(item){
            var params = {'type': item.company_type_id, 'country_code':item.country_code}
            promotionAPI.getCustomerSegment(params).then(function(res){
                try{
                   item.customerList = res.data.results;
                   $scope.updateStateSelect2();
                }catch(e){
                    console.log(e);
                }
              })
          }
          $scope.checkCustomerList = function(segment){
              if(segment.customers.length>0){
                segment.has_specific_customer = true;
              }else{
                segment.has_specific_customer = false;
              }
          }
              function updateStateSelect2() {
                $timeout(function() {
                    angular.element(".multiple-select2").trigger("change");
                }, 1000)
        }
          $scope.cancelSegment = function(){
              $state.go('app.customer.segment.list');
          }
          function getDetailSegment(id){
            promotionAPI.getDetailSegment(id).then(function(res){
                try{
                    if(res.data._type=='success'){
                        $scope.mainData.generalInfo = res.data.results;
                        $scope.mainData.generalInfo.crtd_on = new Date( $scope.mainData.generalInfo.crtd_on);
                        angular.forEach(res.data.results.detail,function(item){
                            console.log(item)
                            $scope.getCustomer(item);
                             $scope.updateStateSelect2();

                        })
                        $scope.mainData.segmentList =  res.data.results.detail;
                        // $scope.mainData.segmentList[0].customers= ['25'];
                        console.log( $scope.mainData.segmentList);

                    } else {
                        toastr.error(res.data.message);
                    }

                }catch(e){
                    console.log(e)
                }
            })
        }

        $scope.updateSegment = function(id){
            var params = $scope.mainData.generalInfo;
              params.detail = $scope.mainData.segmentList;
              promotionAPI.updateSegment(id,params).then(function(res){
                  try{
                      if(res.data._type=='success'){
                        toastr.success(res.data.message);
                        $timeout(function() {
                            $state.go("app.customer.customer-segment.list");
                        }, 500)

                    } else {
                        toastr.error(res.data.message);
                      }

                  }catch(e){
                      console.log(e);
                  }
              })
        }

    }
})();
