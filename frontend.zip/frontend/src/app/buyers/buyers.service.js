
(function () {
    'use strict';

    angular
        .module('app')
        .service('buyerAPI', service);

    /** @ngInject */
    function service(API, $q, $interval, $http) {

        this.getListCompany =getListCompany;
        this.updateImageForBuyer = updateImageForBuyer;
        this.getAllCity = getAllCity;
        this.getStateByCountry = getStateByCountry;
        this.getCityByState = getCityByState;
        this.createBuyer = createBuyer;
        this.getListBuyerType =getListBuyerType;
        this.getSalePriceList =getSalePriceList;
        
        function getAllCity() {
            var url = ['city', 'get-all'].join('/');
            return API.get(url);
        }     
        function getListCompany(params){
            var url ='company/list-option-company';
            return API.get(url,params)
        } 
        
        function getStateByCountry( params) {
            var url = 'state/get-by-country'
            return API.get(url, params);
        }

        function getCityByState(params) {
            var url = 'city/get-by-state';
            return API.get(url, params);
        }
        
        function getListBuyerType(){
            var url ='company_type/all';
            return API.get(url);
        }
        function getSalePriceList(){
            var url ='sale-price/get-list-option';
            return API.get(url);
        }

        //create image for product
        function createBuyer(data,files) {
            var url = ['buyer', 'create'].join('/');
            url = API.getHost() + url;
            var defer = $q.defer();
            var formData = new FormData();
            formData.append('data', JSON.stringify(data));
            if(files)
                formData.append('image' , files[0]);


            $http
                .post(url, formData, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function (result) {
                    defer.resolve(result);

                })
                .error(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }
        
        //update image for product
        function updateImageForBuyer(idBuyer,data,files) {
            var url = ['buyer', 'update',idBuyer].join('/');
            url = API.getHost() + url;
            var defer = $q.defer();
            var formData = new FormData();
            formData.append('data', JSON.stringify(data));
            if(files)
                formData.append('image' , files[0]);


            // Object
            //     .keys(data)
            //     .forEach(function (key, value) {
            //         formData.append(key, data[key])
            //     })
            $http
                .post(url, formData, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function (result) {
                    defer.resolve(result);

                })
                .error(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }
    }
})();
