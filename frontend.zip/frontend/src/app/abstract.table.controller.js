(function () {
    'use strict';

    angular.module('app').controller('abstract.table.controller', controller);


    /** @ngInject **/
    function controller($scope, $anchorScroll){
        var _this = this;
	    $scope.itemPerPageOptions = [15,30,50,100,200];
	    $scope.maxSize = 5;
	    $scope.changeLength = changeLength;


        $scope.sortParams = {};

        $scope.pagination_2 = {
            length : $scope.itemPerPageOptions[0]
        };

        _this.getParams = getParams;
        _this.sortAction = sortAction;
        _this.matchPagingOption = matchPagingOption;
        _this.searchAction = searchAction;
        $scope.sortAction = sortAction;


        $scope.searchAction = searchAction;
        $scope.changeLength = changeLength;
        $scope.changePage = changePage;

        return _this;

        /** Internal functions */

        function getParams() {
            var params  = {};
            params.page = $scope.pagination_2.page || 1;
            params.length = $scope.pagination_2.length || 15;

            angular.forEach(_this.params, function(value, key) {
                if(value)
                {
                    params[key] = value;
                }
            });

            /* check sort */
            if($scope.sortParams['order']) {
	            params['order'] = $scope.sortParams.order;
            } /*else {
	            params['order'] = 'name';
            }*/

            if($scope.sortParams['sort']) {
                params['sort'] = $scope.sortParams.sort === 1 ? 'asc' : 'desc';
            }

            return params;
        }

        function sortAction() {
            $scope.getList();
        }

	    function changeLength() {
		    $scope.pagination_2.page = 1;
		    return getList();
	    };

        function searchAction(params){
            _this.params = angular.copy(params);

            $scope.pagination_2.page = 1;
            return $scope.getList();
        }
        

        function changeLength() {
            $anchorScroll();
            $scope.pagination_2.page = 1;
            return $scope.getList();
        }

        function changePage() {
            $anchorScroll();
            return $scope.getList();
        }

        function matchPagingOption(options)
        {
            try{
                $scope.pagination_2.total_page = options['total_page'];
                $scope.pagination_2.total_record = options['total_record'];
                $scope.pagination_2.page = options['page'];
            }catch(e){
                console.log('pagination',e);
            }
        }
    }
})();
