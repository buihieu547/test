

(function () {
    'use strict';

    angular.module('app').service('API',service);

    /** @ngInject */
    function service(envConfig, $http) {
        var _this = this;

        this.get = function (uri, params) {

            var url = this.getHost() + uri;
            return $http.get(url, { params:params } );
        };

        this.post = function (uri, params) {

            var url = this.getHost() + uri;
            return $http.post(url, params);
        };

        this.put = function (uri, params) {

            var url = this.getHost() + uri;
            return $http.put(url, params);
        };

        this.delete = function (uri, params) {

            var url = this.getHost() + uri;
            return $http.delete(url, { params:params });
        };

        this.getHost = function () {
            return envConfig.API_HOST + envConfig.API_VERSION;
        };

        this.handleErrors = function (error) {
            if(error.message)
            {
                window.toastr.error(error.message);
            }
            else
            {
                this.parseErrorMsg(error.errors).forEach(function (msg) {
                    window.toastr.error(msg);
                });
            }
        };

        this.parseErrorMsg = function (errors,message) {

            if(!message) message = [];

            if(angular.isObject(errors))
            {
                for (var i in errors){
                    _this.parseErrorMsg(errors[i],message);
                }
            }
            else if(angular.isArray(errors))
            {
                errors.forEach(function (e) {
                    _this.parseErrorMsg(e,message);
                });
            }
            else
            {
                message.push(errors);
            }

            return message;
        };

        this.$get = function () {
            return this;
        };
    }
})();
