(function () {
    'use strict';

    angular
        .module('app')
        .filter('utcToLocal', function (moment) {
            return function (date, formatOutput, formatInput) {
                if(!formatInput)
                    formatInput = 'MM-DD-YYYY hh:mm:ss';
                if(!formatOutput)
                    formatOutput = 'MM-DD-YYYY HH:mm:ss';
                var localOrdDate =  moment.utc(date, formatInput).local().format(formatOutput);
                return localOrdDate;
            }
        })
})();