(function() {
	'use strict';

	angular.module('app').controller('accounts.manage.controller', controller);

	/** @ngInject */
	function controller($scope, $controller, API, $state, MessageService) {
		var $listController = $controller('abstract.list.controller',{ $scope : $scope });

		$scope.itemPerPageOptions = [15,30];
		$scope.pagination = {
			length : $scope.itemPerPageOptions[0]
		};

		$scope.getList = getList;
		$scope.addNewAccount = addNewAccount;
		$scope.searchAction = searchAction;
		$scope.resetAction = resetAction;
		$scope.deleteAccount = deleteAccount;
		$scope.editAccount = editAccount;
		$scope.search = {};

		$scope.list = {
			items : []
		};

		/** Internal functions */

		(function onInit() {
			getList();
		})();

		function searchAction(search) {
			var params = $listController.getParams();
			angular.merge(params, search);
			$listController.searchAction(params);
		}

		function resetAction() {
			$scope.search = {};
			$listController.searchAction();
		}

		function addNewAccount() {
			$state.go("app.accounts.create");
		}

		function deleteAccount(accountId) {
			MessageService.showConfirm("Are You Sure?").then(function(yes) {
				if(yes)
				{
					API.delete(['user', 'delete', accountId].join('/')).success(function (res) {
						window.toastr.success(res.message);
						getList();
					});
				}
			})
		}

		function editAccount(item) {
			if (item.id) {
				$state.go("app.accounts.edit",{id: item.id});
			}
		}

		function getList() {
			var params = $listController.getParams();
			API.get('user', params).then(function(res) {
				try {
					$scope.list.items = res.data.results.rows;
					$listController.matchPagingOption(res.data.results);
				} catch(e) {
					console.log(e);
				}
			});
		}
	}
})();