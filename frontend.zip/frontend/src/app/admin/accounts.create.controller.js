(function() {
	'use strict';

	angular.module('app').controller('accounts.create.controller', controller);

	/** @ngInject */
	function controller($scope, $controller, API, $state, MessageService, $stateParams) {
		var $listController = $controller('abstract.list.controller', {$scope: $scope});

		$scope.account = {};
		$scope.cancelCreateAccount = cancelCreateAccount;
		$scope.saveCreateAccount = saveCreateAccount;
		$scope.roles = [];

		(function onInit() {
			getListRole();
		})();

		/** Internal functions */

		function getListRole() {
			API.get('role').then(function(res) {
				try {
					$scope.roles = res.data.results.rows;
				} catch(e) {
					console.log(e);
				}
			})
		}

		function cancelCreateAccount() {
			$state.go('app.accounts.manage');
		}

		function saveCreateAccount(data) {

			var params = angular.copy(data);

			API.post('user', params).then(function(res) {
				try {
					if (res.data._type === 'success') {
						toastr.success(res.data.message);
						if ($stateParams.redirect) {
							$state.go($stateParams.redirect,{ids: $stateParams.ids});
						} else {
							$state.go('app.accounts.manage');
						}
					}
				} catch(e) {
					console.log(e);
				}
			});
		}
	}
})();