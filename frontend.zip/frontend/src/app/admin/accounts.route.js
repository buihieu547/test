(function() {
	'use strict';

	angular
		.module('app')
		.config(config);

	/** @ngInject */
	function config($stateProvider, $urlRouterProvider, $locationProvider) {

		$stateProvider
			.state('app.accounts', {
				url: '/accounts',
				template: '<ui-view></ui-view>',
				abstract: true
			})
			.state('app.accounts.manage', {
				url: '/manage',
				templateUrl: 'app/admin/accounts.manage.html',
				controller: 'accounts.manage.controller',
				middleware : ['auth', 'admin']
			})
			.state('app.accounts.create', {
				url: '/create/:id',
				templateUrl: 'app/admin/accounts.create.html',
				controller: 'accounts.create.controller',
				middleware: ['auth', 'admin']
			})
			.state('app.accounts.edit', {
				url: '/edit/:id',
				templateUrl: 'app/admin/accounts.edit.html',
				controller: 'accounts.edit.controller',
				middleware: ['auth', 'admin']
			})
	}
})();