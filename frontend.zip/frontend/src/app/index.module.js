/**
 * @ngdoc overview
 * @name angular
 * @description
 * # angular
 *
 * Main module of the application.
 */

var moduleName = 'app';

var app = angular.module('app', [
    'ui.router',
    'ui.bootstrap',
    'ui.router.middleware',
    'ngAnimate',
    'ngStorage',
    'checklist-model',
    'chart.js',
    '720kb.datepicker',
    'autocomplete',
    'angularMoment',
	  'ngIdle',
    
    'ui.select2',
    'cfp.hotkeys',
    'ui.carousel',
    'ncy-angular-breadcrumb',
    'chart.js',
    'toastr',
    'tmh.dynamicLocale',
    'gettext',
    'ui.mask',
    'ngDraggable'
]);

app.config(['uibDatepickerConfig',function (uibDatepickerConfig) {
    uibDatepickerConfig.startingDay = 1;
    uibDatepickerConfig.showWeeks = false;
  }])
  
app.config(['IdleProvider', 'KeepaliveProvider', 'tmhDynamicLocaleProvider', function(IdleProvider, KeepaliveProvider, tmhDynamicLocaleProvider) {
	IdleProvider.idle(30*60); // 30 minutes idle
	IdleProvider.timeout(1); // after 1 seconds idle, time the user out
    KeepaliveProvider.interval(1*60); // 5 minute keep-alive ping
    tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');
    tmhDynamicLocaleProvider.localeLocationPattern('/angular-i18n/angular-locale_{{locale}}.js');      
    //  if(process.env.NODE_TYPE != 'server') {
    //     tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');        
    // } else {
    //     tmhDynamicLocaleProvider.localeLocationPattern('/angular-i18n/angular-locale_{{locale}}.js');    
    // }
    
    
}]);
